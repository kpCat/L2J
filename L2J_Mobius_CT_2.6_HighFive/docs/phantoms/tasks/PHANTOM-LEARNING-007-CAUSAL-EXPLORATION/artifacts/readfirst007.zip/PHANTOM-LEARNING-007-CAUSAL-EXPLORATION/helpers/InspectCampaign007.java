import java.nio.file.*;
import java.util.*;
import org.l2jmobius.gameserver.phantoms.learning.*;

/** Read-only canonical receipt joins. No SQL, fitting, replay mutation, dispatch or counterfactual labels. */
public final class InspectCampaign007 {
    static String q(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r")+"\"";}
    public static void main(String[] args)throws Exception{
        Path campaign=Path.of(args[0]);var samples=new ArrayList<ActionAdvantageV1.Sample>();var items=new ArrayList<String>();
        int terminals=0,missing=0,invalid=0,alternatives=0;String error="";
        try(var directories=Files.list(campaign)){
            for(var w:directories.filter(p->p.getFileName().toString().matches("slot-\\d{3}")).sorted().toList()){
                if(!Files.exists(w.resolve("terminal.bin"))){continue;}
                byte[] bytes=Files.readAllBytes(w.resolve("terminal.bin"));
                var terminal=TerminalRewardReceiptV1.restore(bytes,TacticalObservationV3.hash(bytes));terminals++;
                var path=campaign.resolve("samples").resolve(terminal.episode().id()+".selection.bin");
                if(!Files.exists(path)){missing++;continue;}
                var selection=TrainExplorationV1.Selection.restore(Files.readAllBytes(path));
                try{
                    var sample=new ActionAdvantageV1.Sample(selection,terminal);samples.add(sample);
                    var receipt=sample.row().receipt();boolean different=!selection.stock().equals(selection.selected());if(different){alternatives++;}
                    items.add("{\"slot\":"+q(w.getFileName().toString())+",\"episode\":"+q(terminal.episode().id())+",\"split\":"+q(selection.split())+",\"scope\":"+q(terminal.episode().scope())+",\"experimental\":"+selection.experimental()
                        +",\"context\":"+q(sample.context())+",\"physicalSha\":"+q(selection.cell())+",\"different\":"+different+",\"propensity\":"+selection.propensity()+",\"stock\":"+q(selection.stock().toString())+",\"selected\":"+q(selection.selected().toString())
                        +",\"eventKey\":"+q(receipt.eventKey())+",\"receiptSha\":"+q(TacticalObservationV3.hash(TacticalStoreV3.encode(sample.row())))+",\"selectionSha\":"+q(selection.sha256())+",\"terminalSha\":"+q(terminal.sha256())
                        +",\"actualHp\":"+receipt.actualHp()+",\"actualMp\":"+receipt.actualMp()+",\"elapsedNanos\":"+receipt.elapsedNanos()+",\"outcome\":"+q(terminal.outcome())+",\"utility\":"+sample.utility()+"}");
                }catch(IllegalArgumentException rejected){invalid++;error=rejected.getMessage();}
            }
        }
        String frozen="null";
        if(!samples.isEmpty()){
            try{var f=ActionAdvantageV1.freeze("0".repeat(32),samples);frozen="{\"sufficient\":"+f.sufficient()+",\"metrics\":"+f.metrics()+",\"targets\":"+f.targets().size()+"}";}
            catch(IllegalArgumentException rejected){error=rejected.getMessage();}
        }
        String output="{\"readOnly\":true,\"terminals\":"+terminals+",\"samples\":"+samples.size()+",\"missingSelection\":"+missing+",\"invalidJoin\":"+invalid+",\"paidAlternatives\":"+alternatives+",\"error\":"+q(error)+",\"frozenPreview\":"+frozen+",\"actions\":["+String.join(",",items)+"]}";
        Files.writeString(Path.of(args[1]),output+"\n");
        System.out.println("INSPECT007 terminals="+terminals+" matched="+samples.size()+" missing="+missing+" invalid="+invalid+" paidAlternatives="+alternatives+" preview="+frozen+" error="+error);
    }
}
