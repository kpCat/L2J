"""Read-only evidence analysis and exact new-file delivery for the design review stage."""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

BASE = Path(__file__).resolve().parent
PACKAGE = BASE / "package"
TASK = "PHANTOM-LEARNING-007-CAUSAL-EXPLORATION"
MODULE = "L2J_Mobius_CT_2.6_HighFive"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(name, value):
    path = PACKAGE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def analyze(repo):
    historical = repo / MODULE / "docs/phantoms/tasks/PHANTOM-LEARNING-006R1-OUTCOME-CLOSURE"
    ab = read(historical / "evidence/ab-r1.json")
    resources = read(historical / "evidence/resources-r1.json")
    scores = read(BASE / "draft9-scores.json")
    keys = {e["key"] for a in ab["independentAB"]["arms"] if a["side"] == "LEARNED" for e in a["effects"]}
    selected = [o for o in scores["observations"] if o["key"] in keys]
    assert len(selected) == len(keys) == 16
    assert len({o["key"] for o in selected}) == 16
    assert sum(o["topEqualsStock"] for o in selected) == 8
    counters = collections.Counter()
    for entry in resources["policyDiagnostics"]:
        counters.update(entry["receipt"]["counters"])
    groups = {}
    for family in ("DAMAGE", "HEAL"):
        rows = [o for o in selected if o["family"] == family]
        values = [s["score"] for r in rows for s in r["scores"]]
        groups[family] = dict(n=len(rows), topEqualsStock=sum(r["topEqualsStock"] for r in rows),
            minimumGap=min(r["gap"] for r in rows), maximumGap=max(r["gap"] for r in rows),
            minimumScore=min(values), maximumScore=max(values))
    archive = historical / "artifacts/native-evidence-r1.zip"
    with zipfile.ZipFile(archive) as native:
        for row in scores["observations"]:
            prefix = row["path"].removesuffix(".native.source.json")
            source_bytes = native.read(prefix + ".source.json").rstrip(b"\r\n")
            source = json.loads(source_bytes)
            assert sha(native.read(row["path"]).rstrip(b"\r\n")) == source["nativeReceiptSha"]
            assert sha(native.read(prefix + ".observation.bin")) == source["observationSha"]
    diag = dict(stage="READ_FIRST_ONLY", method=scores["method"],
        historicalArchiveSha=sha(archive.read_bytes()), canonicalReconstructedObservations=len(scores["observations"]),
        primaryLearnedPaidActions=len(selected), topEqualsStock=8, topDifferentFromStock=8, allPrimaryGapsBelow0025=True,
        families=groups, countersScope="Published 006R1 proof plus independentAB plus stock-stock diagnostics; overlapping reasons",
        counters=dict(sorted(counters.items())), safetyReasonKeysRecorded=[],
        nativeReadinessRefusalCensus="UNKNOWN", trainEpisodeRewards=scores["trainEpisodeRewards"],
        gradientDiagnosis="Static chain-rule review only; no obvious defect; numerical gradient NOT_RUN",
        scoreRows=selected)
    write("evidence/diagnostics.json", diag)
    exports = repo / ".phantom-local/learning002/train/tactical-v3-exports"
    original = exports / "model-2-b69c2f1271854fc38e35b2a183be17f3.zip"
    cold = exports / "model-2-944dc10b9be74beabf111131c0e8a6e7.zip"
    assert sha(original.read_bytes()) == "291474aff0bfe16b4ad580a9e18b9d9135058fb36d74bc3f21542f4daad1dd1d"
    with zipfile.ZipFile(original) as old, zipfile.ZipFile(cold) as fresh:
        entries = {n: sha(fresh.read(n)) for n in fresh.namelist()}
        assert set(old.namelist()) == set(fresh.namelist())
        assert all(old.read(n) == fresh.read(n) for n in old.namelist() if n != "manifest.json")
        manifest = json.loads(fresh.read("manifest.json"))
        apps = [json.loads(line) for line in fresh.read("terminal-applications.jsonl").decode().splitlines()]
        assert len(apps) == 13
    write("evidence/g0-cold.json", dict(sourceHead="3bfdce560a24882519a3358d405bfe4b99bb25de",
        localBranch="wip/phantom-learning-007", sourceTrackedDirtBefore=False,
        actualRemoteRefs={"feature/phantom-world":"7e997636dbac9d5e1754e00c793cd6fac858b0c6",
            "master":"16d61833b3983a3976583d0e4813e0de9457a52f",
            "wip/phantom-learning-006":"5a38d35194c914c5dda90f8d57763a916201e977",
            "wip/phantom-learning-006r1":"3bfdce560a24882519a3358d405bfe4b99bb25de"},
        ancestry={"method":"Independent GitHub compare_commits", "status":"diverged", "ahead":3,"behind":1,
            "mergeBase":"dfcba154fa1f459be6082a559744d2b4a5c9b47a"},
        preflightExit=0, coldExportExit=0, gameServerStarts=0, nativeWallSeconds=0,
        coldExportName=cold.name, coldExportSha=sha(cold.read_bytes()), originalExportSha=sha(original.read_bytes()),
        allPayloadEntriesByteEqual=True, entries=entries, manifest=manifest,
        terminalOptimizerWeightsSha=scores["terminalOptimizerWeightsSha"], applicationMarkers=len(apps),
        readback="Canonical optimizationParent SQL traversal plus terminal snapshot validation during cold Export",
        controlledPreCommitCrash="NOT_RUN", state="STOPPED", generation=16))
    evidence = dict(goal=TASK, stage="PLAN_REVIEW_REQUIRED", goalComplete=False, productCodeChanged=False,
        gameServerStarts=0, ceilingGameServerStarts=8, nativeWallSeconds=0, ceilingNativeWallSeconds=5400,
        training007="NOT_RUN", gameVerdict="NOT_EVALUATED", finalManualGate="REQUIRED",
        designOwnerApproval="PENDING", baselineAndCold="evidence/g0-cold.json", diagnostics="evidence/diagnostics.json",
        historicalGameVerdict006R1="INCONCLUSIVE", historicalPaidDivergences006R1=0,
        gitUsed=True, branch="wip/phantom-learning-007", commits007=[], push007="NOT_RUN_AT_PLAN_STAGE",
        budget={"historicalIssuedTasks001Through006R1":7,"remainingDevelopmentRangeAfter006R1":[7,13],
            "currentTaskNumberWithin13":1,"remainingUntilReviewThreshold":12,"partialAndFixTasksConsumeBudget":True},
        encoding={"mojibake":"PENDING_FINAL_CHECK","escapedCyrillic":"PENDING_FINAL_CHECK"})
    write("EVIDENCE.json", evidence)
    archived = {"Diagnostic007.java":BASE / "Diagnostic007.java", "draft9-scores.json":BASE / "draft9-scores.json",
        "Package007.py":Path(__file__), "g0-cold.json":PACKAGE / "evidence/g0-cold.json"}
    artifact = PACKAGE / "artifacts/readfirst007.zip"
    artifact.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(artifact, "x", compression=zipfile.ZIP_DEFLATED) as out:
        for name, source in archived.items(): out.writestr(name, source.read_bytes())
        out.writestr("SHA256SUMS.json", json.dumps({n:sha(p.read_bytes()) for n,p in archived.items()}, indent=2))
    print(json.dumps({"diagnostics":groups,"coldExportSha":sha(cold.read_bytes()),"archiveBytes":artifact.stat().st_size}))

def mapping():
    output = {f"{MODULE}/docs/phantoms/tasks/{TASK}/{p.relative_to(PACKAGE).as_posix()}":p
        for p in PACKAGE.rglob("*") if p.is_file() and p.name not in {"REPORT.md", "COMBAT-AI-ROADMAP.md", "SCOPE_ALLOWLIST.txt"}}
    output[f"{MODULE}/docs/phantoms/reports/{TASK}.md"] = PACKAGE / "REPORT.md"
    output[f"{MODULE}/docs/phantoms/COMBAT-AI-ROADMAP.md"] = PACKAGE / "COMBAT-AI-ROADMAP.md"
    scope = f"{MODULE}/docs/phantoms/tasks/{TASK}/SCOPE_ALLOWLIST.txt"
    output[scope] = PACKAGE / "SCOPE_ALLOWLIST.txt"
    output[scope].write_text("\n".join(sorted(output)) + "\n", encoding="utf-8")
    return output

def deliver(repo):
    outputs = mapping()
    for name, source in outputs.items():
        destination = repo / name
        if destination.exists() and destination.read_bytes() != source.read_bytes():
            raise RuntimeError("Existing unique file would be replaced: " + name)
    for name, source in outputs.items():
        destination = repo / name
        if destination.exists(): continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        pending = destination.with_name(destination.name + ".pending007")
        with pending.open("xb") as stream: stream.write(source.read_bytes())
        assert sha(pending.read_bytes()) == sha(source.read_bytes())
        pending.rename(destination)
    assert all((repo / n).read_bytes() == s.read_bytes() for n,s in outputs.items())
    print(json.dumps({"deliveredPaths":len(outputs),"scopeSha":sha((PACKAGE/"SCOPE_ALLOWLIST.txt").read_bytes())}))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["analyze", "deliver"])
    parser.add_argument("repo", type=Path)
    args = parser.parse_args()
    (analyze if args.action == "analyze" else deliver)(args.repo.resolve())
