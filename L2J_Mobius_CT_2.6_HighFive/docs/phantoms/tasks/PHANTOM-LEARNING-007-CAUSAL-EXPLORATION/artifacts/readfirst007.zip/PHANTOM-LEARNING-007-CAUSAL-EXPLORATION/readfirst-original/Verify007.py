"""Focused artifact/encoding/scope validation; no product execution or training."""
import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path
import zipfile
from Package007 import BASE, PACKAGE, MODULE, TASK, mapping

MARKERS = ('Рџ','Рќ','Рћ','Р•','РЎ','Р›','Р¤','Рњ','РЈ','Рљ','Рґ','Рµ','Р°','Р»','РЅ','Рѕ',
           'СЏ','С€','СЂ','С‹','СЊ','С‚','Сѓ','С‡','С…','С†','�')
ESCAPED = (r'\\u04[0-9A-Fa-f]{2}', r'\\u05[0-9A-Fa-f]{2}',
           r'&#x04[0-9A-Fa-f]{2};', r'&#x05[0-9A-Fa-f]{2};',
           r'&#X04[0-9A-Fa-f]{2};', r'&#X05[0-9A-Fa-f]{2};')

def verify(repo=None, seal=False):
    output = mapping()
    assert len(output) == 14, len(output)
    markers, escaped, links, whitespace = [], [], [], []
    virtual = {name:source for name, source in output.items()}
    for name, source in output.items():
        path = repo / name if repo else source
        if repo: assert path.read_bytes() == source.read_bytes(), name
        if path.suffix == '.zip':
            with zipfile.ZipFile(path) as archive:
                sums = json.loads(archive.read('SHA256SUMS.json'))
                assert set(archive.namelist()) == set(sums) | {'SHA256SUMS.json'}
                for member, expected in sums.items():
                    assert hashlib.sha256(archive.read(member)).hexdigest() == expected, member
            continue
        text = path.read_text(encoding='utf-8')
        if path.suffix == '.json': json.loads(text)
        markers.extend((name,m) for m in MARKERS if m in text)
        escaped.extend((name,p) for p in ESCAPED if re.search(p,text))
        whitespace.extend((name,i) for i,line in enumerate(text.splitlines(),1) if line.rstrip()!=line)
        if path.suffix == '.md':
            for target in re.findall(r'\]\(([^)]+)\)',text):
                if '://' in target or target.startswith('#'): continue
                target = target.split('#',1)[0]
                relative = Path(name).parent / target
                normalized = str(relative).replace('\\','/')
                parts=[]
                for part in normalized.split('/'):
                    if part=='..': parts.pop()
                    elif part!='.': parts.append(part)
                if '/'.join(parts) not in virtual:
                    links.append((name,target))
    assert not markers, markers
    assert not escaped, escaped
    assert not whitespace, whitespace
    assert not links, links
    git=None
    if repo:
        tracked=subprocess.run(['git','status','--porcelain=v1','--untracked-files=no'],cwd=repo,capture_output=True,text=True)
        assert tracked.returncode==0 and not tracked.stdout.strip(), (tracked.returncode,tracked.stdout,tracked.stderr)
        scoped=subprocess.run(['git','status','--porcelain=v1','--untracked-files=all','--',*sorted(output)],cwd=repo,capture_output=True,text=True)
        assert scoped.returncode==0 and len(scoped.stdout.splitlines())==14, scoped.stdout
        assert all(line.startswith('?? ') for line in scoped.stdout.splitlines()), scoped.stdout
        diff=subprocess.run(['git','diff','--check','--',*sorted(output)],cwd=repo,capture_output=True,text=True)
        assert diff.returncode==0 and not diff.stdout.strip(), (diff.returncode,diff.stdout,diff.stderr)
        git={'trackedDirt':0,'newExactPaths':14,'diffCheckExit':diff.returncode}
    result={'exactPaths':14,'utf8JsonLinksWhitespace':'PASS',
            'mojibakeMarkers':'PASS_27_MARKERS','escapedCyrillic':'PASS_6_PATTERNS',
            'archiveEntrySha':'PASS','scope':git,'productCodeChanged':False,'goalComplete':False}
    if seal:
        path=PACKAGE/'EVIDENCE.json'
        evidence=json.loads(path.read_text(encoding='utf-8'))
        evidence['encoding']={'mojibake':'PASS_27_MARKERS','escapedCyrillic':'PASS_6_PATTERNS'}
        evidence['artifactVerification']={'exactPaths':14,'utf8JsonLinksWhitespace':'PASS','archiveEntrySha':'PASS',
            'stage':'SCRATCH_BYTES_BEFORE_IDENTICAL_DELIVERY'}
        evidence['designReview']={'reviewer':'independent builder-check subagent','importantQuestions':2,
            'resolvedInDesign':['campaign STOP versus transient decision fallback','quantitative G4 admission'],
            'ownerApproval':'PENDING','implementationApproved':False}
        path.write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        return verify(repo=None,seal=False)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--repo',type=Path)
    parser.add_argument('--seal',action='store_true')
    args=parser.parse_args()
    print(json.dumps(verify(args.repo,args.seal),ensure_ascii=False))
