# PHANTOM-LEARNING-007 — независимые TEST наблюдения

Новая модель DRAFT, accepted1/2 неизменны. EVAL никогда не обучает. Game verdict INCONCLUSIVE: бюджет меньше20пар на режим.

Native outcome подтверждается отдельно terminal.json; неполная action evidence не означает отсутствие kill. UNKNOWN deaths/loot/economy не заменяются0. Score/margin пересчитаны после drain по frozen model и exact observation; native selection и paid effect — из настоящих owners.

## SOLO_DAMAGE_V3

Fair completed pairs: 1; A→B=0; B→A=1; paid divergences=0. Median Δms=-15837.752300000004; 95% bootstrap CI=-15837.752300000004…-15837.752300000004.

- SOLO_DAMAGE_V3-0: MATCHED_COMPLETED/PHYSICAL_FACTS_EQUAL_NATIVE_RANDOMNESS_INDEPENDENT; A=COMPLETED/36071.2407ms; B=COMPLETED/20233.4884ms; divergences=0; deltas={adenaNet=null, allActionsMpDebit=null, canonicalCompleted=0.0, consumables=null, deaths=null, deathsLowerBound=0.0, drainMillis=604.6299, elapsedMillis=-15837.752300000004, exp=724.0, expPerMinute=57643.63516304147, hp=2268.3255482752365, loot=null, mp=-16.1902240000004, netHpChange=2268.3255482752365, netMpChange=-16.1902240000004, observedHealMpDebit=0.0, observedUsefulHeal=0.0, settlementSnapshotMillis=-15288.767099999997, sp=0.0, spPerMinute=9888.73479470109, uniqueEnemyKills=0.0, untrackedStockDamageUnknown=0.0, usefulHeal=null, wholePartyDamage=null}.
## PARTY_HEAL_V3

Fair completed pairs: 1; A→B=0; B→A=1; paid divergences=0. Median Δms=8850.4922; 95% bootstrap CI=8850.4922…8850.4922.

- PARTY_HEAL_V3-0: MATCHED_COMPLETED/PHYSICAL_FACTS_EQUAL_NATIVE_RANDOMNESS_INDEPENDENT; A=COMPLETED/19509.9703ms; B=COMPLETED/28360.4625ms; divergences=0; deltas={adenaNet=null, allActionsMpDebit=null, canonicalCompleted=0.0, consumables=null, deaths=null, deathsLowerBound=0.0, drainMillis=-914.3108000000002, elapsedMillis=8850.4922, exp=0.0, expPerMinute=-106358.16149088144, hp=-543.256637972514, loot=null, mp=29.426980000000185, netHpChange=-543.256637972514, netMpChange=29.426980000000185, observedHealMpDebit=0.0, observedUsefulHeal=-1987.2545627304019, settlementSnapshotMillis=7865.841800000002, sp=0.0, spPerMinute=-18950.81488886533, uniqueEnemyKills=0.0, untrackedStockDamageUnknown=0.0, usefulHeal=null, wholePartyDamage=null}.
