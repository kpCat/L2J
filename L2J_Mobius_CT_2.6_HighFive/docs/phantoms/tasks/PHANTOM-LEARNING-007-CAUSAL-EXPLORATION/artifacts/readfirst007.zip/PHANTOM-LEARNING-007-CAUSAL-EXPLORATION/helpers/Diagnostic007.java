import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;
import org.l2jmobius.gameserver.phantoms.learning.*;

/** Read-only offline evidence inspection. Uses the unchanged canonical Java scorer; never fits or dispatches. */
public class Diagnostic007 {
    static String read(ZipFile zip, String name) throws Exception {
        try (var input = zip.getInputStream(Objects.requireNonNull(zip.getEntry(name), name))) {
            return new String(input.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
    static byte[] bytes(ZipFile zip, String name) throws Exception {
        try (var input = zip.getInputStream(Objects.requireNonNull(zip.getEntry(name), name))) { return input.readAllBytes(); }
    }
    static String field(String json, String name) {
        var match = Pattern.compile("\"" + name + "\":\"([^\"]*)\"").matcher(json);
        if (!match.find()) throw new IllegalArgumentException(name);
        return match.group(1);
    }
    static float number(String json, String name) {
        var match = Pattern.compile("\"" + name + "\":([0-9.Ee+\\-]+)").matcher(json);
        if (!match.find()) throw new IllegalArgumentException(name);
        return Float.parseFloat(match.group(1));
    }
    static LegalActionV3 action(String fields) {
        var map = new HashMap<String,String>();
        for (String field : fields.split(", (?=[a-zA-Z]+=)")) {
            int at = field.indexOf('=');
            if (at <= 0 || map.put(field.substring(0, at), field.substring(at + 1)) != null) throw new IllegalArgumentException(fields);
        }
        if (map.size() != 16) throw new IllegalArgumentException("Unexpected native action record fields: " + map.size());
        return new LegalActionV3(LegalActionV3.Family.valueOf(map.get("family")), map.get("owner"),
            Long.parseLong(map.get("profileId")), Integer.parseInt(map.get("actorObjectId")), Long.parseLong(map.get("actorEpoch")),
            Long.parseLong(map.get("generation")), Integer.parseInt(map.get("targetObjectId")), Long.parseLong(map.get("targetEpoch")),
            map.get("partyIdentity"), Integer.parseInt(map.get("skillId")), Integer.parseInt(map.get("skillLevel")),
            Double.parseDouble(map.get("mpCost")), Integer.parseInt(map.get("castMillis")), Integer.parseInt(map.get("range")),
            Boolean.parseBoolean(map.get("criticalSafety")), Boolean.parseBoolean(map.get("lawful")));
    }
    static String id(LegalActionV3 action) { return action.skillId() + ":" + action.skillLevel() + "/" + action.targetObjectId(); }
    static String q(String value) { return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\""; }
    public static void main(String[] args) throws Exception {
        try (var export = new ZipFile(args[0]); var nativeZip = new ZipFile(args[1])) {
            var model = TacticalModelV3.restore(bytes(export, "working-weights.bin"), "5eacf0b7619c82de3950c0203fcf599c149156d13d31d67cfc9e408362b416dc");
            var optimizer = TacticalModelV3.Optimizer.restore(bytes(export, "optimizer.bin"), "f76ea960288f3cdb1ba85bb203a33cb327937fdffb99bc6bc4503b90cd54990c");
            var terminal = TerminalReplayV1.restore("6610167d6f044536954e926e5df843dc", bytes(export, "terminal-targets.bin"), "37ef5f6a259cbbcb7deed3425772ec9bd4a422a13d133bfc8475eae672720c0f");
            var output = new ArrayList<String>();
            for (String name : nativeZip.stream().map(ZipEntry::getName).filter(n -> n.endsWith(".native.source.json")).sorted().toList()) {
                String prefix = name.substring(0, name.length() - ".native.source.json".length());
                String source = read(nativeZip, prefix + ".source.json");
                String record = read(nativeZip, name);
                var observation = TacticalObservationV3.restore(bytes(nativeZip, prefix + ".observation.bin"));
                if (!TacticalObservationV3.hash(observation.bytes()).equals(field(source, "observationSha"))) throw new IllegalStateException("Observation SHA changed");
                var actions = new ArrayList<LegalActionV3>();
                int start = record.indexOf("offered=["), end = record.indexOf("], selected=LegalActionV3[", start);
                if (start < 0 || end < start) throw new IllegalStateException("Missing exact offered native records");
                var matcher = Pattern.compile("LegalActionV3\\[([^\\]]+)\\]").matcher(record.substring(start, end));
                while (matcher.find()) actions.add(action(matcher.group(1)));
                if (actions.size() < 2 || actions.size() > 16) throw new IllegalStateException("Native action count");
                var encoded = model.encode(observation.state());
                var scored = new ArrayList<String>();
                LegalActionV3 top = null;
                float best = -Float.MAX_VALUE, second = best, selectedScore = Float.NaN, stockScore = Float.NaN;
                String selected = field(source, "selected"), stock = field(source, "baseline");
                for (var action : actions) {
                    float score = model.scoreEncoded(encoded, action.features(observation));
                    scored.add("{\"action\":" + q(id(action)) + ",\"score\":" + score + "}");
                    if (score > best) { second = best; best = score; top = action; } else second = Math.max(second, score);
                    if (id(action).equals(selected)) selectedScore = score;
                    if (id(action).equals(stock)) stockScore = score;
                }
                if (!Float.isFinite(selectedScore) || !Float.isFinite(stockScore)
                    || Math.abs(selectedScore - number(source, "selectedScore")) > 0.000001
                    || Math.abs(stockScore - number(source, "stockScore")) > 0.000001
                    || Math.abs(best - second - number(source, "margin")) > 0.000001) throw new IllegalStateException("Canonical score readback differs: " + name);
                output.add("{\"path\":" + q(name) + ",\"key\":" + q(field(source, "eventKey")) + ",\"family\":" + q(top.family().name())
                    + ",\"stock\":" + q(stock) + ",\"selected\":" + q(selected) + ",\"neuralTop\":" + q(id(top))
                    + ",\"topEqualsStock\":" + id(top).equals(stock) + ",\"gap\":" + (best - second) + ",\"scores\":[" + String.join(",", scored) + "]}");
            }
            var rewards = terminal.receipts().stream().filter(r -> r.split().equals("TRAIN")).map(r -> Float.toString(r.reward())).toList();
            System.out.println("{\"method\":\"CANONICAL_JAVA_READ_ONLY_DRAFT9_RECONSTRUCTION\",\"modelSha\":" + q(model.sha256())
                + ",\"optimizerSha\":" + q(optimizer.sha256()) + ",\"terminalOptimizerWeightsSha\":" + q(optimizer.model().sha256())
                + ",\"updates\":" + optimizer.updates() + ",\"epochs\":" + optimizer.completedEpochs() + ",\"trainEpisodeRewards\":[" + String.join(",", rewards)
                + "],\"observations\":[" + String.join(",", output) + "]}");
        }
    }
}
