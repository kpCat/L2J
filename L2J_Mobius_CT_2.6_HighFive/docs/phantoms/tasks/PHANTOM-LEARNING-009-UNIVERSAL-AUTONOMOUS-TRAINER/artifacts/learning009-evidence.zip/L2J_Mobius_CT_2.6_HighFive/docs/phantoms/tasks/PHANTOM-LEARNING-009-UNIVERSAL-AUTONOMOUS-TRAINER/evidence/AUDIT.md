# Goal009 — read-first audit до реализации

13 ноября 2026, Europe/Chisinau. Результат этого этапа: прочитанный source и проект PLAN, без изменений checkout/runtime. Статус G0–G8 не объявляется PASS.

## Прочитано

Корневые AGENTS.md/README.md в TEST, основной AGENTS.md; серверный case-variant Agents.md; релевантные разделы PHANTOM_DEVELOPMENT_MASTER_PLAN.md, PHANTOM_CURRENT_STATUS.md, CODEX_WORKFLOW_CONTRACT.md и TASK_PACKAGE_STANDARD.md. Инструкций AGENTS.md выше repository root в D:/Codex/repos, D:/Codex, D:/ не найдено. Отдельные High Five code-map/pattern files не найдены; Studio source-pattern artifacts не относятся к этому TRAIN scope.

Predecessors: reports006R1/007/008, целевые разделы EVIDENCE006R1/007/008, PLAN008, HANDOFF008, COMMANDS006R1/008 и COMBAT-AI-ROADMAP. У008 отсутствует новый универсальный catalog; её hardcoded списки остаются historical fixtures.

Целевые source/декларации/участки внутри High Five:

- model/actor/enums/player/PlayerClass.java; data/xml/SkillTreeData.java и SkillData.java; model/actor/Creature.java и Player.java; model/skill/Skill.java, holders/EnchantSkillLearn.java; network/clientpackets/RequestExEnchantSkill.java; taskmanagers/AutoUseTaskManager.java.
- phantoms/combat/PhantomNativeCombatCapability.java, PhantomCombatCapabilityResolver.java, PhantomCombatLoadout.java, PhantomCombatService.java, L2jCombatBackend.java, PhantomSupportEffectAuthority.java; party/PhantomPartyTactics.java.
- progression/PhantomProgressionSourceParser.java, PhantomProgressionCatalog.java, L2jProgressionBackend.java. Последний уже обходит PlayerClass.values и complete parent trees; его actor snapshot читает настоящий learned set, readiness — native conditions/resources/reuse.
- learning/TacticalModelV3.java, TacticalObservationV3.java, TacticalSnapshotV3.java, TacticalPolicyV3.java, LegalActionV3.java, TacticalStoreV3.java, TacticalTrainerV3.java, TrainExplorationV1.java, ActionAdvantageV1.java, ActionAdvantage008.java, TerminalRewardReceiptV1.java, TrainingStore.java, TrainingConfig.java.
- test/.../PhantomTrainingScenarios.java, PhantomTrainingActors.java, PhantomTrainingNative.java, PhantomLearning008Scenarios.java, PhantomLearning001ActorFixture.java, PhantomLearning001ShadowNative.java.
- tools/phantom-runtime/training/Training.ps1, TrainingOwner.ps1, TrainingBroker.ps1, TrainingBootstrap.ps1, Test-Training.ps1, TRAIN_CONFIG.ini, TrainingV3.ini, RUNBOOK_RU.md; build.xml relevant requirements/compile-tests/007/008 targets.
- UI аналог: PhantomSemanticStudio/.../StageSelectionForm.Designer.cs и StageSelectionForm.cs. Только структура layout/runtime, Studio исходники и проекты не изменяются.

Это bounded чтение затронутых контрактов, не полный аудит всего GameServer.

## Переиспользуемые локальные паттерны

1. L2jProgressionBackend + PhantomProgressionSourceParser: native classes/complete skill trees + exact source attribution; acquired actor snapshot отдельно от theory.
2. PhantomNativeCombatCapability и PhantomSupportEffectAuthority: canonical mechanics/support classification; execution/readiness остаются в Combat/Party leases.
3. TrainingOwner/Bootstrap/Broker: один physical installation owner, nonce/PID creation-time/image/command/config guards, lock, detached lifecycle, atomic Write-TrainText.
4. TacticalStoreV3: frozen dataset, SQL transaction для model/Adam/applications, latestOptimization ancestry, immutable terminal receipts.
5. Native007/008 и Runtime001: pre-CUT lawful setup, native owners, paid HP/MP/terminal evidence, отдельные held-out splits; fixed class/skill lists и auto-learning не переносятся в новый algorithm.

## Существенные результаты

- getAllSkills/getKnownSkill определены в Creature и доступны Player: фактическая skill map. Complete class tree — другая, теоретическая коллекция с родителями.
- Skill.getLevel — canonical encoded level; EnchantSkillLearn имеет getEnchantRoute/getEnchantIndex. Отдельного подтверждённого getSubLevel API не найдено, его не следует выдумывать.
- SkillData.getSkill может вернуть max-rank fallback; exact returned level должен проверяться.
- Skill.getAffectLimit использует Rnd: его нельзя выдавать за неизменяемый max-target fact read-only каталога.
- Resolver, Loadout и L2jCombatBackend.learningCandidates ограничены4. TacticalPolicyV3 допускает16. TacticalSnapshotV3 хранит лишь128active abilities поID; это не полный learned inventory.
- Native mechanic discovery шире подтверждённых neural execution families. HEAL V3 выбирает из настоящих Party directives; ID summon/control не доказывает наличие adapter.
- Training.ps1 уже содержит generic batch loop и detached ownership; специальные007/008 routes выполняют одну фазу и ждут Stop в PAUSED. Для нового режима нужен цикл вокруг существующих владельцев.
- ActionAdvantage008 и её trainer routing имеют exact historical class/teacher/parent pins. Они не годятся для следующего бесконечного cohort fit без отдельной generic revision. Переписывать исторический смысл008 нельзя.
- Fixture createTraining автоматически добавляет class-tree skills. Новый путь обязан входить через настоящий сохранённый learned state и не использовать auto-learning как eligibility repair.

## Refs и ownership

TEST HEAD/branch:85b1c3558e35c1df0a7625fcf5a9e5c119c18b96/wip/phantom-learning-008. Tracked clean, untracked .phantom-local. Единственный worktree этого самостоятельного repository — сам TEST root. Локальный feature ref в TEST старый dfcba154fa1f459be6082a559744d2b4a5c9b47a; он не используется как009 base.

Основной checkout:feature/phantom-world,7e997636dbac9d5e1754e00c793cd6fac858b0c6, dirty. Только прочитан. GitHub connector подтвердил008 и feature exact SHA; master16d61833b3983a3976583d0e4813e0de9457a52f;009 отсутствует. Branch/commit/push не выполнялись.

Дополнительно независимо прочитаны GitHub007=062862eca8e0bcedd4107d7b91720627307f736c и006R1=3bfdce560a24882519a3358d405bfe4b99bb25de, совпали с локальными refs. Upstream у локальных006R1/007/008 не задан; публикационный target009 должен быть явно проверен, а не выведен из upstream.

Read-only owner-context check: saved director STOPPED; прежние Director86580/Native16276/Worker70180 не соответствуют живым PID+creation-time; listeners33357/18001/19301=0. Evaluation JSON: DRAFT candidate12; selected SHA6f3dfa43…; Adam85cea568…;terminal weights7d3c8fc1…;887/207. Это ещё не повторная SQL blob verification.

Sandbox чтение private training root получило Access Denied. Повторная **только read-only** проверка в owner-контексте прошла без изменения ACL или runtime. Запрошенный каталог train/exports не существует; повторный поиск не выполнялся. Некоторые поисковые команды первоначально использовали неверный cwd или несуществующий guessed filename (L2jCombatActorLease.java/model/skill/enchant); исправлены обращением к фактическим L2jCombatBackend и holders/EnchantSkillLearn. Это диагностические ошибки, не дефекты продукта и не основание менять scope.

## Git-команды этого этапа

Разрешение: user AGENTS/project-doc явно допускают bounded branch/scope inspection; Goal009 требует повторно проверить refs/working tree и отдельно разрешает scoped commit/push позже.

Из TEST root выполнены:

```text
git rev-parse --show-toplevel
git symbolic-ref --short HEAD
git rev-parse HEAD
git status --short
git for-each-ref --format='%(refname) %(objectname)' refs/heads refs/remotes
git for-each-ref --format='%(refname) %(objectname) %(upstream)' refs/heads/wip/phantom-learning-008 refs/heads/wip/phantom-learning-007 refs/heads/wip/phantom-learning-006r1
git worktree list --porcelain
```

Из основного checkout выполнены только первые4команды и повторно rev-parse HEAD/symbolic-ref. Изменения Git state, diff, branch creation, staging, commit/push не выполнялись. Remote refs проверялись GitHub search_branches/fetch_commit, а не изменением local refs.

## Что осталось проверить

Полный203/207 hash preflight, SQL digests/blobs/optimizer ancestry, all-class inventory counts и фактический TRAIN readiness, tests/build, GUI commands и detached lifetime, native lawful generator,2cycles/fit/evaluation, perf и final scope/publication — NOT_RUN. GameServer starts текущего этапа:0; SQL starts:0.

Оригинальное задание скопировано побайтово в TASK.txt вне checkout; оба SHA256=8c42f5228c0edebfcd20d170e06db3ffc8f159fd2ccc7209b98850f1b468a80c. Проверки этого документа, PLAN и TASK отдельными rg-командами: все27mojibake markers и все6escaped-Cyrillic patterns, exit1/no matches. После финальных правок проверки повторяются.

Отдельный read-only builder review сопоставил PLAN с заданием и ближайшим source, без Git-команд/SQL/native или edits. Существенные замечания внесены в PLAN: реальный OFF comparator одного frozen shortlist вместо обещания baseline полного production набора; separate comparison/split keys; source snapshot lineage; exactly-once replay;1initial decision/episode и48episodes/fit. Неразрешённых вопросов владельцу не выявлено. Approval всё ещё REQUIRED по пользовательскому правилу крупного PLAN.

- mojibake-маркеры в изменённых файлах проверены: полный набор27literal markers, совпадений нет.
- escaped Cyrillic в изменённых файлах проверены: все6regex, совпадений нет.
