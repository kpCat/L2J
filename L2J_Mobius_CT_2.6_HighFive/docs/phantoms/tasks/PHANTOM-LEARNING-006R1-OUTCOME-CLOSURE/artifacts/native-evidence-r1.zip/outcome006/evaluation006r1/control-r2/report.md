# PHANTOM-LEARNING-006R1 — независимые TEST наблюдения

Новая модель DRAFT, accepted1/2 неизменны. EVAL никогда не обучает. Game verdict INCONCLUSIVE: бюджет меньше20пар на режим.

Native outcome подтверждается отдельно terminal.json; неполная action evidence не означает отсутствие kill. UNKNOWN deaths/loot/economy не заменяются0. Score/margin пересчитаны после drain по frozen model и exact observation; native selection и paid effect — из настоящих owners.

## SOLO_DAMAGE_V3

Fair completed pairs: 1; A→B=0; B→A=1; paid divergences=0. Median Δms=12831.268600000003; 95% bootstrap CI=12831.268600000003…12831.268600000003.

- SOLO_DAMAGE_V3-0: MATCHED_COMPLETED/PHYSICAL_FACTS_EQUAL_NATIVE_RANDOMNESS_INDEPENDENT; A=COMPLETED/20790.7074ms; B=COMPLETED/33621.976ms; divergences=0; deltas={adenaNet=null, allActionsMpDebit=null, canonicalCompleted=0.0, consumables=null, deaths=null, deathsLowerBound=0.0, drainMillis=613.4032000000001, elapsedMillis=12831.268600000003, exp=4429.0, expPerMinute=-39040.506496422095, hp=-1078.2798201376177, loot=null, mp=190.3312960000003, netHpChange=-1078.2798201376177, netMpChange=190.3312960000003, observedHealMpDebit=0.0, observedUsefulHeal=0.0, settlementSnapshotMillis=13421.502700000001, sp=0.0, spPerMinute=-8364.810845595899, uniqueEnemyKills=0.0, untrackedStockDamageUnknown=0.0, usefulHeal=null, wholePartyDamage=null}.
## PARTY_HEAL_V3

Fair completed pairs: 1; A→B=0; B→A=1; paid divergences=0. Median Δms=10950.688399999995; 95% bootstrap CI=10950.688399999995…10950.688399999995.

- PARTY_HEAL_V3-0: MATCHED_COMPLETED/PHYSICAL_FACTS_EQUAL_NATIVE_RANDOMNESS_INDEPENDENT; A=COMPLETED/29419.3005ms; B=COMPLETED/40369.9889ms; divergences=0; deltas={adenaNet=null, allActionsMpDebit=null, canonicalCompleted=0.0, consumables=null, deaths=null, deathsLowerBound=0.0, drainMillis=-2107.5060999999996, elapsedMillis=10950.688399999995, exp=0.0, expPerMinute=-61308.93388343227, hp=-1401.1134502818604, loot=null, mp=-1.0973599999997532, netHpChange=-1401.1134502818604, netMpChange=-1.0973599999997532, observedHealMpDebit=0.0, observedUsefulHeal=0.0, settlementSnapshotMillis=8933.499200000006, sp=0.0, spPerMinute=-10923.978383720172, uniqueEnemyKills=0.0, untrackedStockDamageUnknown=0.0, usefulHeal=null, wholePartyDamage=null}.
