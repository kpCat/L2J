# PHANTOM-LEARNING-006R1 — независимые TEST наблюдения

Новая модель DRAFT, accepted1/2 неизменны. EVAL никогда не обучает. Game verdict INCONCLUSIVE: бюджет меньше20пар на режим.

Native outcome подтверждается отдельно terminal.json; неполная action evidence не означает отсутствие kill. UNKNOWN deaths/loot/economy не заменяются0. Score/margin пересчитаны после drain по frozen model и exact observation; native selection и paid effect — из настоящих owners.

## SOLO_DAMAGE_V3

Fair completed pairs: 0; A→B=0; B→A=0; paid divergences=0. Median Δms=null; 95% bootstrap CI=null…null.

- SOLO_DAMAGE_V3-0: UNMATCHED/PRE_CUT_FACTS_DIFFER; A=COMPLETED/12720.3358ms; B=COMPLETED/31916.082ms; divergences=0; deltas={}.
## PARTY_HEAL_V3

Fair completed pairs: 0; A→B=0; B→A=0; paid divergences=0. Median Δms=null; 95% bootstrap CI=null…null.

- PARTY_HEAL_V3-0: UNMATCHED/PRE_CUT_FACTS_DIFFER; A=INCOMPLETE/45014.539ms; B=INCOMPLETE/45078.5729ms; divergences=0; deltas={}.
