"""Read-only collection of existing 008 evidence; no model fitting or SQL access."""
import argparse
import collections
import hashlib
import json
import re
import zipfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("train", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    train, out = args.train.resolve(strict=True), args.out.resolve(strict=True)
    campaign = train / "outcome006/campaigns/learning008-pve-generalization-v1"
    budget = read(campaign / "budget.json")
    assert not budget["pending"] and budget["starts"] <= 8
    assert budget["wallMillis"] <= 5400000 and budget["collectionWallMillis"] <= 3600000
    slots = []
    for directory in sorted(campaign.glob("slot-*")):
        row = {"directory": directory.name}
        for name in ("reserved", "precut", "result", "terminal", "settlement", "selection"):
            path = directory / (name + ".json")
            if path.is_file():
                row[name] = read(path)
        slots.append(row)
    save(out / "collection008-slots.json", slots)
    arms = {}
    pairs = {}
    for phase in ("evaluate-v1", "control-v1"):
        directory = train / "outcome006/evaluation008" / phase
        rows = []
        for path in sorted(directory.glob("*.json")):
            if re.fullmatch("[0-9a-f]{64}", path.stem):
                rows.append(read(path))
        arms[phase] = rows
        pairs[phase] = [read(path) for path in sorted(directory.glob("*.pair.json"))]
        save(out / (phase + "-arms.json"), rows)
        save(out / (phase + "-pairs.json"), pairs[phase])
        save(out / (phase + "-summary.json"), read(directory / "summary.json"))
    native = []
    timing = []
    counters = collections.defaultdict(collections.Counter)
    for directory in sorted((train / "attempts").iterdir()):
        unchanged = directory / "evaluation008.training-unchanged.json"
        eval_dir = directory / "evaluation008"
        # A native collection attempt owns at least one reserved slot.
        reserved_text = json.dumps([row.get("reserved", {}) for row in slots])
        owned = directory.name in reserved_text or unchanged.is_file()
        if not owned:
            continue
        entry = {"attemptId": directory.name}
        for name in ("native-resources.json", "exit.json", "evaluation008.training-unchanged.json"):
            path = directory / name
            if path.is_file():
                entry[name] = read(path)
        if unchanged.is_file():
            assert entry["evaluation008.training-unchanged.json"]["equal"]
        native.append(entry)
        for path in sorted(eval_dir.glob("*/policy-diagnostics.json")):
            diagnostic = read(path)
            class_id = int(re.search(r"class(\d+)", path.parent.name)[1])
            phase = "CONTROL" if directory.name == "6866f35a85644ee09428d0de46b31f8a" else "EVAL"
            counters[(phase, class_id)].update(diagnostic["counters"])
            text = (path.parent / "policy-timing.txt").read_text(encoding="utf-8-sig")
            for metric, fields in re.findall(r"(\w+)=\{([^}]+)\}", text):
                values = {key: int(value) for key, value in re.findall(r"(\w+):(\d+)", fields)}
                timing.append({"phase": phase, "classId": class_id, "arm": path.parent.name,
                               "metric": metric, **values})
    save(out / "native008-resources.json", native)
    save(out / "policy008-timing.json", timing)
    save(out / "policy008-counters.json", [
        {"phase": phase, "classId": cid, "counters": dict(count)}
        for (phase, cid), count in sorted(counters.items())])
    before = train / "tactical-v3-exports/model-2-a85a9a76fed0446c9a5481c13ff5950e.zip"
    after = train / "tactical-v3-exports/model-2-d2b3039e74824456b7e19b84393ce54e.zip"
    comparison = {"beforeExportSha": sha(before.read_bytes()), "afterExportSha": sha(after.read_bytes()), "entries": []}
    checkpoint = out / "checkpoint"
    checkpoint.mkdir(exist_ok=True)
    with zipfile.ZipFile(before) as left, zipfile.ZipFile(after) as right:
        for name in left.namelist():
            if any(key in name for key in ("working", "optimizer", "residual", "application", "label", "manifest")):
                a, b = left.read(name), right.read(name)
                item = {"entry": name, "beforeSha": sha(a), "afterSha": sha(b), "equal": a == b, "bytes": len(b)}
                comparison["entries"].append(item)
                if "manifest" not in name:
                    assert item["equal"], item
                safe = Path(name)
                assert not safe.is_absolute() and ".." not in safe.parts
                destination = checkpoint / safe
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(b)
    assert comparison["entries"]
    save(out / "posteval-cold-comparison.json", comparison)
    save(out / "budget008-final.json", budget)
    coverage = collections.defaultdict(lambda: collections.Counter())
    collection_policy = collections.Counter()
    for row in slots:
        reserved, result = row["reserved"], row.get("result", {})
        count = coverage[(reserved["split"], reserved["classId"])]
        count["attempted"] += 1
        count[result.get("outcome", "NO_RESULT")] += 1
        count["paidRawEffects"] += result.get("paidRawEffects", 0)
        collection_policy.update(result.get("policyDiagnostics", {}).get("counters", {}))
    summary = {"coverage": [{"split": split, "classId": cid, **dict(count)}
                             for (split, cid), count in sorted(coverage.items())],
               "collectionPolicyCounters": dict(collection_policy),
               "nativeCpuSeconds": sum(row["native-resources.json"]["cpuSeconds"] for row in native),
               "nativePeakWorkingSetBytes": max(row["native-resources.json"]["peakWorkingSetBytes"] for row in native),
               "timing": [], "outcomes": []}
    for phase in ("EVAL", "CONTROL"):
        for cid in (94, 103, 110, 105):
            rows = [row for row in timing if row["phase"] == phase and row["classId"] == cid
                    and row["metric"] == "totalNanos" and row["n"]]
            if rows:
                summary["timing"].append({"phase": phase, "classId": cid,
                    "n": sum(row["n"] for row in rows),
                    **{"worstArm_" + key: max(row[key] for row in rows) for key in ("p50", "p95", "p99", "max")}})
    for phase, rows in arms.items():
        for row in rows:
            summary["outcomes"].append({"phase": phase, "pairId": row["pairId"],
                "side": row["side"], "outcome": row["outcome"], "reason": row["reason"],
                "elapsedMillis": row["elapsedMillis"], "metrics": row["metrics"],
                "effects": len(row["effects"]), "kills": len(row["kills"])})
    save(out / "report008-facts.json", summary)
    print(json.dumps({"slots": len(slots), "arms": {k: len(v) for k, v in arms.items()},
                      "nativeAttempts": len(native), "budget": budget,
                      "coldCompared": len(comparison["entries"])}, indent=2))


if __name__ == "__main__":
    main()
