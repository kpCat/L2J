import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.ZipFile;
import org.l2jmobius.gameserver.phantoms.learning.*;

/** Read-only exported-data report. Uses the actual public008 codec and forecast; never fits or opens SQL. */
public class AnalyzeFrozen008
{
    static String q(String value)
    {
        if (!value.matches("[A-Za-z0-9_-]+")) { throw new IllegalArgumentException("Expected bounded export identity"); }
        return "\"" + value + "\"";
    }
    static String field(String json, String name)
    {
        var match = java.util.regex.Pattern.compile("\"" + name + "\"\\s*:\\s*\"([^\"]+)\"").matcher(json);
        if (!match.find()) { throw new IllegalArgumentException("Missing export field " + name); }
        String value = match.group(1); if (match.find()) { throw new IllegalArgumentException("Duplicate export field " + name); } return value;
    }
    static float[] features(TacticalStoreV3.Row row)
    {
        var a = row.receipt().attempt(); var result = Arrays.copyOf(a.observation().state(), 192);
        System.arraycopy(a.baseline().features(a.observation()), 0, result, 128, 64); return result;
    }
    public static void main(String[] args) throws Exception
    {
        if (args.length != 2) { throw new IllegalArgumentException("Expected frozen008 export ZIP and output JSON"); }
        try (var zip = new ZipFile(args[0]))
        {
            String manifest = new String(zip.getInputStream(zip.getEntry("manifest.json")).readAllBytes(), StandardCharsets.UTF_8);
            byte[] bytes = zip.getInputStream(zip.getEntry("residual-targets.bin")).readAllBytes();
            var frozen = ActionAdvantage008.restore(field(manifest, "workingRunId"), bytes, field(manifest, "residualDatasetSha"));
            var controls = new ArrayList<ActionAdvantage008.Control>();
            for (var s : frozen.samples()) { if (s.selection().split().equals("TRAIN") && !s.selection().experimental())
            {
                var row = s.row(); controls.add(new ActionAdvantage008.Control(s.terminal().naturalKey(), s.context(row), s.selection().block(), "TRAIN", s.selection().observation().self().classId(), features(row), s.utility(row)));
            }}
            var rows = new ArrayList<String>(); var groups = new ArrayList<String>();
            for (String split : List.of("TUNING", "AUDIT")) { for (int classId : List.of(94, 103, 110))
            {
                var distances = new ArrayList<Double>();
                for (var s : frozen.samples()) { if (s.selection().split().equals(split) && s.selection().observation().self().classId() == classId)
                {
                    var forecast = ActionAdvantage008.baseline(controls, "", features(s.row()));
                    var target = frozen.targets().stream().filter(t -> t.sample().terminal().naturalKey().equals(s.terminal().naturalKey()) && s.selection().matches(t.row().receipt())).findFirst().orElseThrow();
                    if (!target.baselineSha().equals(forecast.sourceSha()) || Math.abs(target.baseline() - forecast.value()) > 0.000001) { throw new IllegalArgumentException("Frozen held-out forecast differs"); }
                    distances.add(forecast.nearestSquaredDistance());
                    rows.add("{\"episode\":" + q(s.terminal().episode().id()) + ",\"split\":" + q(split) + ",\"classId\":" + classId + ",\"nearestTrainNormalizedSquaredDistance\":" + forecast.nearestSquaredDistance() + ",\"trainControls\":" + forecast.controls() + ",\"exactTrainCells\":" + forecast.cells() + ",\"sourceSha\":" + q(forecast.sourceSha()) + "}");
                }}
                if (!distances.isEmpty()) { groups.add("{\"split\":" + q(split) + ",\"classId\":" + classId + ",\"independentEpisodes\":" + distances.size() + ",\"meanDistance\":" + distances.stream().mapToDouble(Double::doubleValue).average().orElseThrow() + ",\"maximumDistance\":" + distances.stream().mapToDouble(Double::doubleValue).max().orElseThrow() + "}"); }
            }}
            String report = "{\"schemaVersion\":8,\"targetSha\":" + q(frozen.datasetSha()) + ",\"unit\":\"mean squared distance over existing state128+stockAction64\",\"trainOnlyControls\":" + controls.size() + ",\"heldOutForecastRecomputation\":\"EXACT_WITH_FLOAT_SERIALIZATION_TOLERANCE_1e-6\",\"thresholdSelected\":false,\"trainingCredit\":false,\"groups\":[" + String.join(",", groups) + "],\"episodes\":[" + String.join(",", rows) + "],\"limitation\":\"Feature distance is descriptive; it does not validate causal stock counterfactuals or gameplay superiority\"}";
            Files.writeString(Path.of(args[1]), report + "\n", StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
            System.out.println("FROZEN008_OOD episodes=" + rows.size() + " controls=" + controls.size() + " target=" + frozen.datasetSha() + " SQL=false fit=false");
        }
    }
}
