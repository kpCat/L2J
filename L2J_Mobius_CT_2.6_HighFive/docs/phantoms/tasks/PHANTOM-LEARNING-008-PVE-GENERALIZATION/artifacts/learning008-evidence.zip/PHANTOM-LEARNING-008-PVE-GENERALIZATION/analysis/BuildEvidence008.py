"""Write delivery metadata from existing read-only 008 results."""
import argparse
import hashlib
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("scratch", type=Path)
    parser.add_argument("module", type=Path)
    args = parser.parse_args()
    scratch, module = args.scratch.resolve(strict=True), args.module.resolve(strict=True)
    evidence = scratch / "evidence"
    plan = (scratch / "PLAN.md").read_text(encoding="utf-8-sig")
    paths = plan.split("SCOPE_ALLOWLIST_BEGIN\n", 1)[1].split("SCOPE_ALLOWLIST_END", 1)[0].splitlines()
    assert len(paths) == 27 and len(set(paths)) == 27
    sources = []
    for path in paths[:16]:
        data = (module / path).read_bytes()
        normalized = data.replace(b'\r\n', b'\n')
        def blob_sha(value):
            return hashlib.sha1(b'blob ' + str(len(value)).encode('ascii') + b'\0' + value).hexdigest()
        sources.append({"path": path, "sha256": hashlib.sha256(data).hexdigest(),
                        "rawGitBlobSha1": blob_sha(data), "lfGitBlobSha1": blob_sha(normalized)})
    (evidence / "source008-hashes.json").write_text(json.dumps(sources, indent=2) + "\n", encoding="utf-8")
    training = read(evidence / "training008.json")
    offline = read(evidence / "offline-model12.json")
    result = {
        "goal": "PHANTOM-LEARNING-008-PVE-GENERALIZATION",
        "status": "PARTIAL", "reason": "NO_TUNING_CHECKPOINT_IMPROVEMENT",
        "goalComplete": False, "finalManualGate": "REQUIRED",
        "designOwnerApproval": "APPROVED_EXPLICIT_USER_REPLY",
        "baselineCommit": "062862eca8e0bcedd4107d7b91720627307f736c",
        "branch": "wip/phantom-learning-008",
        "initialRemoteFeature": "7e997636dbac9d5e1754e00c793cd6fac858b0c6",
        "commonAncestor": "dfcba154fa1f459be6082a559744d2b4a5c9b47a",
        "sourceScope": sources, "exactAllowlist": paths,
        "trainClasses": [94, 103], "unseenAuditClass": 110, "healRegressionClass": 105,
        "plannedCollectionAttempts": 48, "completedCollectionEpisodes": 42,
        "preCutFailures": 2, "incompleteEpisodes": 4,
        "gradientEpisodes": 12, "gradientActionTargets": 24,
        "gradientTargetsByClass": {"94": 14, "103": 10, "110": 0, "105": 0},
        "applicationMarkers": {"total": 42, "gradient": 12, "baseline": 13, "heldOut": 16, "excluded": 1},
        "teacher11Sha": "7de6f5b6bd51f71a8bfce143422139e6b18da44cf81e6ea81f91728b0da206d0",
        "selectedModel12Sha": training["candidateSha"], "selectedEpoch": 0,
        "selectedEqualsParentTerminalWeights": True,
        "training": training, "offlineReadback": offline,
        "same008LabelsComparisonOnly": True, "newGradientCausalAdvantageProven": False,
        "evaluation": read(evidence / "evaluate-v1-summary.json"),
        "stockControls": read(evidence / "control-v1-summary.json"),
        "budget": read(evidence / "budget008-final.json"),
        "nativeCeilings": {"starts": 8, "wallMinutes": 90, "collectionMinutes": 60},
        "gameVerdict": "INCONCLUSIVE", "productionPromotion": False,
        "postEvalColdComparison": read(evidence / "posteval-cold-comparison.json"),
        "tests": {"finalAnt008007JarExit": 0, "existingFocusedRegressions": 10,
                  "existingFocusedRegressionsExit": 0, "ownerFinalPreflightExit": 0,
                  "newFaultInjection": "NOT_RUN_SHARED_TRANSACTION_UNCHANGED"},
        "processDeviation": "Case-sensitive read-first inventory missed server Agents.md; read and corrected before delivery",
        "runtimeFinalState": "STOPPED_PORTS_FREE",
        "stoppedProof": read(evidence / "final-stopped-director.json"),
        "portsProof": read(evidence / "final-ports.json"),
        "validation": read(evidence / "final-scope-encoding.json"),
        "publication": {"state": "REQUIRED"},
        "taskBudget": {"historicalIssued001Through006R1": 7, "accepted007TaskWithin13": 1,
                       "current008TaskWithin13": 2, "remainingUntilReview": 11,
                       "partialAndFixTasksConsumeBudget": True},
    }
    if (evidence / "archive-receipt.json").is_file():
        result["archive"] = read(evidence / "archive-receipt.json")
    (scratch / "EVIDENCE.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"sourcePaths": len(sources), "allowlistPaths": len(paths),
                      "status": result["status"], "model": training["candidateVersion"]}))


if __name__ == "__main__":
    main()
