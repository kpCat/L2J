param([Parameter(Mandatory)][string]$TestRepo)
$ErrorActionPreference = 'Stop'
$modulePath = Join-Path $TestRepo 'L2J_Mobius_CT_2.6_HighFive'
$javaPath = 'C:\Program Files\Eclipse Adoptium\jdk-25.0.4.101-hotspot\bin\java.exe'
$classPath = @((Join-Path $TestRepo 'build\bin'), (Join-Path $TestRepo 'build\phantom-test\bin'), (Join-Path $TestRepo 'build\phantom-test\resources'), (Join-Path $modulePath 'dist\libs\*')) -join ';'
$cases = @(
    ,@('org.l2jmobius.tests.phantoms.PhantomLearning004Schema', $modulePath)
    ,@('org.l2jmobius.tests.phantoms.PhantomLearning004ModelChecks')
    ,@('org.l2jmobius.tests.phantoms.PhantomLearning005Checks')
    ,@('org.l2jmobius.gameserver.phantoms.learning.Learning006OutcomeChecks', 'contracts')
    ,@('org.l2jmobius.tests.phantoms.PhantomLearning006Checks', 'clock-r1')
    ,@('org.l2jmobius.tests.phantoms.PhantomLearning006Checks', 'heal-totals-r1')
    ,@('org.l2jmobius.tests.phantoms.PhantomLearning006Checks', 'authority-r1')
    ,@('org.l2jmobius.tests.phantoms.PhantomLearning006Checks', 'campaign-r1')
    ,@('org.l2jmobius.tests.phantoms.PhantomLearning006Checks', 'boundaries')
    ,@('org.l2jmobius.tests.phantoms.PhantomLearning006Checks', 'routing-r1', $modulePath)
)
foreach ($case in $cases) {
    Write-Output ('RUN ' + ($case -join ' '))
    & $javaPath -cp $classPath @case
    if ($LASTEXITCODE -ne 0) { throw ('Focused regression failed: ' + ($case -join ' ')) }
    Write-Output 'EXIT 0'
}
