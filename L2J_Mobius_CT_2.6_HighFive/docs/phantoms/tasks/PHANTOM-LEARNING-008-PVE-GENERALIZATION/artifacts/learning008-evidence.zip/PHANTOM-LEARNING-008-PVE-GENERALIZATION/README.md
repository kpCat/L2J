# PHANTOM-LEARNING-008

`/goal PHANTOM-LEARNING-008-PVE-GENERALIZATION`

PARTIAL / NO_TUNING_CHECKPOINT_IMPROVEMENT; game INCONCLUSIVE; manual gate REQUIRED.
Selected DRAFT12 is epoch0 / parent terminal Adam11 weights. No promotion.
Native receipts are observations, never synthetic counterfactuals.
analysis/checkpoint contains selected weights, exact optimizer, frozen targets, labels and applications.
native contains all reserved collection attempts including failures, plus EVAL/control ledgers.
No Geo, SQL dump, credentials, full repository, or large private logs.
MANIFEST.json authenticates every other entry by SHA-256.
