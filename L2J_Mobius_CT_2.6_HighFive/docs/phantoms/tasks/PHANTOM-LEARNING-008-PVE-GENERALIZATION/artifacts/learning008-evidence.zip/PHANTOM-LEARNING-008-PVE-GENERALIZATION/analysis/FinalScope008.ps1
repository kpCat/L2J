param([Parameter(Mandatory)][string]$TestRepo,[Parameter(Mandatory)][string]$Scratch)
$ErrorActionPreference='Stop'
$planText=Get-Content -LiteralPath (Join-Path $Scratch 'PLAN.md') -Raw
$scopeText=($planText -split 'SCOPE_ALLOWLIST_BEGIN\r?\n',2)[1] -split 'SCOPE_ALLOWLIST_END',2
$relativePaths=@($scopeText[0] -split '\r?\n' | Where-Object { $_ })
if($relativePaths.Count -ne 27){throw 'Exact 27-path allowlist required'}
$moduleName='L2J_Mobius_CT_2.6_HighFive'
$gitPaths=@($relativePaths | ForEach-Object { $moduleName+'/'+$_ })
$modulePath=Join-Path $TestRepo $moduleName
$textPaths=@($relativePaths | Where-Object {$_ -notlike '*.zip'} | ForEach-Object { Join-Path $modulePath $_ })
$evidencePath=Join-Path $Scratch 'evidence'
Push-Location -LiteralPath $TestRepo
try {
    $rootStatus=@(& git status --short --untracked-files=normal)
    if($LASTEXITCODE -ne 0){throw 'Root status failed'}
    $rootStatus | Set-Content -LiteralPath (Join-Path $evidencePath 'final-root-status.txt') -Encoding utf8
    foreach($line in $rootStatus){
        if($line.Substring(3) -eq '.phantom-local/'){continue}
        if(-not $line.Substring(3).StartsWith($moduleName+'/')){throw ('Unexpected root scope: '+$line)}
    }
    $scopeStatus=@(& git status --short --untracked-files=all -- $moduleName)
    if($LASTEXITCODE -ne 0){throw 'Module status failed'}
    $scopeStatus | Set-Content -LiteralPath (Join-Path $evidencePath 'final-scope-status.txt') -Encoding utf8
    foreach($line in $scopeStatus){if($line.Substring(3) -notin $gitPaths){throw ('Unexpected changed path: '+$line)}}
    if($scopeStatus.Count -ne 27){throw ('Expected exactly 27 changed paths: '+$scopeStatus.Count)}
    & git diff --check -- @gitPaths
    if($LASTEXITCODE -ne 0){throw 'Exact diff whitespace check failed'}
    & git diff -- @gitPaths | Set-Content -LiteralPath (Join-Path $evidencePath 'final-exact-diff.txt') -Encoding utf8
    if($LASTEXITCODE -ne 0){throw 'Exact diff readback failed'}
} finally {Pop-Location}
$markers=@'
Рџ|Рќ|Рћ|Р•|РЎ|Р›|Р¤|Рњ|РЈ|Рљ|Рґ|Рµ|Р°|Р»|РЅ|Рѕ|СЏ|С€|СЂ|С‹|СЊ|С‚|Сѓ|С‡|С…|С†|�
'@
& rg -n -- $markers @textPaths *> (Join-Path $evidencePath 'encoding-mojibake.log')
$mojibakeExit=$LASTEXITCODE
if($mojibakeExit -ne 1){throw ('Mojibake matches or read error: '+$mojibakeExit)}
$escaped='\\u04[0-9A-Fa-f]{2}|\\u05[0-9A-Fa-f]{2}|&#x04[0-9A-Fa-f]{2};|&#x05[0-9A-Fa-f]{2};|&#X04[0-9A-Fa-f]{2};|&#X05[0-9A-Fa-f]{2};'
& rg -n -- $escaped @textPaths *> (Join-Path $evidencePath 'encoding-escaped-cyrillic.log')
$escapedExit=$LASTEXITCODE
if($escapedExit -ne 1){throw ('Escaped Cyrillic matches or read error: '+$escapedExit)}
$commands=@(
    ,@('git','status','--short','--untracked-files=normal')
    ,@('git','status','--short','--untracked-files=all','--',$moduleName)
    ,(@('git','diff','--check','--')+$gitPaths)
    ,(@('git','diff','--')+$gitPaths)
)
[ordered]@{allowlistPaths=27;changedPaths=$scopeStatus.Count;textFiles=26;mojibakeRgExit=$mojibakeExit;escapedCyrillicRgExit=$escapedExit;gitCwd=$TestRepo;gitArgv=$commands;status='PASS'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $evidencePath 'final-scope-encoding.json') -Encoding utf8
Write-Output 'Exact27-path scope PASS; mojibake PASS; escaped Cyrillic PASS.'
exit 0
