"""Package existing bounded 008 receipts; never include SQL, Geo, or runtime config."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("train", type=Path)
    parser.add_argument("evidence", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    train = args.train.resolve(strict=True)
    evidence = args.evidence.resolve(strict=True)
    destination = args.destination.resolve()
    entries = {}
    root = "PHANTOM-LEARNING-008-PVE-GENERALIZATION/"

    def add(path, name):
        data = path.read_bytes()
        assert len(data) < 16 * 1024 * 1024, str(path)
        assert name not in entries
        entries[name] = data

    for path in sorted(evidence.rglob("*")):
        if not path.is_file() or path.name == "DiagnoseFit008.java":
            continue
        if path.name.startswith(("publication", "archive-receipt")):
            continue
        add(path, "analysis/" + path.relative_to(evidence).as_posix())
    campaign = train / "outcome006/campaigns/learning008-pve-generalization-v1"
    for path in sorted(campaign.rglob("*")):
        if path.is_file() and path.suffix in (".json", ".jsonl", ".bin", ".tsv"):
            add(path, "native/collection/" + path.relative_to(campaign).as_posix())
    capability = train / "game/data/phantoms/progression/learning008-capabilities.xml"
    add(capability, "native/learning008-capabilities.xml")
    for phase in ("evaluate-v1", "control-v1"):
        directory = train / "outcome006/evaluation008" / phase
        for path in sorted(directory.glob("*")):
            if path.is_file() and path.suffix in (".json", ".bin"):
                add(path, "native/" + phase + "/" + path.name)
    resources = json.loads((evidence / "native008-resources.json").read_text(encoding="utf-8"))
    for row in resources:
        attempt = train / "attempts" / row["attemptId"]
        for path in sorted((attempt / "evaluation008").rglob("*")):
            if path.is_file() and path.suffix in (".json", ".bin", ".tsv", ".txt"):
                add(path, "native/attempts/" + row["attemptId"] + "/" + path.relative_to(attempt).as_posix())
    entries["README.md"] = (
        "# PHANTOM-LEARNING-008\n\n"
        "`/goal PHANTOM-LEARNING-008-PVE-GENERALIZATION`\n\n"
        "PARTIAL / NO_TUNING_CHECKPOINT_IMPROVEMENT; game INCONCLUSIVE; manual gate REQUIRED.\n"
        "Selected DRAFT12 is epoch0 / parent terminal Adam11 weights. No promotion.\n"
        "Native receipts are observations, never synthetic counterfactuals.\n"
        "analysis/checkpoint contains selected weights, exact optimizer, frozen targets, labels and applications.\n"
        "native contains all reserved collection attempts including failures, plus EVAL/control ledgers.\n"
        "No Geo, SQL dump, credentials, full repository, or large private logs.\n"
        "MANIFEST.json authenticates every other entry by SHA-256.\n"
    ).encode("utf-8")
    manifest = {"goal": "PHANTOM-LEARNING-008-PVE-GENERALIZATION", "entries": [
        {"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        for name, data in sorted(entries.items())]}
    entries["MANIFEST.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(entries.items()):
            archive.writestr(root + name, data)
    with zipfile.ZipFile(temporary) as archive:
        assert archive.testzip() is None
        for item in manifest["entries"]:
            data = archive.read(root + item["path"])
            assert len(data) == item["bytes"] and hashlib.sha256(data).hexdigest() == item["sha256"]
    temporary.replace(destination)
    receipt = {"archiveSha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
               "archiveBytes": destination.stat().st_size, "entries": len(entries),
               "manifestVerified": True, "path": str(destination)}
    (evidence / "archive-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
