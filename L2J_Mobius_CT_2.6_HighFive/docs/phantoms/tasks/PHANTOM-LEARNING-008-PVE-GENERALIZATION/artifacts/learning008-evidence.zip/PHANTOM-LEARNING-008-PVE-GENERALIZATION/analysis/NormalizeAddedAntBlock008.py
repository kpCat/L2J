import sys
from pathlib import Path

path = Path(sys.argv[1])
data = path.read_bytes()
start = data.index(b'\t<target name="phantom-learning008-test"')
end = data.index(b'\t</target>', start) + len(b'\t</target>')
end = data.index(b'\n', end) + 1
if data[end:end + 2] == b'\r\n':
    end += 2
block = data[start:end]
assert block.count(b'\r\n') == 21
result = data[:start] + block.replace(b'\r\n', b'\n') + data[end:]
path.write_bytes(result)
print('Only new Ant008 block: 21 CRLF changed to LF; surrounding bytes unchanged.')
