import java.nio.file.*;
import java.util.*;
import org.l2jmobius.gameserver.phantoms.learning.*;

/** File-only canonical decoder, following the existing007 evidence helper pattern. Never opens SQL or fits. */
public class InspectCampaign008
{
    public static void main(String[] args) throws Exception
    {
        if (args.length != 1) { throw new IllegalArgumentException("Expected owned008 campaign directory"); }
        Path root = Path.of(args[0]); var samples = new ArrayList<ActionAdvantage008.Sample>();
        try (var slots = Files.list(root))
        {
            for (var slot : slots.filter(p -> p.getFileName().toString().matches("slot-\\d{3}")).sorted().toList())
            {
                Path terminal = slot.resolve("terminal.bin"); if (!Files.exists(terminal)) { continue; }
                byte[] bytes = Files.readAllBytes(terminal); var receipt = TerminalRewardReceiptV1.restore(bytes, NeuralPolicy.sha256(bytes));
                Path selected = root.resolve("samples/" + receipt.episode().id() + ".selection.bin"); if (!Files.exists(selected)) { continue; }
                var selection = TrainExplorationV1.Selection.restore(Files.readAllBytes(selected)); if (!selection.fallback().isEmpty()) { continue; }
                if (receipt.actions().stream().filter(a -> selection.matches(a.row().receipt())).count() != 1) { System.out.println("INITIAL_PAID_MISMATCH " + slot.getFileName()); continue; }
                var sample = new ActionAdvantage008.Sample(selection, receipt); samples.add(sample);
                System.out.println("SAMPLE " + slot.getFileName() + " class=" + selection.observation().self().classId() + " split=" + selection.split() + " B=" + selection.experimental() + " p=" + selection.propensity());
            }
        }
        try
        {
            var frozen = ActionAdvantage008.freeze("8".repeat(32), samples);
            System.out.println("FROZEN samples=" + samples.size() + " targets=" + frozen.targets().size() + " sufficient=" + frozen.sufficient());
            System.out.println(frozen.metrics());
        }
        catch (IllegalArgumentException failure) { failure.printStackTrace(System.out); System.exit(2); }
    }
}
