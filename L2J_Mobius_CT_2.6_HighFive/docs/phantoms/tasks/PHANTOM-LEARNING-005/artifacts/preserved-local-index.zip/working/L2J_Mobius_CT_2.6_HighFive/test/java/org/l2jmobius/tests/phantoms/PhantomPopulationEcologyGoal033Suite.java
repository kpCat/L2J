/*
 * Copyright (c) 2013 L2jMobius
 */
package org.l2jmobius.tests.phantoms;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import org.l2jmobius.gameserver.config.custom.PhantomPlayersConfig;
import org.l2jmobius.gameserver.phantoms.activity.PhantomActivityState;
import org.l2jmobius.gameserver.phantoms.background.PhantomBackgroundCatchupState;
import org.l2jmobius.gameserver.phantoms.background.PhantomBackgroundCatchupState.Status;
import org.l2jmobius.gameserver.phantoms.background.PhantomBackgroundCatchupStore.Snapshot;
import org.l2jmobius.gameserver.phantoms.background.PhantomBackgroundState;
import org.l2jmobius.gameserver.phantoms.background.PhantomHistoricalBackgroundService;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationCatalog;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationEcologyCatalog;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationEcologyCatalog.PresetDefinition;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationEcologyService;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationEcologyService.HistoricalPort;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationEcologyService.PersistencePort;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationEcologyState;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationEcologyState.Disposition;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationEcologyState.Pace;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationEcologyState.Personality;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationEcologyState.Preset;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationEcologyStateCodec;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationEcologyStore.ArchivedResult;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationEcologyStore.StoredState;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationManager;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationState;
import org.l2jmobius.gameserver.phantoms.population.PhantomPopulationStore.ManagedSnapshot;
import org.l2jmobius.gameserver.phantoms.profile.PhantomProfileComponent;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialCatalog;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialModel;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialService;

/** Focused deterministic Goal033 ecology contract gate. It does not touch a DB. */
public final class PhantomPopulationEcologyGoal033Suite implements PhantomTestSuite
{
	private static final long SEED = 33003300L;
	private static final long MINUTE_MILLIS = 60_000L;
	private static final Instant CREATED = Instant.parse("2026-01-01T00:00:00Z");
	private PhantomPopulationCatalog _population;
	private PhantomSocialCatalog _social;
	private PhantomPopulationEcologyCatalog _ecology;
	private final boolean _handoffOnly;

	public PhantomPopulationEcologyGoal033Suite() { this(false); }
	public PhantomPopulationEcologyGoal033Suite(boolean handoffOnly) { _handoffOnly = handoffOnly; }

	@Override
	public String id()
	{
		return "population-ecology-goal033";
	}

	@Override
	public void beforeAll(PhantomTestContext context)
	{
		PhantomAssertions.assertEquals(SEED, context.seed(), "Goal033 deterministic seed changed.");
		_population = PhantomPopulationCatalog.load(context.moduleRoot().resolve("dist/game/data/phantoms/population/high-five-population-v1.xml"), ZoneOffset.UTC);
		_social = PhantomSocialCatalog.load(context.moduleRoot().resolve("dist/game/data/phantoms/social/high-five-social-v1.xml"));
		_ecology = PhantomPopulationEcologyCatalog.load(context.moduleRoot().resolve("dist/game/data/phantoms/population/high-five-ecology-v1.xml"), _population, _social);
	}

	@Override
	public void register(PhantomTestRegistry registry)
	{
<<<<<<< Updated upstream
		if (System.getProperty("phantom.m1.native.focus", "").equals("boundaries122"))
		{
			registry.add("28-preparation-capacity-preserves-stop-owner", this::testPreparationStopReason122);
			registry.add("26-live-history-reports-owner-not-capacity", this::testLiveOwnerReason113);
			registry.add("18-native-context-releases-only-materialization-gate", this::testNativeMaterializationReadiness);
			return;
		}
		if (System.getProperty("phantom.m1.native.focus", "").equals("continuity113"))
		{
			registry.add("14-periodic-cursor-materialized-boundary-and-resume", this::testPeriodicMaterializedBoundary);
			registry.add("18-native-context-releases-only-materialization-gate", this::testNativeMaterializationReadiness);
			registry.add("25-cold-focus-does-not-starve-released-history", this::testColdFocusRelease113);
			registry.add("26-live-history-reports-owner-not-capacity", this::testLiveOwnerReason113);
			registry.add("27-large-debt-and-5000-identity-queue-model", this::testColdQueueModel113);
			return;
		}
=======
>>>>>>> Stashed changes
		if (System.getProperty("phantom.m1.native.focus", "").equals("stop075"))
		{
			registry.add("22-stop-settles-live-tail-before-downtime-once", this::testStopLiveTail075);
			registry.add("23-stop-retries-cas-without-clock-regression", this::testStopCursorConflict075);
			registry.add("24-stop-batches-preserve-pending-history", this::testStopPendingHistory075);
			return;
		}
		if (System.getProperty("phantom.m1.native.focus", "").equals("releasedMinute052"))
		{
			registry.add("20-native-release-priority-survives-minute-refresh", this::testNativeReleaseAcrossMinute);
			return;
		}
		if (_handoffOnly)
		{
			registry.add("12-background-due-reconciles-elapsed-cursor-once", this::testBackgroundDueReconciliation);
			registry.add("13-periodic-due-crash-before-and-after-durable-commit", this::testPeriodicDueCrashRecovery);
			registry.add("14-periodic-cursor-materialized-boundary-and-resume", this::testPeriodicMaterializedBoundary);
			registry.add("15-stale-authority-renews-current-request", this::testStaleAuthorityRenewal);
			registry.add("16-incomplete-periodic-due-continues-under-pulse-budgets", this::testIncompletePeriodicDueContinues);
			registry.add("17-restored-inventory-readiness-starts-bounded-target-creation", this::testRestoredInventoryReadinessStartsCreation);
			return;
		}
		registry.add("01-strict-catalog-config-and-codec", this::testCatalogConfigAndCodec);
		registry.add("02-low-discrepancy-and-human-independence", this::testAssignmentAndHumanIndependence);
		registry.add("03-pace-and-schedule-causal-time", this::testPaceAndSchedule);
		registry.add("04-bounded-calendar-restart-and-ongoing", this::testCalendarRestartAndOngoing);
		registry.add("05-safe-turnover-replacement-and-cap", this::testTurnoverAndCap);
		registry.add("06-personality-new-state-only", this::testPersonality);
		registry.add("07-production-architecture-static-fences", this::testStaticFences);
		registry.add("08-idle-calendar-catchup-reopens-schedule-fence", this::testIdleCalendarCatchupFence);
		registry.add("09-restart-existing-ecology-reopens-schedule-fences", this::testRestartExistingEcologyFences);
		registry.add("10-topology-block-quiet-and-resume", this::testTopologyBlockQuietAndResume);
		registry.add("11-transient-item-retry-has-shared-pulse-backoff", this::testTransientItemRetryBackoff);
		registry.add("12-background-due-reconciles-elapsed-cursor-once", this::testBackgroundDueReconciliation);
		registry.add("13-periodic-due-crash-before-and-after-durable-commit", this::testPeriodicDueCrashRecovery);
		registry.add("14-periodic-cursor-materialized-boundary-and-resume", this::testPeriodicMaterializedBoundary);
		registry.add("15-stale-authority-renews-current-request", this::testStaleAuthorityRenewal);
		registry.add("16-incomplete-periodic-due-continues-under-pulse-budgets", this::testIncompletePeriodicDueContinues);
		registry.add("17-restored-inventory-readiness-starts-bounded-target-creation", this::testRestoredInventoryReadinessStartsCreation);
		registry.add("18-native-context-releases-only-materialization-gate", this::testNativeMaterializationReadiness);
		registry.add("19-live-capacity-release-catchup-reopens-current-admission", this::testLiveCapacityReleaseAdmission);
		registry.add("20-native-release-priority-survives-minute-refresh", this::testNativeReleaseAcrossMinute);
		registry.add("21-native-context-before-new-history-claim", this::testNativeContextBeforeClaim061);
		registry.add("22-stop-settles-live-tail-before-downtime-once", this::testStopLiveTail075);
		registry.add("23-stop-retries-cas-without-clock-regression", this::testStopCursorConflict075);
		registry.add("24-stop-batches-preserve-pending-history", this::testStopPendingHistory075);
<<<<<<< Updated upstream
		registry.add("25-cold-focus-does-not-starve-released-history", this::testColdFocusRelease113);
		registry.add("26-live-history-reports-owner-not-capacity", this::testLiveOwnerReason113);
		registry.add("27-large-debt-and-5000-identity-queue-model", this::testColdQueueModel113);
		registry.add("28-preparation-capacity-preserves-stop-owner", this::testPreparationStopReason122);
=======
>>>>>>> Stashed changes
		for (int control = 1; control <= 12; control++)
		{
			final int selected = control;
			registry.add("O%02d-orphan-ownership-contract".formatted(control), context -> testOrphanOwnership(context, selected));
		}
	}

<<<<<<< Updated upstream
	private void seedColdRequest113(PhantomPopulationTestDoubles.MemoryStore population, EcologyMemoryStore store, HistoricalMemoryPort history, long id, long from, long target)
	{
		final var ready = population.seedReady(id, Math.toIntExact(id));
		final var request = history.begin(id, from, target, id).snapshot();
		store.insert(id, new PhantomPopulationEcologyState(_ecology.hash(), Preset.LIVING, 1, id, target, from, from, target,
			Pace.OUTLIER, 10_000, _ecology.limits().productiveBlockMinutes(), Personality.BALANCED,
			Map.of(1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0), ready.state().scheduleTemplate(), Disposition.MANAGED,
			target + 10_000, 0, request.state().requestId(), target, 0, 0, ""));
	}

	private void testColdFocusRelease113(PhantomTestContext context)
	{
		final var now = Instant.parse("2026-01-20T20:30:00Z");
		final long target = minute(now), from = target - 23_000;
		final var population = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final var store = new EcologyMemoryStore(null);
		final var history = new HistoricalMemoryPort();
		for (long id = 1; id <= 3; id++) { seedColdRequest113(population, store, history, id, from, target); }
		final var live = new AtomicBoolean(true);
		final var service = new PhantomPopulationEcologyService(_ecology, _population, store, history, id -> id == 3 && live.get(), id -> "",
			new PhantomPopulationTestDoubles.MutableClock(now), ZoneOffset.UTC, Preset.LIVING, 0, 10, worker -> { worker.run(); return true; });
		service.installRuntime(id -> population.loadManagedAfter(id - 1, 1).stream().filter(actor -> actor.profile().profileId() == id).findFirst(), noEvents());
		for (long id = 1; id <= 3; id++) { service.register(population.loadManagedAfter(id - 1, 1).getFirst()); }
		loadMetadata(service, 3);
		final var focus = new PhantomPopulationEcologyService.DemandFact(1, 1, true, 1, 1);
		service.updateMaterializationDemand(List.of(focus, new PhantomPopulationEcologyService.DemandFact(3, 1, true, 1, 3)), 2);
		service.onPopulationPulse();
		PhantomAssertions.assertEquals(from, history.status(3).orElseThrow().state().cursorEpochMinute(), "Historical advance raced a live native owner.");
		service.updateMaterializationDemand(List.of(focus), 2);
		service.onPopulationPulse(); // Physical demand leaves before the native STORE releases its owner.
		live.set(false);
		service.updateMaterializationDemand(List.of(focus), 2);
		for (int batch = 0; batch < 8; batch++)
		{
			final long beforeFocus = history.status(1).orElseThrow().state().cursorEpochMinute();
			final long beforeOrdinary = history.status(2).orElseThrow().state().cursorEpochMinute();
			final long beforeRelease = history.status(3).orElseThrow().state().cursorEpochMinute();
			service.onPopulationPulse();
			PhantomAssertions.assertTrue(history.status(1).orElseThrow().state().cursorEpochMinute() > beforeFocus && history.status(2).orElseThrow().state().cursorEpochMinute() > beforeOrdinary, "Release priority starved focus or ordinary work: batch=" + batch);
			PhantomAssertions.assertTrue(history.status(3).orElseThrow().state().cursorEpochMinute() > beforeRelease, "Released request lost its bounded share: batch=" + batch);
		}
		for (long id = 1; id <= 3; id++)
		{
			PhantomAssertions.assertTrue(history.status(id).orElseThrow().state().cursorEpochMinute() > from,
				"Cold focus/ordinary debt starved a released historical owner: profile=" + id);
		}
		PhantomAssertions.assertTrue(service.snapshot().maximumPulseIntervals() <= 16 && service.snapshot().maximumPulseProfiles() <= 4, "Three queues exceeded the unchanged source budgets.");
		context.record("task113.threeQueueCursors", java.util.stream.LongStream.rangeClosed(1, 3).map(id -> history.status(id).orElseThrow().state().cursorEpochMinute() - from).boxed().toList());
		service.beginStop();
	}

	private void testLiveOwnerReason113(PhantomTestContext context)
	{
		final var now = Instant.parse("2026-01-20T20:30:00Z");
		final long target = minute(now), from = target - 23_000;
		final var population = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final var store = new EcologyMemoryStore(null);
		final var history = new HistoricalMemoryPort();
		seedColdRequest113(population, store, history, 1, from, target);
		final var original = store.require(1);
		final var request = history.status(1);
		final var service = service(store, history, new AtomicBoolean(true), new AtomicReference<>(""), new PhantomPopulationTestDoubles.MutableClock(now), Preset.LIVING, 0, 10);
		service.installRuntime(id -> population.loadManagedAfter(id - 1, 1).stream().filter(actor -> actor.profile().profileId() == id).findFirst(), noEvents()); service.register(population.loadManagedAfter(0, 1).getFirst()); loadMetadata(service, 1);
		service.updateMaterializationDemand(List.of(new PhantomPopulationEcologyService.DemandFact(1, 1, true, 1, 1)), 0);
		final var due = service.dueSnapshot(1);
		PhantomAssertions.assertEquals("ecology.live_owner", due.reason(), "A live pending native owner was misreported as preparation capacity.");
		PhantomAssertions.assertFalse(due.complete() || service.permitsScheduling(1), "Diagnostic owner reason weakened the historical fence.");
		PhantomAssertions.assertEquals(original, store.require(1), "Diagnostic snapshot wrote ecology.");
		PhantomAssertions.assertEquals(request, history.status(1), "Diagnostic snapshot wrote the historical request.");
		context.record("task113.liveOwner", due); service.beginStop();
		PhantomAssertions.assertEquals("ecology.stopping", service.dueSnapshot(1).reason(), "A live-owner diagnostic hid the STOP fence.");
	}

	private void testPreparationStopReason122(PhantomTestContext context)
	{
		final var now = Instant.parse("2026-01-20T20:30:00Z");
		final long target = minute(now), from = target - 23_000;
		final var population = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final var store = new EcologyMemoryStore(null);
		final var history = new HistoricalMemoryPort();
		seedColdRequest113(population, store, history, 1, from, target);
		final var original = store.require(1);
		final var request = history.status(1);
		final var service = service(store, history, new AtomicBoolean(), new AtomicReference<>(""), new PhantomPopulationTestDoubles.MutableClock(now), Preset.LIVING, 0, 10);
		service.installRuntime(id -> population.loadManagedAfter(id - 1, 1).stream().filter(actor -> actor.profile().profileId() == id).findFirst(), noEvents());
		service.register(population.loadManagedAfter(0, 1).getFirst()); loadMetadata(service, 1);
		service.updateMaterializationDemand(List.of(new PhantomPopulationEcologyService.DemandFact(1, 1, true, 1, 1)), 0);
		PhantomAssertions.assertEquals("ecology.preparation_capacity", service.dueSnapshot(1).reason(), "Zero preparation slots lost their selection reason.");
		service.beginStop();
		final var stopped = service.dueSnapshot(1);
		PhantomAssertions.assertEquals("ecology.stopping", stopped.reason(), "Preparation selection hid the STOP owner behind capacity.");
		PhantomAssertions.assertFalse(stopped.complete() || service.permitsScheduling(1), "STOP admitted historical work.");
		PhantomAssertions.assertEquals(original, store.require(1), "Capacity/STOP observation changed the durable ecology cursor.");
		PhantomAssertions.assertEquals(request, history.status(1), "Capacity/STOP observation changed the historical claim or receipt.");
		context.record("task122.preparationStop", stopped);
	}

	private void testColdQueueModel113(PhantomTestContext context)
	{
		final var now = Instant.parse("2026-01-20T20:30:00Z");
		final long target = minute(now);
		for (int count : List.of(2, 5000))
		{
			final var population = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
			final var store = new EcologyMemoryStore(null);
			final var history = new HistoricalMemoryPort();
			for (long id = 1; id <= count; id++) { seedColdRequest113(population, store, history, id, target - 23_000 - id, target); }
			final var service = service(store, history, new AtomicBoolean(), new AtomicReference<>(""), new PhantomPopulationTestDoubles.MutableClock(now), Preset.LIVING, 0, 10);
			service.installRuntime(id -> population.loadManagedAfter(id - 1, 1).stream().filter(actor -> actor.profile().profileId() == id).findFirst(), noEvents());
			for (long id = 1; id <= count; id++) { service.register(population.loadManagedAfter(id - 1, 1).getFirst()); }
			loadMetadata(service, count);
			final int batches = count == 2 ? 3000 : 5000;
			final long started = System.nanoTime();
			for (int batch = 0; batch < batches; batch++) { service.onPopulationPulse(); }
			for (long id = 1; id <= count; id++)
			{
				final var due = service.dueSnapshot(id);
				PhantomAssertions.assertTrue(history.status(id).orElseThrow().state().cursorEpochMinute() > target - 23_000 - id, "Cold ordinary queue starved profile=" + id);
				if (count == 2) { PhantomAssertions.assertTrue(due.complete() && service.permitsScheduling(id), "Finite two-actor debt never reached readiness."); }
			}
			PhantomAssertions.assertTrue(service.snapshot().maximumPulseIntervals() <= 16 && service.snapshot().maximumPulseProfiles() <= 4, "Cold queue exceeded source budgets.");
			if (count == 2)
			{
				PhantomAssertions.assertEquals(46_003L, history.advancedMinutes(), "Cold request was skipped or counted twice.");
				final long earned = history.advancedMinutes();
				for (int replay = 0; replay < 8; replay++) { service.requestBackgroundDue(1); service.onPopulationPulse(); }
				PhantomAssertions.assertEquals(earned, history.advancedMinutes(), "Completed request replay advanced history twice.");
				service.beginStop();
				final var restored = service(store, history, new AtomicBoolean(), new AtomicReference<>(""), new PhantomPopulationTestDoubles.MutableClock(now), Preset.LIVING, 0, 10);
				restored.installRuntime(id -> population.loadManagedAfter(id - 1, 1).stream().filter(actor -> actor.profile().profileId() == id).findFirst(), noEvents());
				for (long id = 1; id <= count; id++) { restored.register(population.loadManagedAfter(id - 1, 1).getFirst()); }
				loadMetadata(restored, count); restored.onPopulationPulse();
				PhantomAssertions.assertTrue(restored.permitsScheduling(1) && restored.permitsScheduling(2), "Memory-store restart lost completed admission readiness.");
				PhantomAssertions.assertEquals(earned, history.advancedMinutes(), "Memory-store restart replayed completed history.");
				restored.beginStop();
			}
			context.record("task113.queueModel" + count, "batches=" + batches + ", elapsedMs=" + (System.nanoTime() - started) / 1_000_000 + ", historicalPort=MEMORY_NOT_NATIVE");
			service.beginStop();
		}
	}

	private void testNativeContextBeforeClaim061(PhantomTestContext context)
=======
	private void testNativeContextBeforeClaim061(PhantomTestContext context)
>>>>>>> Stashed changes
	{
		final Instant now = Instant.parse("2026-01-05T20:30:00Z");
		final long from = minute(now) - 1;
		for (boolean completed : List.of(false, true))
		{
			final var population = new PhantomPopulationTestDoubles.MemoryStore(_population.hash()).seedReady(1, 1);
			final EcologyMemoryStore store = new EcologyMemoryStore(null);
			final var original = store.insert(1, stateAt(from, Pace.OUTLIER, 10_000, population.state().scheduleTemplate()));
			final var hashes = new PhantomBackgroundState.Hashes("knowledge", "topology", "progression", "commerce");
			final Snapshot previous = completed ? new Snapshot(new PhantomBackgroundCatchupState(Status.COMPLETE, "e".repeat(64), 1, from - 1, from, from, 0, 0, 1, 1, 1, 1, 0, "f".repeat(64), PhantomBackgroundState.MODEL_VERSION, hashes, ""), 0) : null;
			final HistoricalPort historical = new HistoricalPort()
			{
				@Override public Optional<Snapshot> status(long id) { return Optional.ofNullable(previous); }
				@Override public PhantomHistoricalBackgroundService.Result begin(long id, long start, long end, long seed)
				{
					return PhantomHistoricalBackgroundService.Result.rejected(PhantomHistoricalBackgroundService.ResultStatusCode.REPLAN_REQUIRED, "native_context.required:accepted_journey", previous);
				}
				@Override public PhantomHistoricalBackgroundService.Result advance(long id, int intervals, int minutes) { throw new AssertionError("No new history claim exists."); }
			};
			final AtomicBoolean demand = new AtomicBoolean();
			final var service = service(store, historical, new AtomicBoolean(), new AtomicReference<>(""), new PhantomPopulationTestDoubles.MutableClock(now), Preset.LIVING, 0, 1);
			service.enablePeriodicDueMode();
			service.installMaterializationDemand(id -> demand.get());
			service.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
			service.register(population); loadMetadata(service, 1); service.onPopulationPulse();
			PhantomAssertions.assertFalse(service.requestMaterializationDue(1).complete(), "Absent demand bypassed the native context fence.");
			demand.set(true);
			final var ready = service.requestMaterializationDue(1);
			PhantomAssertions.assertTrue(ready.complete(), "Native context rejected before begin cannot resume in World; previousComplete=" + completed);
			PhantomAssertions.assertEquals(org.l2jmobius.gameserver.phantoms.activity.PhantomActivityMaterializationPort.MaterializationRequest.Kind.NORMAL, ready.request().kind(), "No pending historical owner exists to hand off.");
			PhantomAssertions.assertEquals(0, ready.advancedIntervals(), "Native preparation fabricated history.");
			PhantomAssertions.assertFalse(service.requestBackgroundReadiness(1).complete() || service.permitsScheduling(1), "Native admission opened simulated background work.");
			demand.set(false);
			PhantomAssertions.assertFalse(service.requestMaterializationDue(1).complete(), "Withdrawn demand retained native permission.");
			PhantomAssertions.assertEquals(original, store.require(1), "Native admission modified the history cursor or owner.");
			PhantomAssertions.assertEquals(Optional.ofNullable(previous), historical.status(1), "Native admission replaced historical evidence.");
		}
		context.record("task061.preclaimNative", "absent/completed history; exact current demand; NORMAL admission only; no cursor/claim writes");
	}

	private void testNativeReleaseAcrossMinute(PhantomTestContext context)
	{
		final Instant now = Instant.parse("2026-01-05T20:30:00Z");
		final int count = _ecology.limits().maximumProfilesPerPulse() + 16;
		final long from = minute(now) - 120;
		final var population = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final var store = new EcologyMemoryStore(null);
		final var history = new HistoricalMemoryPort();
		for (long id = 1; id <= count; id++)
		{
			final var ready = population.seedReady(id, Math.toIntExact(id));
			final var pending = history.begin(id, from, from + 100, id).snapshot();
			store.insert(id, new PhantomPopulationEcologyState(_ecology.hash(), Preset.LIVING, 1, id, from, from, from, from,
				Pace.OUTLIER, 10_000, _ecology.limits().productiveBlockMinutes(), Personality.BALANCED,
				Map.of(1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0), ready.state().scheduleTemplate(), Disposition.MANAGED,
				minute(now) + 10_000, 0, pending.state().requestId(), from + 100, 0, 0, ""));
		}
		final AtomicBoolean live = new AtomicBoolean(true);
		final var clock = new PhantomPopulationTestDoubles.MutableClock(now);
		final var ecology = new PhantomPopulationEcologyService(_ecology, _population, store, history,
			id -> id == count && live.get(), id -> "", clock, ZoneOffset.UTC, Preset.LIVING, 0, 10,
			worker -> { worker.run(); return true; });
		ecology.enablePeriodicDueMode();
		final var manager = new PhantomPopulationManager(population, _population, null, new PhantomPopulationTestDoubles.Ownership(),
			clock, ZoneOffset.UTC, count, 0, count, 4, 1, 64);
		manager.installEcology(ecology);
		PhantomAssertions.assertTrue(manager.start(), "Minute-release fixture did not start.");
		try
		{
			ecology.holdStartupPopulationPlan();
			loadMetadata(ecology, count);
			ecology.startupPopulationPlanApplied();
			ecology.updateMaterializationDemand(List.of(new PhantomPopulationEcologyService.DemandFact(count, 1, true, 1, 1)), 1);
			ecology.onPopulationPulse();
			final long held = history.status(count).orElseThrow().state().cursorEpochMinute();
			ecology.updateMaterializationDemand(List.of(), 1);
			clock.set(now.plusSeconds(60)); // Deterministic clock only; the native owner is still alive.
			ecology.onPopulationPulse();
			PhantomAssertions.assertEquals(held, history.status(count).orElseThrow().state().cursorEpochMinute(), "Minute refresh advanced a live owner.");
			live.set(false);
			ecology.updateMaterializationDemand(List.of(), 1);
			PhantomAssertions.assertEquals(1, ecology.progressSnapshot(count).urgentQueued(), "Minute refresh lost native release priority behind ordinary backlog.");
			final long ordinary = java.util.stream.LongStream.range(1, count).map(id -> history.status(id).orElseThrow().state().cursorEpochMinute()).sum();
			ecology.onPopulationPulse();
			PhantomAssertions.assertTrue(history.status(count).orElseThrow().state().cursorEpochMinute() > held, "Released owner did not progress in its priority batch.");
			PhantomAssertions.assertTrue(java.util.stream.LongStream.range(1, count).map(id -> history.status(id).orElseThrow().state().cursorEpochMinute()).sum() > ordinary, "Release priority starved ordinary work.");
			PhantomAssertions.assertTrue(ecology.snapshot().maximumPulseProfiles() <= _ecology.limits().maximumProfilesPerPulse()
				&& ecology.snapshot().maximumPulseIntervals() <= _ecology.limits().maximumIntervalsPerPulse(), "Release priority changed shared budgets.");
		}
		finally { ecology.beginStop(); stop(manager); }
	}

	private void testOrphanOwnership(PhantomTestContext context, int control)
	{
		final OrphanFixture f = new OrphanFixture(control);
		if (control == 10)
		{
			for (boolean owner : List.of(true, false))
			{
				f.materialized.set(owner);
				f.safety.set(owner ? "" : "critical_goal");
				f.turn();
				PhantomAssertions.assertEquals(f.original, f.store.require(1), "O10 unsafe adoption changed ecology.");
				PhantomAssertions.assertEquals(f.historyBefore, f.history.get(), "O10 unsafe adoption changed history.");
			}
			f.materialized.set(false); f.safety.set("");
		}
		if (control == 11) { f.store._raceNextSave = true; }
		f.turn();
		if (control == 10)
		{
			for (int pulse = 0; pulse < 256 && !f.store.require(1).state().requestPending(); pulse++) { f.turn(); }
		}
		if ((control >= 5) && (control <= 7))
		{
			PhantomAssertions.assertEquals(f.original, f.store.require(1), "Conflicting orphan changed ecology.");
			PhantomAssertions.assertEquals("ecology.orphan_historical_conflict", f.service.snapshot().lastFailure(), "Orphan conflict is not typed.");
			PhantomAssertions.assertEquals(0, f.begins.get(), "Conflicting orphan called historical begin.");
			PhantomAssertions.assertEquals(f.historyBefore, f.history.get(), "Conflicting orphan rewrote history.");
			return;
		}
		if (control == 4)
		{
			PhantomAssertions.assertTrue(f.begins.get() > 0, "COMPLETE history prevented ordinary sequential renewal.");
			PhantomAssertions.assertFalse(f.historyBefore.state().requestId().equals(f.store.require(1).state().currentRequestId()), "COMPLETE request was adopted.");
			return;
		}
		if (control == 9)
		{
			PhantomAssertions.assertEquals(f.original, f.store.require(1), "Different owned request was stolen.");
			PhantomAssertions.assertEquals(f.historyBefore, f.history.get(), "Ownership disagreement rewrote history.");
			return;
		}
		if (control == 8)
		{
			PhantomAssertions.assertEquals(f.original, f.store.require(1), "Already-owned request added an ecology write.");
			PhantomAssertions.assertTrue(f.advances.get() > 0, "Already-owned request did not use normal advance.");
			return;
		}
		if (control == 11)
		{
			PhantomAssertions.assertFalse(f.store.require(1).state().requestPending(), "CAS loser fabricated ownership.");
			PhantomAssertions.assertEquals(f.historyBefore, f.history.get(), "CAS loser changed historical payload/version.");
			for (int pulse = 0; pulse < 256 && !f.store.require(1).state().requestPending(); pulse++) { f.turn(); }
		}
		final StoredState adopted = f.store.require(1);
		PhantomAssertions.assertTrue(adopted.state().requestPending(), "Exact orphan was not adopted.");
		PhantomAssertions.assertEquals(f.historyBefore.state().requestId(), adopted.state().currentRequestId(), "Adoption minted a request ID.");
		PhantomAssertions.assertEquals(f.historyBefore.state().targetEpochMinute(), adopted.state().currentWindowTargetEpochMinute(), "Adoption changed target.");
		PhantomAssertions.assertEquals(f.original.state().calendarCursorEpochMinute(), adopted.state().calendarCursorEpochMinute(), "Adoption moved outer cursor.");
		PhantomAssertions.assertEquals(f.historyBefore, f.history.get(), "Adoption changed historical row/version/progress.");
		PhantomAssertions.assertEquals(0, f.begins.get(), "Adoption called historical begin.");
		PhantomAssertions.assertEquals(0, f.advances.get(), "Adoption fell through into advance in the same worker turn.");
		PhantomAssertions.assertEquals(f.original.rowVersion() + (control == 11 ? 2 : 1), adopted.rowVersion(), "Adoption added duplicate ecology writes.");
		if (control == 3)
		{
			f.turn();
			f.demand.set(true);
			final var permission = f.service.requestMaterializationDue(1);
			PhantomAssertions.assertTrue(permission.complete(), "Adopted native-context failure did not reach foreground gate.");
			PhantomAssertions.assertEquals("ecology.native_materialization_required", permission.reason(), "Native gate lost exact reason.");
			PhantomAssertions.assertFalse(f.service.requestBackgroundDue(1).complete(), "Native exception opened background due.");
			PhantomAssertions.assertFalse(f.service.requestBackgroundReadiness(1).complete(), "Native exception opened background readiness.");
		}
		if (control == 12)
		{
			f.service.beginStop();
			f.start();
			f.turn();
			PhantomAssertions.assertEquals(adopted, f.store.require(1), "Restart adopted the same request twice.");
			PhantomAssertions.assertTrue(f.advances.get() > 0, "Restart did not resume normal historical request.");
			PhantomAssertions.assertEquals(f.historyBefore.state().requestId(), f.history.get().state().requestId(), "Restart replaced historical identity.");
		}
		context.record("task016.O%02d".formatted(control), "exact ownership preserved");
	}

	private final class OrphanFixture
	{
		private final Instant now = Instant.parse("2026-01-05T20:30:00Z");
		private final long from = minute(now) - 10;
		private final ManagedSnapshot population = new PhantomPopulationTestDoubles.MemoryStore(_population.hash()).seedReady(1, 1);
		private final EcologyMemoryStore store = new EcologyMemoryStore(null);
		private final AtomicBoolean materialized = new AtomicBoolean();
		private final AtomicBoolean demand = new AtomicBoolean();
		private final AtomicReference<String> safety = new AtomicReference<>("");
		private final AtomicReference<Snapshot> history = new AtomicReference<>();
		private final AtomicInteger begins = new AtomicInteger();
		private final AtomicInteger advances = new AtomicInteger();
		private final StoredState original;
		private final Snapshot historyBefore;
		private PhantomPopulationEcologyService service;
		private final HistoricalPort port = new HistoricalPort()
		{
			@Override public Optional<Snapshot> status(long id) { return Optional.of(history.get()); }
			@Override public PhantomHistoricalBackgroundService.Result begin(long id, long start, long end, long seed)
			{
				begins.incrementAndGet();
				if (history.get().state().status() != Status.COMPLETE) { return PhantomHistoricalBackgroundService.Result.rejected(PhantomHistoricalBackgroundService.ResultStatusCode.CONFLICT, "synthetic.conflict", history.get()); }
				final var previous = history.get();
				final var replacement = new PhantomBackgroundCatchupState(Status.PENDING, "b".repeat(64), seed, start, end, start, 0, 0, 1, 1, 1, 0, 0, "", PhantomBackgroundState.MODEL_VERSION, previous.state().authorityHashes(), "");
				history.set(new Snapshot(replacement, previous.rowVersion() + 1));
				return PhantomHistoricalBackgroundService.Result.success(history.get(), 0);
			}
			@Override public PhantomHistoricalBackgroundService.Result advance(long id, int intervals, int minutes)
			{
				advances.incrementAndGet();
				final var current = history.get();
				if (current.state().status() == Status.FAILED_REPLAN_REQUIRED) { return PhantomHistoricalBackgroundService.Result.rejected(PhantomHistoricalBackgroundService.ResultStatusCode.REPLAN_REQUIRED, current.state().failureReason(), current); }
				return PhantomHistoricalBackgroundService.Result.rejected(PhantomHistoricalBackgroundService.ResultStatusCode.RETRY, "transaction.items.retry", current);
			}
		};
		private OrphanFixture(int control)
		{
			var ecology = stateAt(from, Pace.OUTLIER, 10_000, population.state().scheduleTemplate());
			if (control == 8 || control == 9) { ecology = ecology.beginRequest(control == 8 ? "a".repeat(64) : "c".repeat(64), from + 5); }
			original = store.insert(1, ecology);
			final Status status = control == 2 ? Status.RUNNING : control == 3 ? Status.FAILED_REPLAN_REQUIRED : control == 4 ? Status.COMPLETE : Status.PENDING;
			final long start = control == 5 || control == 6 ? from - 5 : from;
			final long target = control == 6 ? from : from + 5;
			final long cursor = control == 4 ? target : control == 2 ? from + 1 : start;
			final boolean planned = control == 2 || control == 4;
			// Fixed independent fixture seed for generation=1, ordinal=1, virtualJoin=29460740.
			final long seed = 2874440040829550073L + (control == 7 ? 1 : 0);
			final var value = new PhantomBackgroundCatchupState(status, "a".repeat(64), seed, start, target, cursor, 0, control == 2 ? 1 : 0, 1, 1, 1, planned ? 1 : 0, 0, planned ? "f".repeat(64) : "", PhantomBackgroundState.MODEL_VERSION, new PhantomBackgroundState.Hashes("knowledge", "topology", "progression", "commerce"), control == 3 ? "native_context.required:coalesced" : "");
			historyBefore = new Snapshot(value, 41);
			history.set(historyBefore);
			start();
		}
		private void start()
		{
			service = service(store, port, materialized, safety, new PhantomPopulationTestDoubles.MutableClock(now), Preset.LIVING, 0, 1);
			service.enablePeriodicDueMode();
			service.installMaterializationDemand(id -> demand.get());
			service.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
			service.register(population);
			loadMetadata(service, 1);
		}
		private void turn() { service.requestBackgroundDue(1); service.onPopulationPulse(); }
	}

	private void testLiveCapacityReleaseAdmission(PhantomTestContext context)
	{
		final Instant now = Instant.parse("2026-01-05T20:30:00Z");
		final long target = minute(now);
		final long from = target - 48;
		final var population = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final var store = new EcologyMemoryStore(population);
		final var history = new HistoricalMemoryPort();
		final AtomicBoolean liveOwners = new AtomicBoolean(true);
		final AtomicInteger capacityRetries = new AtomicInteger();
		for (long id = 1; id <= 9; id++)
		{
			final var ready = population.seedReady(id, 1);
			final var pending = history.begin(id, from, from + 15, SEED).snapshot();
			store.insert(id, new PhantomPopulationEcologyState(_ecology.hash(), Preset.LIVING, 1, id, target, from, from, target,
				Pace.OUTLIER, 10_000, _ecology.limits().productiveBlockMinutes(), Personality.BALANCED,
				Map.of(1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0), ready.state().scheduleTemplate(), Disposition.MANAGED,
				target + 10_000, 0, pending.state().requestId(), from + 15, 0, 0, ""));
		}
		final HistoricalPort historical = new HistoricalPort()
		{
			@Override
			public Optional<Snapshot> status(long id) { return history.status(id); }
			@Override
			public PhantomHistoricalBackgroundService.Result begin(long id, long start, long end, long seed) { return history.begin(id, start, end, seed); }
			@Override
			public PhantomHistoricalBackgroundService.Result advance(long id, int intervals, int minutes)
			{
				if (liveOwners.get())
				{
					PhantomAssertions.assertEquals(9L, id, "Historical advance raced a live native owner.");
					capacityRetries.incrementAndGet();
					return PhantomHistoricalBackgroundService.Result.rejected(PhantomHistoricalBackgroundService.ResultStatusCode.RETRY,
						"catchup.baseline.materialize_capacity_reached", history.status(id).orElseThrow());
				}
				return history.advance(id, intervals, minutes);
			}
		};
		final var clock = new PhantomPopulationTestDoubles.MutableClock(now);
		final var ecology = new PhantomPopulationEcologyService(_ecology, _population, store, historical,
			id -> liveOwners.get() && id <= 8, id -> "", clock, ZoneOffset.UTC, Preset.LIVING, -1, 10,
			worker -> { worker.run(); return true; });
		ecology.enablePeriodicDueMode();
		final var manager = new PhantomPopulationManager(population, _population, null, new PhantomPopulationTestDoubles.Ownership(),
			clock, ZoneOffset.UTC, 9, 8, 16, 8, 2, 64);
		manager.installEcology(ecology);
		PhantomAssertions.assertTrue(manager.start(), "Capacity fixture population did not start.");
		try
		{
			loadMetadata(ecology, 9);
			final List<PhantomPopulationEcologyService.DemandFact> demand = new ArrayList<>();
			for (long id = 1; id <= 8; id++) { demand.add(new PhantomPopulationEcologyService.DemandFact(id, 1, true, id, id)); }
			ecology.updateMaterializationDemand(demand, 0);
			for (int pulse = 0; pulse < 64; pulse++) { manager.onPulse(); }
			PhantomAssertions.assertTrue(capacityRetries.get() > 0 && capacityRetries.get() < 16, "Capacity retries lost bounded backoff.");
			PhantomAssertions.assertEquals(0L, history.advancedMinutes(), "Live capacity fabricated historical progress.");
			PhantomAssertions.assertEquals(0, manager.admissionSnapshot().admittedActive(), "Live Player bypassed current ecology admission.");
			for (long id = 1; id <= 8; id++)
			{
				final var due = ecology.dueSnapshot(id);
				PhantomAssertions.assertFalse(due.complete(), "Pending live history became current.");
				PhantomAssertions.assertEquals(from, due.committedCursorMinute(), "Live owner advanced a pending cursor.");
				PhantomAssertions.assertEquals("ecology.preparation_capacity", due.reason(), "Occupied live preparation gate changed.");
			}
			// Only external lifetime/capacity facts change; the owners drain their original queues and requests.
			liveOwners.set(false);
			ecology.updateMaterializationDemand(List.of(), 8);
			pulseUntil(manager, () -> manager.admissionSnapshot().eligibleActive() == 9, 256, "Ordinary released catchup did not reopen admission.");
			PhantomAssertions.assertEquals(8, manager.admissionSnapshot().admittedActive(), "Current admission changed the native cap.");
			for (long id = 1; id <= 9; id++)
			{
				final var due = ecology.dueSnapshot(id);
				PhantomAssertions.assertTrue(due.complete() && due.initialCatchupComplete() && !due.requestPending(), "Prepared identity retained a historical fence.");
				PhantomAssertions.assertEquals(target, due.committedCursorMinute(), "Catchup did not reach the current horizon.");
				PhantomAssertions.assertTrue(ecology.permitsScheduling(id), "Committed current history did not permit ordinary scheduling.");
			}
			PhantomAssertions.assertEquals(9 * 48L, history.advancedMinutes(), "Released catchup lost or replayed productive history.");
			PhantomAssertions.assertTrue(ecology.snapshot().maximumPulseProfiles() <= _ecology.limits().maximumProfilesPerPulse(), "Preparation exceeded profile budget.");
			PhantomAssertions.assertTrue(ecology.snapshot().maximumPulseIntervals() <= _ecology.limits().maximumIntervalsPerPulse(), "Preparation exceeded interval budget.");
			PhantomAssertions.assertEquals(now, clock.instant(), "Preparation required a clock change.");
			context.record("task046.releaseAdmission", "live8/capacity_retry/admitted0 -> ordinary_catchup/current9/admitted8; clock_unchanged");
		}
		finally { stop(manager); }
	}

	private void testNativeMaterializationReadiness(PhantomTestContext context)
	{
		final Instant now = Instant.parse("2026-01-05T20:30:00Z");
		final long from = minute(now) - 1;
		final long target = minute(now);
		for (String reason : List.of("native_context.required:coalesced", "transaction.native_context_required", "native_context.required:accepted", "model.slot_capacity", "model.slot_capacity_unknown", "synthetic.permanent_failure"))
		{
			final boolean nativeRequired = !reason.equals("synthetic.permanent_failure") && !reason.equals("model.slot_capacity_unknown");
			PhantomAssertions.assertEquals(nativeRequired, PhantomHistoricalBackgroundService.requiresNativeMaterialization(reason), "Exact native materialization classification changed.");
			PhantomAssertions.assertFalse(PhantomHistoricalBackgroundService.isRecoverableFailure(reason), "Foreground requirement entered generic background recovery.");
			final String requestId = "e".repeat(64);
			final var population = new PhantomPopulationTestDoubles.MemoryStore(_population.hash()).seedReady(1, 1);
			final EcologyMemoryStore store = new EcologyMemoryStore(null);
			final var original = store.insert(1, stateAt(from, Pace.OUTLIER, 10_000, population.state().scheduleTemplate()).beginRequest(requestId, target));
			final var hashes = new PhantomBackgroundState.Hashes("knowledge", "topology", "progression", "commerce");
			final boolean pending = reason.equals("native_context.required:accepted");
			final var failed = new PhantomBackgroundCatchupState(pending ? Status.PENDING : Status.FAILED_REPLAN_REQUIRED, requestId, 1, from, target, from, 0, 0, 1, 1, 1, 1, 0, "f".repeat(64), PhantomBackgroundState.MODEL_VERSION, hashes, pending ? "" : reason);
			final Snapshot snapshot = new Snapshot(failed, 0);
			final AtomicInteger attempts = new AtomicInteger();
			final HistoricalPort historical = new HistoricalPort()
			{
				@Override
				public Optional<Snapshot> status(long profileId) { return Optional.of(snapshot); }
				@Override
				public PhantomHistoricalBackgroundService.Result begin(long profileId, long start, long end, long seed) { throw new AssertionError("Native requirement must preserve the pending request."); }
				@Override
				public PhantomHistoricalBackgroundService.Result advance(long profileId, int intervals, int minutes)
				{
					attempts.incrementAndGet();
					return PhantomHistoricalBackgroundService.Result.rejected(PhantomHistoricalBackgroundService.ResultStatusCode.REPLAN_REQUIRED, reason, snapshot);
				}
			};
			final AtomicBoolean materialized = new AtomicBoolean();
			final AtomicBoolean demand = new AtomicBoolean();
			final var service = service(store, historical, materialized, new AtomicReference<>(""), new PhantomPopulationTestDoubles.MutableClock(now), Preset.LIVING, 0, 1);
			service.enablePeriodicDueMode();
			service.installMaterializationDemand(id -> demand.get());
			service.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
			service.register(population);
			loadMetadata(service, 1);
			service.onPopulationPulse();
			PhantomAssertions.assertEquals(1, attempts.get(), "Fixture did not deliver the historical failure.");
			PhantomAssertions.assertFalse(service.requestBackgroundDue(1).complete(), "No human demand opened background readiness.");
			PhantomAssertions.assertFalse(service.requestMaterializationDue(1).complete(), "Absent current human demand granted native materialization.");
			demand.set(true);
			for (int retry = 0; retry < 3; retry++)
			{
				final var readiness = service.requestMaterializationDue(1);
				PhantomAssertions.assertEquals(nativeRequired, readiness.complete(), "Native requirement did not release only the materialization gate: " + reason);
				PhantomAssertions.assertEquals(0, readiness.advancedIntervals(), "Materialization readiness fabricated catchup progress.");
				if (nativeRequired) { PhantomAssertions.assertEquals("ecology.native_materialization_required", readiness.reason(), "Materialization exception lost its explicit reason."); }
				PhantomAssertions.assertFalse(service.requestBackgroundDue(1).complete(), "Materialization exception opened background due.");
				PhantomAssertions.assertFalse(service.requestBackgroundReadiness(1).complete(), "Materialization exception opened background admission.");
				PhantomAssertions.assertFalse(service.permitsScheduling(1), "Materialization exception weakened ordinary scheduling.");
			}
			service.updateMaterializationDemand(List.of(new PhantomPopulationEcologyService.DemandFact(1, 1, true, 1, 1)), 1);
			PhantomAssertions.assertEquals(nativeRequired, service.requestMaterializationDue(1).complete(), "Native prerequisite backoff stranded bounded preparation admission: " + reason);
			for (int pulse = 0; pulse < 256; pulse++) { service.onPopulationPulse(); }
			PhantomAssertions.assertTrue(nativeRequired ? attempts.get() > 1 && attempts.get() <= (pending ? 10 : 3) : attempts.get() == 1, "Native retry must remain bounded and permanent failures terminal: " + reason + " attempts=" + attempts.get());
			if (nativeRequired)
			{
				materialized.set(true);
				final int before = attempts.get();
				for (int pulse = 0; pulse < 256; pulse++) { service.onPopulationPulse(); }
				PhantomAssertions.assertEquals(before, attempts.get(), "Historical retry raced a materialized Player.");
				materialized.set(false);
				demand.set(false);
				service.withdrawMaterializationDue(1);
				PhantomAssertions.assertFalse(service.requestMaterializationDue(1).complete(), "Withdrawn human demand retained native permission.");
			}
			PhantomAssertions.assertEquals(original, store.require(1), "Native requirement changed pending/cursor/completion or durable revision.");
			PhantomAssertions.assertEquals(snapshot, historical.status(1).orElseThrow(), "Readiness changed failed historical ownership.");
		}
	}

	private void testRestoredInventoryReadinessStartsCreation(PhantomTestContext context)
	{
		final PhantomPopulationTestDoubles.MemoryStore populationStore = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final EcologyMemoryStore ecologyStore = new EcologyMemoryStore(populationStore);
		for (long profileId = 1; profileId <= 2; profileId++)
		{
			final ManagedSnapshot restored = populationStore.seedReady(profileId, 1);
			ecologyStore.insert(profileId, stateAt(minute(CREATED), Pace.OUTLIER, 10_000, restored.state().scheduleTemplate()));
		}
		final PhantomPopulationTestDoubles.MutableClock clock = new PhantomPopulationTestDoubles.MutableClock(CREATED);
		final PhantomPopulationEcologyService ecology = service(ecologyStore, new HistoricalMemoryPort(), new AtomicBoolean(), new AtomicReference<>(""), clock, Preset.LIVING, 0, 10);
		final PhantomPopulationManager manager = new PhantomPopulationManager(populationStore, _population, null, new PhantomPopulationTestDoubles.Ownership(), clock, ZoneOffset.UTC, 5, 0, 16, 4, 2, 64);
		manager.installEcology(ecology);
		PhantomAssertions.assertTrue(manager.start(), "Restored population did not start.");
		PhantomAssertions.assertFalse(ecology.inventoryReady(), "Restored ecology unexpectedly bypassed inventory loading.");
		PhantomAssertions.assertEquals(2, populationStore.size(), "Target deficit created shells before ecology inventory was ready.");
		manager.onPulse();
		PhantomAssertions.assertTrue(ecology.inventoryReady(), "Final restored ecology row did not make inventory ready inside the pulse.");
		PhantomAssertions.assertEquals(4, populationStore.size(), "Lost ecology readiness edge did not reconcile the target deficit into two bounded shells.");
		final long createdId = populationStore.loadManagedAfter(0, 16).stream().filter(value -> value.state().creationPending()).findFirst().orElseThrow().profile().profileId();
		advanceToReady(manager, createdId);
		PhantomAssertions.assertFalse(ecology.dueSnapshot(createdId).reason().equals("ecology.population_paused"), "New READY identity retained its SHELL ecology pause.");
		stop(manager);
		context.record("goal033.restoredReadinessCreated", populationStore.size());
	}

	private void testIncompletePeriodicDueContinues(PhantomTestContext context)
	{
		final Instant now = Instant.parse("2026-01-05T20:00:00Z");
		final long target = minute(now);
		final PhantomPopulationTestDoubles.MemoryStore populationStore = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final ManagedSnapshot population = populationStore.seedReady(1, 1);
		final EcologyMemoryStore store = new EcologyMemoryStore(null);
		store.insert(1, stateAt(target - 60, Pace.OUTLIER, 10_000, population.state().scheduleTemplate()));
		final HistoricalMemoryPort historical = new HistoricalMemoryPort();
		final var clock = new PhantomPopulationTestDoubles.MutableClock(now);
		final PhantomPopulationEcologyService service = service(store, historical, new AtomicBoolean(), new AtomicReference<>(""), clock, Preset.LIVING, 0, 10);
		service.enablePeriodicDueMode();
		service.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
		service.register(population);
		final var first = service.dueSnapshot(1);
		PhantomAssertions.assertFalse(first.complete(), "Backlogged due unexpectedly bypassed the bounded cursor gate.");
		PhantomAssertions.assertTrue(store.require(1).state().calendarCursorEpochMinute() < target, "Fixture did not retain a due gap.");
		for (int pulse = 0; (pulse < 200) && (store.require(1).state().calendarCursorEpochMinute() < target); pulse++)
		{
			service.onPopulationPulse();
		}
		PhantomAssertions.assertEquals(target, store.require(1).state().calendarCursorEpochMinute(), "An incomplete explicit due did not continue through bounded ecology pulses.");
		PhantomAssertions.assertTrue(service.reconcileBackgroundDue(1).complete(), "Current durable cursor did not release the materialization gate.");
		PhantomAssertions.assertTrue(service.snapshot().maximumPulseProfiles() <= _ecology.limits().maximumProfilesPerPulse(), "Periodic continuation exceeded the profile pulse budget.");
		PhantomAssertions.assertTrue(service.snapshot().maximumPulseIntervals() <= _ecology.limits().maximumIntervalsPerPulse(), "Periodic continuation exceeded the interval pulse budget.");
		clock.set(Instant.parse("2026-01-05T23:30:00Z"));
		for (int pulse = 0; pulse < 200; pulse++) { service.onPopulationPulse(); }
		final long beforeOffline = historical.advancedMinutes();
		clock.set(Instant.parse("2026-01-06T17:30:00Z"));
		for (int pulse = 0; pulse < 20; pulse++) { service.onPopulationPulse(); }
		PhantomAssertions.assertEquals(beforeOffline, historical.advancedMinutes(), "Offline calendar gap fabricated farm work.");
		PhantomAssertions.assertEquals(minute(clock.instant()), store.require(1).state().calendarCursorEpochMinute(), "Offline gap required a human to advance its canonical cursor.");
		clock.set(Instant.parse("2026-01-06T17:31:00Z"));
		for (int pulse = 0; pulse < 10; pulse++) { service.onPopulationPulse(); }
		PhantomAssertions.assertEquals(beforeOffline + 1, historical.advancedMinutes(), "Background calendar boundary did not resume without human demand.");
		context.record("goal033.periodicContinuation", historical.advancedMinutes());
	}

	private void testStaleAuthorityRenewal(PhantomTestContext context)
	{
		final Instant now = Instant.parse("2026-01-05T20:30:00Z");
		final long from = minute(now) - 10;
		final long target = minute(now);
		final String requestId = "e".repeat(64);
		final PhantomPopulationTestDoubles.MemoryStore populationStore = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final ManagedSnapshot population = populationStore.seedReady(1, 1);
		final EcologyMemoryStore store = new EcologyMemoryStore(null);
		store.insert(1, stateAt(from, Pace.OUTLIER, 10_000, population.state().scheduleTemplate()).beginRequest(requestId, target));
		final PhantomBackgroundState.Hashes oldHashes = new PhantomBackgroundState.Hashes("knowledge", "topology", "progression", "commerce");
		final PhantomBackgroundState.Hashes currentHashes = new PhantomBackgroundState.Hashes("knowledge", "topology-current", "progression", "commerce");
		final PhantomBackgroundCatchupState stale = new PhantomBackgroundCatchupState(Status.FAILED_REPLAN_REQUIRED, requestId, 1, from, target, from, 0, 0, 1, 1, 1, 1, 0, "f".repeat(64), PhantomBackgroundState.MODEL_VERSION, oldHashes, "authority.hash_stale");
		final AtomicReference<Snapshot> catchup = new AtomicReference<>(new Snapshot(stale, 0));
		final AtomicBoolean renewed = new AtomicBoolean();
		final AtomicInteger awards = new AtomicInteger();
		final HistoricalPort historical = new HistoricalPort()
		{
			@Override
			public Optional<Snapshot> status(long profileId)
			{
				return Optional.of(catchup.get());
			}

			@Override
			public PhantomHistoricalBackgroundService.Result begin(long profileId, long fromEpochMinute, long targetEpochMinute, long deterministicSeed)
			{
				throw new AssertionError("Stale authority must keep the existing request identity.");
			}

			@Override
			public PhantomHistoricalBackgroundService.Result advance(long profileId, int maximumIntervals, int maximumMinutes)
			{
				final Snapshot current = catchup.get();
				if (!renewed.get())
				{
					return PhantomHistoricalBackgroundService.Result.rejected(PhantomHistoricalBackgroundService.ResultStatusCode.REPLAN_REQUIRED, "authority.hash_stale", current);
				}
				final PhantomBackgroundCatchupState continued = current.state().withPlan(1, 1, 1, "a".repeat(64), 2, 2, currentHashes).advanceTo(target);
				awards.addAndGet(Math.toIntExact(target - current.state().cursorEpochMinute()));
				final Snapshot committed = new Snapshot(continued, current.rowVersion() + 1);
				catchup.set(committed);
				return PhantomHistoricalBackgroundService.Result.success(committed, 1);
			}
		};
		final PhantomPopulationEcologyService service = service(store, historical, new AtomicBoolean(), new AtomicReference<>(""), new PhantomPopulationTestDoubles.MutableClock(now), Preset.LIVING, 0, 1);
		service.enablePeriodicDueMode();
		service.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
		service.register(population);
		PhantomAssertions.assertFalse(drainDue(service, 1).complete(), "Stale authority incorrectly completed the due.");
		PhantomAssertions.assertEquals(from, store.require(1).state().calendarCursorEpochMinute(), "Stale authority moved the accepted cursor.");
		renewed.set(true);
		for (int pulse = 0; (pulse < 512) && store.require(1).state().requestPending(); pulse++)
		{
			service.onPopulationPulse();
		}
		PhantomAssertions.assertTrue(drainDue(service, 1).complete(), "Renewed authority did not complete the pending due.");
		PhantomAssertions.assertEquals(target, store.require(1).state().calendarCursorEpochMinute(), "Renewal did not advance the existing ecology cursor.");
		PhantomAssertions.assertEquals(requestId, catchup.get().state().requestId(), "Renewal created a second request identity.");
		PhantomAssertions.assertEquals(currentHashes, catchup.get().state().authorityHashes(), "Renewal kept stale authority hashes.");
		PhantomAssertions.assertEquals(10, awards.get(), "Renewal did not award ten logical minutes exactly once.");
		PhantomAssertions.assertEquals(0, drainDue(service, 1).advancedIntervals(), "Completed renewal replayed the award.");
		context.record("goal033.staleAuthorityRenewal", "same_request,10_minutes_once");
	}

	private void testStopLiveTail075(PhantomTestContext context)
	{
		final Instant from = Instant.parse("2026-01-05T20:00:00Z");
		final long fromMinute = minute(from);
		final var population = new PhantomPopulationTestDoubles.MemoryStore(_population.hash()).seedReady(1, 1);
		final var store = new EcologyMemoryStore(null);
		store.insert(1, stateAt(fromMinute, Pace.OUTLIER, 10_000, population.state().scheduleTemplate()));
		final var historical = new HistoricalMemoryPort();
		final var materialized = new AtomicBoolean(true);
		final var clock = new PhantomPopulationTestDoubles.MutableClock(from.plusSeconds(10 * 60));
		final var first = service(store, historical, materialized, new AtomicReference<>(""), clock, Preset.LIVING, 0, 10);
		first.enablePeriodicDueMode();
		first.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
		first.register(population); loadMetadata(first, 1);
		PhantomAssertions.assertTrue(drainDue(first, 1).complete(), "Initial live sample did not settle its calendar.");
		clock.set(from.plusSeconds(15 * 60));
		first.beginStop();
		materialized.set(false);
		clock.set(from.plusSeconds(25 * 60));
		first.beginStop();
		PhantomAssertions.assertTrue(first.finishStop(), "Single live stop tail did not settle.");
		PhantomAssertions.assertEquals(fromMinute + 15, store.require(1).state().calendarCursorEpochMinute(), "Stop left sampled-to-stop live time available for historical rewards or swallowed downtime.");
		PhantomAssertions.assertEquals(0L, historical.advancedMinutes(), "Stop settlement awarded historical work.");
		for (int restart = 0; restart < 2; restart++)
		{
			final var resumed = service(store, historical, materialized, new AtomicReference<>(""), clock, Preset.LIVING, 0, 10);
			resumed.enablePeriodicDueMode();
			resumed.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
			resumed.register(population); loadMetadata(resumed, 1);
			PhantomAssertions.assertTrue(drainDue(resumed, 1).complete(), "Restart did not reconcile the bounded downtime.");
			PhantomAssertions.assertEquals(10L, historical.advancedMinutes(), "Restart replayed native live time or the same downtime twice.");
			resumed.beginStop();
			PhantomAssertions.assertTrue(resumed.finishStop(), "No-live restart retained stop settlement work.");
		}
		context.record("goal075.stopLiveTail", "10_sampled+5_live_settled_without_reward+10_downtime_once");
	}

	private void testStopCursorConflict075(PhantomTestContext context)
	{
		final Instant from = Instant.parse("2026-01-05T20:00:00Z");
		final long fromMinute = minute(from);
		final var population = new PhantomPopulationTestDoubles.MemoryStore(_population.hash()).seedReady(1, 1);
		final var store = new EcologyMemoryStore(null);
		final var original = store.insert(1, stateAt(fromMinute + 20, Pace.OUTLIER, 10_000, population.state().scheduleTemplate()));
		final var historical = new HistoricalMemoryPort();
		final var clock = new PhantomPopulationTestDoubles.MutableClock(from.plusSeconds(15 * 60));
		final var backwards = service(store, historical, new AtomicBoolean(true), new AtomicReference<>(""), clock, Preset.LIVING, 0, 10);
		backwards.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
		backwards.register(population); loadMetadata(backwards, 1);
		backwards.beginStop();
		PhantomAssertions.assertTrue(backwards.finishStop(), "Backward wall clock blocked a no-op stop.");
		PhantomAssertions.assertEquals(original, store.require(1), "Backward wall clock rewrote the durable calendar.");
		clock.set(from.plusSeconds(25 * 60));
		final var raced = service(store, historical, new AtomicBoolean(true), new AtomicReference<>(""), clock, Preset.LIVING, 0, 10);
		raced.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
		raced.register(population); loadMetadata(raced, 1);
		store._raceNextSave = true;
		raced.beginStop();
		PhantomAssertions.assertFalse(raced.finishStop(), "A failed stop CAS was reported complete.");
		PhantomAssertions.assertEquals(fromMinute + 20, store.require(1).state().calendarCursorEpochMinute(), "Failed stop CAS overwrote the raced row.");
		PhantomAssertions.assertTrue(raced.finishStop(), "Stop retry did not reload the durable row version.");
		final var settled = store.require(1);
		PhantomAssertions.assertEquals(fromMinute + 25, settled.state().calendarCursorEpochMinute(), "Stop CAS retry lost the live tail.");
		PhantomAssertions.assertTrue(raced.finishStop(), "Completed stop was not idempotent.");
		PhantomAssertions.assertEquals(settled, store.require(1), "Completed stop wrote the same row twice.");
		PhantomAssertions.assertEquals(0L, historical.advancedMinutes(), "Stop conflict recovery invoked historical rewards.");
		context.record("goal075.stopCursorConflict", "backward_clock_noop+fresh_cas_retry+idempotent");
	}

	private void testStopPendingHistory075(PhantomTestContext context)
	{
		final Instant from = Instant.parse("2026-01-05T20:00:00Z");
		final long fromMinute = minute(from);
		final int budget = _ecology.limits().maximumProfilesPerPulse();
		final int liveCount = budget + 2;
		final var populations = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final var store = new EcologyMemoryStore(null);
		final var historical = new HistoricalMemoryPort();
		final var owners = new HashMap<Long, ManagedSnapshot>();
		for (long id = 1; id <= liveCount + 1; id++)
		{
			final var owner = populations.seedReady(id, 1); owners.put(id, owner);
			store.insert(id, stateAt(fromMinute, Pace.OUTLIER, 10_000, owner.state().scheduleTemplate()));
		}
		final var pending = historical.begin(1, fromMinute, fromMinute + 5, 1).snapshot();
		final var orphan = historical.begin(2, fromMinute, fromMinute + 5, 2).snapshot();
		final var initial = store.require(1);
		store.save(1, initial, initial.state().beginRequest(pending.state().requestId(), pending.state().targetEpochMinute()));
		final var pendingEcology = store.require(1);
		final var orphanEcology = store.require(2);
		final var nonliveEcology = store.require(liveCount + 1);
		final var clock = new PhantomPopulationTestDoubles.MutableClock(from.plusSeconds(10 * 60));
		final var service = new PhantomPopulationEcologyService(_ecology, _population, store, historical, id -> id <= liveCount, id -> "", clock, ZoneOffset.UTC, Preset.LIVING, 0, 10, worker -> { worker.run(); return true; });
		service.installRuntime(id -> Optional.ofNullable(owners.get(id)), noEvents());
		for (long id = 1; id <= liveCount + 1; id++) { service.register(owners.get(id)); }
		loadMetadata(service, liveCount + 1);
		service.beginStop();
		PhantomAssertions.assertFalse(service.finishStop(), "Stop drained more than one profile budget.");
		PhantomAssertions.assertTrue(service.snapshot().persistenceWrites() <= budget, "Stop settlement exceeded the existing profile budget.");
		PhantomAssertions.assertTrue(service.finishStop(), "Second bounded stop batch did not finish.");
		PhantomAssertions.assertEquals(pendingEcology, store.require(1), "Stop rewrote a pending ecology claim.");
		PhantomAssertions.assertEquals(orphanEcology, store.require(2), "Stop skipped an orphan historical owner.");
		PhantomAssertions.assertEquals(pending, historical.status(1).orElseThrow(), "Stop rewrote pending historical progress.");
		PhantomAssertions.assertEquals(orphan, historical.status(2).orElseThrow(), "Stop rewrote orphan historical progress.");
		PhantomAssertions.assertEquals(nonliveEcology, store.require(liveCount + 1), "Stop consumed downtime for a nonlive profile.");
		for (long id = 3; id <= liveCount; id++) { PhantomAssertions.assertEquals(fromMinute + 10, store.require(id).state().calendarCursorEpochMinute(), "Bounded stop batch omitted a live owner."); }
		PhantomAssertions.assertEquals(0L, historical.advancedMinutes(), "Stop settled pending history by simulating work.");
		context.record("goal075.stopPendingHistory", "bounded_batches+pending_and_orphan_claims_preserved+nonlive_untouched");
	}

	private void testPeriodicMaterializedBoundary(PhantomTestContext context)
	{
		final Instant from = Instant.parse("2026-01-05T20:00:00Z");
		final long fromMinute = minute(from);
		final PhantomPopulationTestDoubles.MemoryStore populationStore = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final ManagedSnapshot population = populationStore.seedReady(1, 1);
		final EcologyMemoryStore store = new EcologyMemoryStore(null);
		store.insert(1, stateAt(fromMinute, Pace.OUTLIER, 10_000, population.state().scheduleTemplate()));
		final HistoricalMemoryPort historical = new HistoricalMemoryPort();
		final AtomicBoolean materialized = new AtomicBoolean();
		final PhantomPopulationTestDoubles.MutableClock clock = new PhantomPopulationTestDoubles.MutableClock(from.plusSeconds(10 * 60));
		final PhantomPopulationEcologyService service = service(store, historical, materialized, new AtomicReference<>(""), clock, Preset.LIVING, 0, 10);
		service.enablePeriodicDueMode();
		service.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
		service.register(population);
		loadMetadata(service, 1);
		PhantomAssertions.assertTrue(drainDue(service, 1).complete(), "First ten-minute due did not complete.");
		PhantomAssertions.assertEquals(10L, historical.advancedMinutes(), "First ten-minute due did not award exactly once.");
		materialized.set(true);
		clock.set(from.plusSeconds(15 * 60));
		service.updateMaterializationDemand(List.of(new PhantomPopulationEcologyService.DemandFact(1, 1, true, 1, 1)), 1);
		PhantomAssertions.assertTrue(drainDue(service, 1).complete(), "Materialized boundary did not commit calendar time.");
		PhantomAssertions.assertEquals(fromMinute + 15, store.require(1).state().calendarCursorEpochMinute(), "Materialized boundary left historical time replayable.");
		PhantomAssertions.assertEquals(10L, historical.advancedMinutes(), "Materialized boundary awarded historical minutes.");
		materialized.set(false);
		clock.set(from.plusSeconds(25 * 60));
		service.updateMaterializationDemand(List.of(new PhantomPopulationEcologyService.DemandFact(1, 1, true, 1, 1)), 1);
		PhantomAssertions.assertTrue(drainDue(service, 1).complete(), "Dematerialized boundary did not resume periodic due.");
		PhantomAssertions.assertEquals(fromMinute + 25, store.require(1).state().calendarCursorEpochMinute(), "Resumed cursor regressed or skipped the due target.");
		PhantomAssertions.assertEquals(20L, historical.advancedMinutes(), "Dematerialized window double-awarded materialized time.");
		PhantomAssertions.assertEquals(0, drainDue(service, 1).advancedIntervals(), "Ack replay advanced a completed dematerialized due.");
		context.record("goal033.periodicMaterializedBoundary", "10_awarded,5_materialized_no_award,10_resumed");
	}

	private void testPeriodicDueCrashRecovery(PhantomTestContext context)
	{
		for (boolean afterSave : List.of(false, true))
		{
			final Instant from = Instant.parse("2026-01-05T20:00:00Z");
			final long fromMinute = minute(from);
			final PhantomPopulationTestDoubles.MemoryStore populationStore = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
			final ManagedSnapshot population = populationStore.seedReady(1, 1);
			final EcologyMemoryStore store = new EcologyMemoryStore(null);
			store.insert(1, stateAt(fromMinute, Pace.OUTLIER, 10_000, population.state().scheduleTemplate()));
			final HistoricalMemoryPort historical = new HistoricalMemoryPort();
			final PhantomPopulationTestDoubles.MutableClock clock = new PhantomPopulationTestDoubles.MutableClock(from.plusSeconds(10 * 60));
			final PhantomPopulationEcologyService first = service(store, historical, new AtomicBoolean(), new AtomicReference<>(""), clock, Preset.LIVING, 0, 10);
			first.enablePeriodicDueMode();
			first.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
			first.register(population);
			loadMetadata(first, 1);
			PhantomAssertions.assertEquals(0, historical.requestIds().size(), "Metadata setup began history before the crash boundary.");
			historical.crashNextAdvance(afterSave);
			PhantomAssertions.assertFalse(drainDue(first, 1).complete(), "Injected crash was reported as a complete due.");
			PhantomAssertions.assertEquals(1, historical.injectedCrashes(), "Crash fixture did not enter historical advance after metadata.");
			PhantomAssertions.assertTrue(store.require(1).state().calendarCursorEpochMinute() >= fromMinute, "Crash moved durable ecology cursor backwards.");
			final PhantomPopulationEcologyService restarted = service(store, historical, new AtomicBoolean(), new AtomicReference<>(""), clock, Preset.LIVING, 0, 10);
			restarted.enablePeriodicDueMode();
			restarted.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
			restarted.register(population);
			loadMetadata(restarted, 1);
			final var recovered = drainDue(restarted, 1);
			PhantomAssertions.assertTrue(recovered.complete(), "Restart did not reconcile the durable request after injected crash.");
			PhantomAssertions.assertEquals(fromMinute + 10, store.require(1).state().calendarCursorEpochMinute(), "Recovery did not commit the whole ten-minute cursor.");
			PhantomAssertions.assertEquals(10L, historical.advancedMinutes(), "Crash/retry double-awarded or lost model minutes.");
			PhantomAssertions.assertEquals(1, historical.requestIds().size(), "Crash/retry created a second request identity.");
			PhantomAssertions.assertEquals(1, historical.injectedCrashes(), "Recovery replayed the injected fault.");
			PhantomAssertions.assertEquals(0, drainDue(restarted, 1).advancedIntervals(), "Scheduler ack retry advanced a completed request.");
		}
		context.record("goal033.periodicCrashRecovery", "before_save,after_save");
	}

	private void testBackgroundDueReconciliation(PhantomTestContext context)
	{
		final Instant from = Instant.parse("2026-01-05T20:00:00Z");
		final long fromMinute = minute(from);
		final PhantomPopulationTestDoubles.MemoryStore populationStore = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final ManagedSnapshot population = populationStore.seedReady(1, 1);
		final EcologyMemoryStore store = new EcologyMemoryStore(null);
		store.insert(1, stateAt(fromMinute, Pace.OUTLIER, 10_000, population.state().scheduleTemplate()));
		final HistoricalMemoryPort historical = new HistoricalMemoryPort();
		final PhantomPopulationTestDoubles.MutableClock clock = new PhantomPopulationTestDoubles.MutableClock(from);
		final PhantomPopulationEcologyService service = service(store, historical, new AtomicBoolean(), new AtomicReference<>(""), clock, Preset.LIVING, 0, 10);
		service.enablePeriodicDueMode();
		service.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
		service.register(population);
		service.onPopulationPulse();
		clock.set(from.plusSeconds(10 * 60));
		service.onPopulationPulse();
		PhantomAssertions.assertEquals(10L, historical.advancedMinutes(), "Calendar upkeep waited for a human or BACKGROUND scheduler state.");
		PhantomAssertions.assertTrue(service.permitsScheduling(1), "Automatic committed upkeep did not open scheduling.");
		PhantomAssertions.assertFalse(service.dueSnapshot(1).queued(), "Steady readiness spun in the ordinary queue.");
		PhantomAssertions.assertEquals(0, service.requestBackgroundReadiness(1).advancedIntervals(), "Readiness consumed the farm receipt.");
		final var first = service.requestBackgroundDue(1);
		PhantomAssertions.assertTrue(first.complete(), "One shared BACKGROUND due did not reconcile the whole ten-minute cursor gap.");
		PhantomAssertions.assertEquals(10, first.advancedIntervals(), "Automatic upkeep lost the periodic handler receipt.");
		PhantomAssertions.assertEquals(fromMinute + 10, store.require(1).state().calendarCursorEpochMinute(), "Durable ecology cursor stopped before the due minute.");
		final long advanced = historical.advancedMinutes();
		PhantomAssertions.assertTrue(advanced > 1, "A ten-minute due was truncated to one model minute.");
		final var duplicate = service.reconcileBackgroundDue(1);
		PhantomAssertions.assertTrue(duplicate.complete(), "Duplicate due should be a completed no-op.");
		PhantomAssertions.assertEquals(advanced, historical.advancedMinutes(), "Duplicate due applied historical intervals twice.");
		PhantomAssertions.assertEquals(3L, service.snapshot().periodicDueCalls(), "Periodic due counter lost pending/ack/duplicate dispatch.");
		PhantomAssertions.assertEquals(0, service.snapshot().periodicRunning(), "Completed due retained a running counter.");
		PhantomAssertions.assertEquals(0L, service.snapshot().periodicBlockedCalls(), "Committed upkeep was incorrectly reported as pending.");
		context.record("goal033.backgroundDueMinutes", advanced);
	}

	private void testTransientItemRetryBackoff(PhantomTestContext context)
	{
		final Instant now = Instant.parse("2026-01-05T20:30:00Z");
		final long from = minute(now) - 1;
		final long target = minute(now);
		final String requestId = "c".repeat(64);
		final PhantomPopulationTestDoubles.MemoryStore populationStore = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final ManagedSnapshot population = populationStore.seedReady(1, 1);
		final EcologyMemoryStore store = new EcologyMemoryStore(null);
		store.insert(1, stateAt(from, Pace.OUTLIER, 10_000, population.state().scheduleTemplate()).beginRequest(requestId, target));
		final PhantomBackgroundState.Hashes hashes = new PhantomBackgroundState.Hashes("knowledge", "topology", "progression", "commerce");
		final PhantomBackgroundCatchupState running = new PhantomBackgroundCatchupState(Status.RUNNING, requestId, 1, from, target, from, 0, 0, 1, 1, 1, 1, 0, "d".repeat(64), PhantomBackgroundState.MODEL_VERSION, hashes, "");
		final AtomicReference<Snapshot> catchup = new AtomicReference<>(new Snapshot(running, 0));
		final AtomicInteger attempts = new AtomicInteger();
		final AtomicBoolean busy = new AtomicBoolean(true);
		final HistoricalPort historical = new HistoricalPort()
		{
			@Override
			public Optional<Snapshot> status(long profileId)
			{
				return Optional.of(catchup.get());
			}

			@Override
			public PhantomHistoricalBackgroundService.Result begin(long profileId, long fromEpochMinute, long targetEpochMinute, long deterministicSeed)
			{
				throw new AssertionError("An existing item retry must not begin again.");
			}

			@Override
			public PhantomHistoricalBackgroundService.Result advance(long profileId, int maximumIntervals, int maximumMinutes)
			{
				attempts.incrementAndGet();
				if (busy.get())
				{
					return PhantomHistoricalBackgroundService.Result.rejected(PhantomHistoricalBackgroundService.ResultStatusCode.RETRY, "transaction.item_busy", catchup.get());
				}
				final Snapshot complete = new Snapshot(catchup.get().state().advanceTo(target), 1);
				catchup.set(complete);
				return PhantomHistoricalBackgroundService.Result.success(complete, 1);
			}
		};
		final PhantomPopulationEcologyService service = service(store, historical, new AtomicBoolean(), new AtomicReference<>(""), new PhantomPopulationTestDoubles.MutableClock(now), Preset.LIVING, 0, 1);
		service.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
		service.register(population);
		for (int pulse = 0; pulse < 20; pulse++)
		{
			service.onPopulationPulse();
		}
		PhantomAssertions.assertTrue(attempts.get() <= 6, "Transient item contention retried every population pulse.");
		PhantomAssertions.assertEquals(from, store.require(1).state().calendarCursorEpochMinute(), "Transient item contention advanced the ecology cursor.");
		busy.set(false);
		for (int pulse = 0; (pulse < 256) && store.require(1).state().requestPending(); pulse++)
		{
			service.onPopulationPulse();
		}
		PhantomAssertions.assertFalse(store.require(1).state().requestPending(), "Released item contention did not complete the existing request.");
		PhantomAssertions.assertTrue(service.permitsScheduling(1), "Completed item retry did not reopen scheduling.");
	}

	private void testTopologyBlockQuietAndResume(PhantomTestContext context)
	{
		final Instant now = Instant.parse("2026-01-05T20:30:00Z");
		final long from = minute(now) - 1;
		final long target = minute(now);
		final String requestId = "a".repeat(64);
		final PhantomPopulationTestDoubles.MemoryStore populationStore = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final ManagedSnapshot population = populationStore.seedReady(1, 1);
		final EcologyMemoryStore store = new EcologyMemoryStore(null);
		store.insert(1, stateAt(from, Pace.OUTLIER, 10_000, population.state().scheduleTemplate()).beginRequest(requestId, target));
		final PhantomBackgroundState.Hashes hashes = new PhantomBackgroundState.Hashes("knowledge", "topology", "progression", "commerce");
		final PhantomBackgroundCatchupState failed = new PhantomBackgroundCatchupState(Status.FAILED_REPLAN_REQUIRED, requestId, 1, from, target, from, 0, 0, 1, 1, 1, 1, 0, "b".repeat(64), PhantomBackgroundState.MODEL_VERSION, hashes, "planner.target_or_route.absent");
		final AtomicReference<Snapshot> catchup = new AtomicReference<>(new Snapshot(failed, 0));
		final AtomicBoolean topologyReady = new AtomicBoolean(false);
		final HistoricalPort historical = new HistoricalPort()
		{
			@Override
			public Optional<Snapshot> status(long profileId)
			{
				return Optional.of(catchup.get());
			}

			@Override
			public PhantomHistoricalBackgroundService.Result begin(long profileId, long fromEpochMinute, long targetEpochMinute, long deterministicSeed)
			{
				throw new AssertionError("An existing ecology request must not begin again.");
			}

			@Override
			public PhantomHistoricalBackgroundService.Result advance(long profileId, int maximumIntervals, int maximumMinutes)
			{
				final Snapshot current = catchup.get();
				if (current.state().status() == Status.FAILED_REPLAN_REQUIRED)
				{
					if (!topologyReady.get())
					{
						return PhantomHistoricalBackgroundService.Result.rejected(PhantomHistoricalBackgroundService.ResultStatusCode.REPLAN_REQUIRED, current.state().failureReason(), current);
					}
					final Snapshot complete = new Snapshot(current.state().withPlan(1, 0, 0, "b".repeat(64), 1, 2).advanceTo(target), current.rowVersion() + 1);
					catchup.set(complete);
					return PhantomHistoricalBackgroundService.Result.success(complete, 1);
				}
				final Snapshot complete = new Snapshot(current.state().advanceTo(target), current.rowVersion() + 1);
				catchup.set(complete);
				return PhantomHistoricalBackgroundService.Result.success(complete, 1);
			}
		};
		final PhantomPopulationEcologyService service = service(store, historical, new AtomicBoolean(), new AtomicReference<>(""), new PhantomPopulationTestDoubles.MutableClock(now), Preset.LIVING, 0, 1);
		service.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
		service.register(population);
		for (int pulse = 0; pulse < 5; pulse++)
		{
			service.onPopulationPulse();
		}
		PhantomAssertions.assertFalse(service.permitsScheduling(1), "Missing factual topology reopened scheduling.");
		PhantomAssertions.assertEquals(from, store.require(1).state().calendarCursorEpochMinute(), "Missing topology advanced ecology cursor.");
		PhantomAssertions.assertTrue(service.snapshot().failures() <= 1, "Unchanged topology absence inflated failure telemetry every pulse.");
		topologyReady.set(true);
		for (int pulse = 0; (pulse < 512) && store.require(1).state().requestPending(); pulse++)
		{
			service.onPopulationPulse();
		}
		PhantomAssertions.assertFalse(store.require(1).state().requestPending(), "Recovered topology did not complete the existing ecology request.");
		PhantomAssertions.assertTrue(service.permitsScheduling(1), "Recovered request did not reopen scheduling permission.");
	}

	private void testCatalogConfigAndCodec(PhantomTestContext context) throws Exception
	{
		PhantomAssertions.assertEquals(3, _ecology.presets().size(), "Ecology catalog does not contain three presets.");
		PhantomAssertions.assertEquals(6, _ecology.personalities().size(), "Ecology catalog does not contain six personalities.");
		PhantomAssertions.assertTrue(_ecology.requirePreset(Preset.FRESH).defaultWorldAgeDays() < _ecology.requirePreset(Preset.LIVING).defaultWorldAgeDays(), "FRESH is not younger than LIVING.");
		PhantomAssertions.assertTrue(_ecology.requirePreset(Preset.LIVING).defaultWorldAgeDays() < _ecology.requirePreset(Preset.MATURE).defaultWorldAgeDays(), "LIVING is not younger than MATURE.");
		final Path ecologyPath = context.moduleRoot().resolve("dist/game/data/phantoms/population/high-five-ecology-v1.xml");
		PhantomAssertions.assertEquals(_ecology.hash(), PhantomPopulationEcologyCatalog.load(ecologyPath, _population, _social).hash(), "Ecology authority hash changed across reload.");

		final PhantomPlayersConfig.Settings shipped = PhantomPlayersConfig.read(context.moduleRoot().resolve("dist/game/config/Custom/PhantomPlayers.ini"));
		final PhantomPlayersConfig.Settings local = PhantomPlayersConfig.read(context.moduleRoot().resolve("docs/phantoms/examples/PhantomPlayers.local-play.ini"));
		PhantomAssertions.assertFalse(shipped.enabled(), "Shipped Phantom system is enabled.");
		PhantomAssertions.assertFalse(shipped.ecologyEnabled(), "Shipped Phantom ecology is enabled.");
		PhantomAssertions.assertTrue(local.enabled() && local.ecologyEnabled(), "Local-play ecology is not enabled.");
		PhantomAssertions.assertEquals("LIVING", local.ecologyPreset(), "Local-play preset is not LIVING.");

		final Path invalidConfig = Files.createTempFile("phantom-goal033-invalid-", ".ini");
		final Path invalidCatalog = Files.createTempFile("phantom-goal033-invalid-", ".xml");
		try
		{
			Files.writeString(invalidConfig, enabledConfig("UNKNOWN"), StandardCharsets.UTF_8);
			PhantomAssertions.assertFalse(PhantomPlayersConfig.read(invalidConfig).enabled(), "Unknown ecology preset did not fail closed.");
			Files.writeString(invalidCatalog, Files.readString(ecologyPath, StandardCharsets.UTF_8).replace("<schedule id=\"evening\" weight=\"50\"/>", "<schedule id=\"unknown\" weight=\"50\"/>"), StandardCharsets.UTF_8);
			PhantomAssertions.assertThrows(IllegalArgumentException.class, () -> PhantomPopulationEcologyCatalog.load(invalidCatalog, _population, _social), "Unknown ecology schedule reference was accepted.");
		}
		finally
		{
			Files.deleteIfExists(invalidConfig);
			Files.deleteIfExists(invalidCatalog);
		}

		final PhantomPopulationEcologyState assigned = _ecology.assign(Preset.LIVING, 3, 17, SEED, minute(CREATED), -1, 0, null);
		final PhantomPopulationEcologyStateCodec codec = new PhantomPopulationEcologyStateCodec();
		PhantomAssertions.assertEquals(assigned, codec.decode(codec.encode(assigned)), "population.ecology v1 codec did not round-trip.");
		PhantomAssertions.assertThrows(IllegalArgumentException.class, () -> codec.decode(java.util.Arrays.copyOf(codec.encode(assigned), codec.encode(assigned).length + 1)), "Ecology codec accepted trailing bytes.");
		context.record("goal033.catalogHash", _ecology.hash());
		context.record("goal033.codecBytes", codec.encode(assigned).length);
	}

	private void testAssignmentAndHumanIndependence(PhantomTestContext context)
	{
		final long now = minute(Instant.parse("2026-09-01T00:00:00Z"));
		for (Preset preset : Preset.values())
		{
			final PresetDefinition definition = _ecology.requirePreset(preset);
			final Map<Pace, Integer> paces = new EnumMap<>(Pace.class);
			final Map<Personality, Integer> personalities = new EnumMap<>(Personality.class);
			final Map<String, Integer> schedules = new TreeMap<>();
			final Map<Integer, Integer> ages = new TreeMap<>();
			final List<PhantomPopulationEcologyState> firstTen = new ArrayList<>();
			for (long ordinal = 1; ordinal <= 100; ordinal++)
			{
				final PhantomPopulationEcologyState first = _ecology.assign(preset, 7, ordinal, SEED, now, -1, 0, null);
				final PhantomPopulationEcologyState restarted = _ecology.assign(preset, 7, ordinal, SEED, now, -1, 0, null);
				PhantomAssertions.assertEquals(first, restarted, "Ecology assignment changed across deterministic restart.");
				paces.merge(first.pace(), 1, Integer::sum);
				personalities.merge(first.personality(), 1, Integer::sum);
				schedules.merge(first.scheduleTemplate(), 1, Integer::sum);
				ages.merge((int) ((now - first.virtualJoinEpochMinute()) / 1440L), 1, Integer::sum);
				if (ordinal <= 10)
				{
					firstTen.add(first);
				}
			}
			definition.paces().forEach(value -> PhantomAssertions.assertEquals(value.weight(), paces.get(value.pace()), "Pace 100-slot allocation differs from configured weight."));
			definition.personalities().forEach(value -> PhantomAssertions.assertEquals(value.weight(), personalities.get(value.personality()), "Personality 100-slot allocation differs from configured weight."));
			definition.schedules().forEach(value -> PhantomAssertions.assertEquals(value.weight(), schedules.get(value.id()), "Schedule 100-slot allocation differs from configured weight."));
			PhantomAssertions.assertTrue(firstTen.stream().map(PhantomPopulationEcologyState::pace).distinct().count() >= 2, "Small population pace assignment lacks diversity.");
			PhantomAssertions.assertTrue(firstTen.stream().map(PhantomPopulationEcologyState::personality).distinct().count() >= 3, "Small population personality assignment lacks diversity.");
			PhantomAssertions.assertTrue(firstTen.stream().map(PhantomPopulationEcologyState::scheduleTemplate).distinct().count() >= 2, "Small population schedule assignment lacks diversity.");
			context.record("goal033." + preset.name().toLowerCase() + ".pace", paces);
			context.record("goal033." + preset.name().toLowerCase() + ".personality", personalities);
			context.record("goal033." + preset.name().toLowerCase() + ".schedule", schedules);
			context.record("goal033." + preset.name().toLowerCase() + ".ageDays", ages);
		}

		final List<String> canonical = assignments(Preset.LIVING, now);
		for (int humanLevel : List.of(1, 20, 40, 60, 85))
		{
			PhantomAssertions.assertEquals(canonical, assignments(Preset.LIVING, now), "Human level fixture changed independent ecology at level " + humanLevel + '.');
		}
		context.record("goal033.humanFixtures", "1,20,40,60,85 identical");
	}

	private void testPaceAndSchedule(PhantomTestContext context) throws Exception
	{
		final Map<Pace, Long> selected = new EnumMap<>(Pace.class);
		for (Pace pace : Pace.values())
		{
			final PhantomPopulationEcologyState state = findPace(pace);
			long productive = 0;
			for (long block = 0; block < 10_000; block++)
			{
				productive += _ecology.productive(state, block) ? 1 : 0;
			}
			PhantomAssertions.assertEquals((long) state.productiveShareBasisPoints(), productive, "Pace share is not exact over its deterministic cycle.");
			selected.put(pace, productive);
		}
		PhantomAssertions.assertTrue(selected.get(Pace.CASUAL) < selected.get(Pace.REGULAR) && selected.get(Pace.REGULAR) < selected.get(Pace.FAST) && selected.get(Pace.FAST) < selected.get(Pace.OUTLIER), "Pace productive exposure is not strictly ordered.");

		final EcologyMemoryStore store = new EcologyMemoryStore(null);
		final HistoricalMemoryPort historical = new HistoricalMemoryPort();
		final PhantomPopulationEcologyService service = service(store, historical, new AtomicBoolean(), new AtomicReference<>(""), new PhantomPopulationTestDoubles.MutableClock(CREATED), Preset.LIVING, 0, 10);
		final long monday = minute(Instant.parse("2026-01-05T00:00:00Z"));
		final PhantomPopulationEcologyState calendar = stateAt(monday, Pace.OUTLIER, 9500, "evening");
		final var window = service.nextProductiveWindow(calendar, 0, monday + 1440);
		PhantomAssertions.assertTrue(window.productive() && (window.startEpochMinute() > monday), "Schedule-aware search did not skip sleeping time.");
		final var evaluation = _population.evaluate("evening", Instant.ofEpochSecond(window.startEpochMinute() * 60L), ZoneOffset.UTC, 0);
		PhantomAssertions.assertTrue((evaluation.state() == PhantomActivityState.ACTIVE) || (evaluation.state() == PhantomActivityState.BACKGROUND), "Productive window escaped ACTIVE/BACKGROUND schedule authority.");

		final Map<Preset, Simulation> simulations = new EnumMap<>(Preset.class);
		for (Preset preset : Preset.values())
		{
			simulations.put(preset, simulate(preset, 128));
		}
		PhantomAssertions.assertTrue(simulations.get(Preset.FRESH).medianAgeMinutes() < simulations.get(Preset.LIVING).medianAgeMinutes(), "FRESH median virtual age is not below LIVING.");
		PhantomAssertions.assertTrue(simulations.get(Preset.LIVING).medianAgeMinutes() < simulations.get(Preset.MATURE).medianAgeMinutes(), "LIVING median virtual age is not below MATURE.");
		PhantomAssertions.assertTrue(simulations.get(Preset.FRESH).medianProductiveMinutes() < simulations.get(Preset.LIVING).medianProductiveMinutes(), "FRESH productive history is not below LIVING.");
		PhantomAssertions.assertTrue(simulations.get(Preset.LIVING).medianProductiveMinutes() < simulations.get(Preset.MATURE).medianProductiveMinutes(), "LIVING productive history is not below MATURE.");
		PhantomAssertions.assertTrue(simulations.get(Preset.MATURE).newcomers() > 0, "MATURE lost its newcomer floor.");
		context.record("goal033.paceCycle", selected);
		context.record("goal033.simulation128", simulations);
		assertNoRewardShortcut(context);
	}

	private void testCalendarRestartAndOngoing(PhantomTestContext context)
	{
		final Reconciliation uninterrupted = reconcile(false);
		final Reconciliation restarted = reconcile(true);
		PhantomAssertions.assertEquals(uninterrupted.cursor(), restarted.cursor(), "Restart changed ecology calendar cursor.");
		PhantomAssertions.assertEquals(uninterrupted.productiveMinutes(), restarted.productiveMinutes(), "Restart changed causal productive minutes.");
		PhantomAssertions.assertEquals(uninterrupted.requestIds(), restarted.requestIds(), "Restart changed deterministic Goal033A request identities.");
		PhantomAssertions.assertTrue(uninterrupted.productiveMinutes() > 0 && uninterrupted.productiveMinutes() < uninterrupted.elapsedMinutes(), "Calendar reconciliation farmed no time or all 24/7 time.");
		PhantomAssertions.assertTrue(uninterrupted.pendingFenceObserved(), "Normal scheduling was not fenced during an owned Goal033A request.");
		PhantomAssertions.assertTrue((uninterrupted.maximumProfilesPerPulse() <= _ecology.limits().maximumProfilesPerPulse()) && (uninterrupted.maximumIntervalsPerPulse() <= _ecology.limits().maximumIntervalsPerPulse()), "Ecology pulse exceeded configured bounds.");
		PhantomAssertions.assertTrue(uninterrupted.ongoingProductiveMinutes() > 0, "Future offline schedule reconciliation did not use causal productive time.");
		PhantomAssertions.assertEquals(uninterrupted.beforeMaterializedMinutes(), uninterrupted.afterMaterializedMinutes(), "Materialized normal work overlapped historical catch-up.");
		context.record("goal033.restartProductiveMinutes", restarted.productiveMinutes());
		context.record("goal033.restartRequests", restarted.requestIds().size());
		context.record("goal033.maximumPulse", restarted.maximumProfilesPerPulse() + "/" + restarted.maximumIntervalsPerPulse());
	}

	private void testTurnoverAndCap(PhantomTestContext context)
	{
		final PhantomPopulationTestDoubles.MemoryStore populationStore = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final PhantomPopulationTestDoubles.Ownership ownership = new PhantomPopulationTestDoubles.Ownership();
		final EcologyMemoryStore ecologyStore = new EcologyMemoryStore(populationStore);
		final HistoricalMemoryPort historical = new HistoricalMemoryPort();
		final AtomicBoolean materialized = new AtomicBoolean();
		final AtomicReference<String> safety = new AtomicReference<>("party");
		final PhantomPopulationTestDoubles.MutableClock clock = new PhantomPopulationTestDoubles.MutableClock(CREATED);
		PhantomPopulationEcologyService ecologyService = service(ecologyStore, historical, materialized, safety, clock, Preset.FRESH, 0, 1);
		final PhantomPopulationEcologyService firstEcology = ecologyService;
		PhantomPopulationManager manager = new PhantomPopulationManager(populationStore, _population, null, ownership, clock, ZoneOffset.UTC, 1, 0, 16, 4, 2, 64);
		manager.installEcology(ecologyService);
		PhantomAssertions.assertTrue(manager.start(), "Synthetic ecology PopulationManager did not start.");
		final long veteran = populationStore.loadManagedAfter(0, 16).get(0).profile().profileId();
		advanceToReady(manager, veteran);
		manager.onPulse();
		final long eligible = ecologyStore.require(veteran).state().turnoverEligibleEpochMinute();
		clock.set(Instant.ofEpochSecond((eligible + 1) * 60L));
		pulseUntil(manager, () -> firstEcology.permitsScheduling(veteran), 10_000, "Veteran did not converge causally before turnover safety checks.");
		PhantomAssertions.assertEquals(0, firstEcology.snapshot().archived(), "Party-blocked profile archived.");
		materialized.set(true);
		safety.set("");
		// The original ownership/archive probe refreshes on a calendar-minute edge.
		clock.set(clock.instant().plusSeconds(60));
		for (int index = 0; index < 8; index++)
		{
			manager.onPulse();
		}
		PhantomAssertions.assertEquals(0, firstEcology.snapshot().archived(), "Materialized profile archived.");
		materialized.set(false);
		clock.set(clock.instant().plusSeconds(60));
		pulseUntil(manager, () -> firstEcology.snapshot().archived() == 1, 256, "Safe eligible veteran did not archive.");
		pulseUntil(manager, () -> populationStore.size() == 2, 256, "PopulationManager did not create a replacement shell.");
		final long replacement = populationStore.loadManagedAfter(veteran, 16).get(0).profile().profileId();
		PhantomAssertions.assertEquals(Disposition.ARCHIVED, ecologyStore.require(veteran).state().disposition(), "Veteran ecology disposition was not durable ARCHIVED.");
		PhantomAssertions.assertEquals(PhantomPopulationState.State.RETIRED, populationStore.reload(veteran).state().state(), "Archived population was not durable RETIRED.");
		PhantomAssertions.assertEquals(veteran, ecologyStore.require(replacement).state().replacesProfileId(), "Replacement did not retain archived predecessor identity.");
		PhantomAssertions.assertEquals("archive_limit", firstEcology.snapshot().turnoverPaused(), "Archive cap did not pause turnover.");
		stop(manager);

		ecologyService = service(ecologyStore, historical, materialized, safety, clock, Preset.MATURE, -1, 1);
		manager = new PhantomPopulationManager(populationStore, _population, null, ownership, clock, ZoneOffset.UTC, 1, 0, 16, 4, 2, 64);
		manager.installEcology(ecologyService);
		PhantomAssertions.assertTrue(manager.start(), "Restarted synthetic ecology PopulationManager did not start.");
		for (int index = 0; index < 12; index++)
		{
			manager.onPulse();
		}
		PhantomAssertions.assertEquals(2, populationStore.size(), "Archived profile was returned or duplicated after restart.");
		PhantomAssertions.assertEquals(Disposition.ARCHIVED, ecologyStore.require(veteran).state().disposition(), "Restart lost archived disposition.");
		PhantomAssertions.assertEquals(Preset.FRESH, ecologyStore.require(veteran).state().preset(), "Config change rerolled existing ecology assignment.");
		stop(manager);
		context.record("goal033.turnover", "managed=1 archived=1 replacement=" + replacement);
	}

	private void testPersonality(PhantomTestContext context)
	{
		final long now = minute(CREATED);
		PhantomPopulationEcologyState assignment = null;
		for (long ordinal = 1; ordinal <= 100; ordinal++)
		{
			final PhantomPopulationEcologyState candidate = _ecology.assign(Preset.LIVING, 1, ordinal, SEED, now, 0, 0, null);
			if (candidate.personality() == Personality.SOCIAL)
			{
				assignment = candidate;
				break;
			}
		}
		PhantomAssertions.assertTrue(assignment != null, "LIVING cycle did not contain SOCIAL personality.");
		final long profileId = 91;
		final Map<Integer, Integer> expected = _ecology.personalityTraits(assignment, profileId);
		PhantomAssertions.assertEquals(assignment.initialSocialTraits(), expected, "Durable ecology assignment did not freeze the initial Social trait vector.");
		PhantomAssertions.assertEquals(6, expected.size(), "Ecology personality did not initialize every Social trait.");
		PhantomAssertions.assertTrue(expected.values().stream().allMatch(value -> (value >= PhantomSocialModel.MIN_VALUE) && (value <= PhantomSocialModel.MAX_VALUE)), "Ecology personality escaped Social trait bounds.");

		final PhantomSocialTestDoubles.MemoryStore socialStore = new PhantomSocialTestDoubles.MemoryStore();
		socialStore.addProfile(profileId);
		PhantomSocialService service = new PhantomSocialService(_social, socialStore, 1, 16);
		PhantomAssertions.assertTrue(service.start(), "Social service did not start for ecology personality test.");
		service.installPersonalityInitializer(id -> expected);
		final var initialized = service.ensurePersonality(profileId);
		PhantomAssertions.assertTrue(initialized.available(), "Ecology-influenced Social personality was not created.");
		final Map<String, Integer> first = initialized.value().traits();
		service.beginStop();
		PhantomAssertions.assertTrue(service.finishStop(), "Social service did not stop after ecology initialization.");

		service = new PhantomSocialService(_social, socialStore, 1, 16);
		PhantomAssertions.assertTrue(service.start(), "Restarted Social service did not start.");
		service.installPersonalityInitializer(id -> Map.of(1, -9999, 2, -9999, 3, -9999, 4, -9999, 5, -9999, 6, -9999));
		final var restarted = service.ensurePersonality(profileId);
		PhantomAssertions.assertTrue(restarted.available(), "Existing durable Social personality was not available after restart.");
		PhantomAssertions.assertEquals(first, restarted.value().traits(), "Existing durable Social state rerolled after initializer/config change.");
		service.beginStop();
		PhantomAssertions.assertTrue(service.finishStop(), "Restarted Social service did not stop.");
		context.record("goal033.socialTraits", first);
	}

	private void testStaticFences(PhantomTestContext context) throws Exception
	{
		final Path root = context.moduleRoot();
		final String service = Files.readString(root.resolve("java/org/l2jmobius/gameserver/phantoms/population/PhantomPopulationEcologyService.java"), StandardCharsets.UTF_8);
		final String system = Files.readString(root.resolve("java/org/l2jmobius/gameserver/phantoms/PhantomSystem.java"), StandardCharsets.UTF_8);
		final String manager = Files.readString(root.resolve("java/org/l2jmobius/gameserver/phantoms/population/PhantomPopulationManager.java"), StandardCharsets.UTF_8);
		final String progression = Files.readString(root.resolve("java/org/l2jmobius/gameserver/phantoms/progression/PhantomProgressionModel.java"), StandardCharsets.UTF_8);
		PhantomAssertions.assertTrue(service.contains("onPopulationPulse()") && manager.contains("_ecology.onPopulationPulse();"), "Ecology is not driven by the existing PopulationManager pulse.");
		PhantomAssertions.assertTrue(manager.contains("READY_RELOAD") && manager.contains("_ownership.reload(action.profileId())"), "Decision runtime is not reloaded before a completed ecology fence reopens scheduling.");
		PhantomAssertions.assertFalse(service.contains("ScheduledExecutor") || service.contains("new Thread") || service.contains("TimerTask") || service.contains("CompletableFuture"), "Ecology added an independent scheduler/thread.");
		PhantomAssertions.assertTrue(system.contains("new PhantomPopulationEcologyStore(productionProfiles)") && system.contains("_historicalBackgroundService"), "Production ecology is not composed over Goal033A and profile components.");
		PhantomAssertions.assertTrue(system.contains("installPersonalityInitializer(_populationEcology::initialPersonalityTraits)"), "Production Social initialization seam is not ecology-aware.");
		PhantomAssertions.assertTrue(progression.contains("CANONICAL_QUEST_REQUIRED"), "Goal036 profession boundary disappeared.");
		context.record("goal033.productionComposition", "population pulse + Goal033A + Social initializer");
	}

	private void testIdleCalendarCatchupFence(PhantomTestContext context)
	{
		final Instant now = Instant.parse("2026-01-05T03:01:00Z");
		final long previousMinute = minute(now) - 1;
		final PhantomPopulationTestDoubles.MemoryStore populationStore = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final ManagedSnapshot population = populationStore.seedReady(1, 1);
		final EcologyMemoryStore store = new EcologyMemoryStore(null);
		store.insert(1, stateAt(previousMinute, Pace.CASUAL, 1, population.state().scheduleTemplate()));
		final PhantomPopulationTestDoubles.MutableClock clock = new PhantomPopulationTestDoubles.MutableClock(now);
		final PhantomPopulationEcologyService service = service(store, new HistoricalMemoryPort(), new AtomicBoolean(), new AtomicReference<>(""), clock, Preset.LIVING, 0, 10);
		final AtomicInteger fenceChanges = new AtomicInteger();
		service.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), new PhantomPopulationEcologyService.PopulationEvents()
		{
			@Override
			public void requestArchive(long profileId)
			{
			}

			@Override
			public void reconcilePopulation()
			{
			}

			@Override
			public void ecologyFenceChanged(long profileId)
			{
				PhantomAssertions.assertEquals(1L, profileId, "Idle calendar catch-up reported the wrong profile.");
				fenceChanges.incrementAndGet();
			}
		});
		service.register(population);
		PhantomAssertions.assertFalse(service.permitsScheduling(1), "Stale idle ecology cursor unexpectedly permitted scheduling.");
		loadMetadata(service, 1);
		PhantomAssertions.assertEquals(0, fenceChanges.get(), "Metadata setup opened the stale idle schedule fence.");
		service.onPopulationPulse();
		PhantomAssertions.assertTrue(service.permitsScheduling(1), "Idle ecology calendar did not catch up to the current minute.");
		PhantomAssertions.assertEquals(1, fenceChanges.get(), "Idle ecology permit transition did not reopen the population schedule fence exactly once.");
		context.record("goal034.idleCalendarFenceChanges", fenceChanges.get());
	}

	private void testRestartExistingEcologyFences(PhantomTestContext context)
	{
		final Instant now = Instant.parse("2026-01-05T20:30:00Z");
		final long nowMinute = minute(now);
		final PhantomPopulationTestDoubles.MemoryStore populationStore = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final EcologyMemoryStore store = new EcologyMemoryStore(null);
		final List<ManagedSnapshot> populations = new ArrayList<>();
		final List<Long> eligible = new ArrayList<>();
		for (long profileId = 1; profileId <= 10; profileId++)
		{
			final ManagedSnapshot population = populationStore.seedReady(profileId, Math.toIntExact(profileId));
			populations.add(population);
			store.insert(profileId, stateAt(nowMinute, Pace.OUTLIER, 10_000, population.state().scheduleTemplate()));
			if (_population.evaluate(population.state().scheduleTemplate(), now, ZoneOffset.UTC, population.state().schedulePhaseMinutes()).state() == PhantomActivityState.ACTIVE)
			{
				eligible.add(profileId);
			}
		}
		PhantomAssertions.assertTrue(eligible.size() >= 5, "Restart fixture does not contain at least five ACTIVE durable schedules.");

		final PhantomPopulationTestDoubles.MutableClock clock = new PhantomPopulationTestDoubles.MutableClock(now);
		final PhantomPopulationEcologyService service = service(store, new HistoricalMemoryPort(), new AtomicBoolean(), new AtomicReference<>(""), clock, Preset.LIVING, 0, 10);
		final List<Long> fenceChanges = new ArrayList<>();
		final AtomicInteger reconciliations = new AtomicInteger();
		service.installRuntime(profileId -> populations.stream().filter(population -> population.profile().profileId() == profileId).findFirst(), new PhantomPopulationEcologyService.PopulationEvents()
		{
			@Override
			public void requestArchive(long profileId)
			{
			}

			@Override
			public void reconcilePopulation()
			{
				reconciliations.incrementAndGet();
			}

			@Override
			public void ecologyFenceChanged(long profileId)
			{
				fenceChanges.add(profileId);
			}
		});
		populations.forEach(service::register);
		PhantomAssertions.assertFalse(service.inventoryReady(), "Restart ecology inventory was ready before durable rows loaded.");
		for (int pulse = 0; (pulse < 32) && !service.inventoryReady(); pulse++)
		{
			service.onPopulationPulse();
			if (!service.inventoryReady())
			{
				PhantomAssertions.assertFalse(service.requestBackgroundReadiness(1).complete(), "Partial restored census admitted direct background readiness.");
				PhantomAssertions.assertEquals(0, fenceChanges.size(), "Partial restored census published a native schedule permit.");
			}
		}
		PhantomAssertions.assertTrue(service.inventoryReady(), "Restart ecology inventory did not load through bounded population pulses.");
		PhantomAssertions.assertEquals(1, reconciliations.get(), "Restored inventory readiness did not reconcile population exactly once.");
		for (long profileId : eligible)
		{
			PhantomAssertions.assertTrue(service.permitsScheduling(profileId), "Loaded eligible ecology row did not permit scheduling: " + profileId);
		}
		// Completion notifications use the retained ordinary queue, bounded by the original profile budget.
		final int notificationBatches = (populations.size() + _ecology.limits().maximumProfilesPerPulse() - 1) / _ecology.limits().maximumProfilesPerPulse();
		for (int batch = 0; batch < notificationBatches; batch++)
		{
			final int before = fenceChanges.size();
			service.onPopulationPulse();
			PhantomAssertions.assertTrue(fenceChanges.size() - before <= _ecology.limits().maximumProfilesPerPulse(), "Restore permission notifications exceeded the ordinary profile budget.");
		}
		final List<Long> distinctFenceChanges = fenceChanges.stream().distinct().sorted().toList();
		PhantomAssertions.assertEquals(eligible, distinctFenceChanges, "Restart restore did not reopen every eligible READY schedule fence.");
		final int changesAfterRestore = fenceChanges.size();
		service.onPopulationPulse();
		PhantomAssertions.assertEquals(1, reconciliations.get(), "No-op ecology pulse repeated population reconciliation.");
		PhantomAssertions.assertEquals(changesAfterRestore, fenceChanges.size(), "No-op ecology pulse repeated scheduling-permission refreshes.");

		clock.set(now.plusSeconds(60));
		for (int pulse = 0; (pulse < 32) && eligible.stream().anyMatch(profileId -> fenceChanges.stream().filter(profileId::equals).count() < 2); pulse++)
		{
			service.onPopulationPulse();
		}
		for (long profileId : eligible)
		{
			PhantomAssertions.assertTrue(fenceChanges.stream().filter(profile -> profile == profileId).count() >= 2, "Beginning catch-up did not publish a closing schedule-fence edge: " + profileId);
		}
		for (int pulse = 0; (pulse < 32) && eligible.stream().anyMatch(profileId -> fenceChanges.stream().filter(profileId::equals).count() < 3); pulse++)
		{
			service.onPopulationPulse();
		}
		for (long profileId : eligible)
		{
			PhantomAssertions.assertTrue(service.permitsScheduling(profileId), "Completing catch-up did not reopen the schedule fence: " + profileId);
			PhantomAssertions.assertEquals(3L, fenceChanges.stream().filter(profile -> profile == profileId).count(), "Catch-up did not publish exactly one close/reopen edge pair: " + profileId);
		}
		PhantomAssertions.assertEquals(changesAfterRestore * 3, fenceChanges.size(), "Catch-up completion did not publish exactly one reopening permission edge per eligible profile.");
		final int changesAfterCatchup = fenceChanges.size();
		service.onPopulationPulse();
		PhantomAssertions.assertEquals(changesAfterCatchup, fenceChanges.size(), "Post-catch-up no-op pulse repeated scheduling-permission refreshes.");
		context.record("goal034.restartExistingFenceChanges", fenceChanges);
		context.record("goal034.restartExistingReconciliations", reconciliations.get());
	}

	private Reconciliation reconcile(boolean restart)
	{
		final PhantomPopulationTestDoubles.MemoryStore populationStore = new PhantomPopulationTestDoubles.MemoryStore(_population.hash());
		final ManagedSnapshot population = populationStore.seedReady(1, 1);
		final EcologyMemoryStore store = new EcologyMemoryStore(null);
		final HistoricalMemoryPort historical = new HistoricalMemoryPort();
		final AtomicBoolean materialized = new AtomicBoolean();
		final AtomicReference<String> safety = new AtomicReference<>("");
		final PhantomPopulationTestDoubles.MutableClock clock = new PhantomPopulationTestDoubles.MutableClock(Instant.parse("2026-01-03T00:00:00Z"));
		PhantomPopulationEcologyService service = service(store, historical, materialized, safety, clock, Preset.LIVING, 0, 10);
		service.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
		service.register(population);
		boolean pendingFence = false;
		for (int pulse = 0; pulse < 10_000 && !service.permitsScheduling(1); pulse++)
		{
			service.onPopulationPulse();
			pendingFence |= store.optional(1).map(StoredState::state).map(PhantomPopulationEcologyState::requestPending).orElse(false) && !service.permitsScheduling(1);
			if (restart && store.optional(1).map(StoredState::state).map(PhantomPopulationEcologyState::requestPending).orElse(false))
			{
				service = service(store, historical, materialized, safety, clock, Preset.MATURE, -1, 10);
				service.installRuntime(id -> id == 1 ? Optional.of(population) : Optional.empty(), noEvents());
				service.register(population);
				restart = false;
			}
		}
		PhantomAssertions.assertTrue(service.permitsScheduling(1), "Two-day ecology reconciliation did not converge.");
		final long initialMinutes = historical.advancedMinutes();
		clock.set(Instant.parse("2026-01-04T23:59:00Z"));
		for (int pulse = 0; pulse < 10_000 && !service.permitsScheduling(1); pulse++)
		{
			service.onPopulationPulse();
		}
		PhantomAssertions.assertTrue(service.permitsScheduling(1), "Ongoing future reconciliation did not converge.");
		final long ongoing = historical.advancedMinutes() - initialMinutes;
		final long beforeMaterialized = historical.advancedMinutes();
		materialized.set(true);
		clock.set(Instant.parse("2026-01-05T12:00:00Z"));
		service.onPopulationPulse();
		final long afterMaterialized = historical.advancedMinutes();
		final var snapshot = service.snapshot();
		return new Reconciliation(store.require(1).state().calendarCursorEpochMinute(), initialMinutes, minute(Instant.parse("2026-01-03T00:00:00Z")) - minute(CREATED), List.copyOf(historical.requestIds()), pendingFence, snapshot.maximumPulseProfiles(), snapshot.maximumPulseIntervals(), ongoing, beforeMaterialized, afterMaterialized);
	}

	private Simulation simulate(Preset preset, int profiles)
	{
		final long now = minute(Instant.parse("2026-09-01T00:00:00Z"));
		final List<Long> ages = new ArrayList<>();
		final List<Long> productive = new ArrayList<>();
		int newcomers = 0;
		long total = 0;
		for (long ordinal = 1; ordinal <= profiles; ordinal++)
		{
			final PhantomPopulationEcologyState state = _ecology.assign(preset, 9, ordinal, SEED, now, -1, 0, null);
			final long age = now - state.virtualJoinEpochMinute();
			long minutes = 0;
			for (long cursor = state.virtualJoinEpochMinute(); cursor < now; cursor += state.productiveBlockMinutes())
			{
				final long duration = Math.min(state.productiveBlockMinutes(), now - cursor);
				final var evaluation = _population.evaluate(state.scheduleTemplate(), Instant.ofEpochSecond(cursor * 60L), ZoneOffset.UTC, 0);
				if (((evaluation.state() == PhantomActivityState.ACTIVE) || (evaluation.state() == PhantomActivityState.BACKGROUND)) && _ecology.productive(state, Math.floorDiv(cursor, state.productiveBlockMinutes())))
				{
					minutes += duration;
				}
			}
			ages.add(age);
			productive.add(minutes);
			total += minutes;
			newcomers += state.newcomer(now, _ecology.requirePreset(preset).newcomerDays()) ? 1 : 0;
		}
		ages.sort(Long::compare);
		productive.sort(Long::compare);
		return new Simulation(profiles, ages.get(profiles / 2), productive.get(profiles / 2), total, newcomers);
	}

	private List<String> assignments(Preset preset, long now)
	{
		final List<String> values = new ArrayList<>();
		for (long ordinal = 1; ordinal <= 32; ordinal++)
		{
			final PhantomPopulationEcologyState state = _ecology.assign(preset, 7, ordinal, SEED, now, -1, 0, null);
			values.add(state.virtualJoinEpochMinute() + ":" + state.pace() + ":" + state.personality() + ":" + state.scheduleTemplate() + ":" + state.turnoverEligibleEpochMinute());
		}
		return List.copyOf(values);
	}

	private PhantomPopulationEcologyState findPace(Pace pace)
	{
		for (long ordinal = 1; ordinal <= 100; ordinal++)
		{
			final PhantomPopulationEcologyState state = _ecology.assign(Preset.LIVING, 1, ordinal, SEED, minute(CREATED), 0, 0, null);
			if (state.pace() == pace)
			{
				return state;
			}
		}
		throw new AssertionError("Missing pace in deterministic cycle: " + pace);
	}

	private PhantomPopulationEcologyState stateAt(long minute, Pace pace, int share, String schedule)
	{
		return new PhantomPopulationEcologyState(_ecology.hash(), Preset.LIVING, 1, 1, minute, minute, minute, minute, pace, share, _ecology.limits().productiveBlockMinutes(), Personality.BALANCED, Map.of(1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0), schedule, Disposition.MANAGED, minute + 10_000, 0, "", 0, 0, 0, "");
	}

	private PhantomPopulationEcologyService service(PersistencePort store, HistoricalPort historical, AtomicBoolean materialized, AtomicReference<String> safety, PhantomPopulationTestDoubles.MutableClock clock, Preset preset, int worldAgeDays, int archiveLimit)
	{
		return new PhantomPopulationEcologyService(_ecology, _population, store, historical, id -> materialized.get(), id -> safety.get(), clock, ZoneOffset.UTC, preset, worldAgeDays, archiveLimit, worker -> { worker.run(); return true; });
	}

	/** Deterministic dispatcher drain belongs to the fixture, never to production request APIs. */
	private static void loadMetadata(PhantomPopulationEcologyService service, int profiles)
	{
		final int allowance = service.snapshot().metadataAllowance();
		final int batches = (profiles + allowance - 1) / allowance;
		for (int batch = 0; batch < batches; batch++) { service.onPopulationPulse(); }
		final var metadata = service.snapshot();
		PhantomAssertions.assertTrue(metadata.inventoryReady(), "Explicit metadata setup did not complete its bounded full census.");
		PhantomAssertions.assertEquals(profiles, metadata.registeredProfiles(), "Metadata setup changed the registered denominator.");
		PhantomAssertions.assertEquals(0, metadata.unloadedProfiles(), "Metadata setup retained unloaded rows.");
		PhantomAssertions.assertEquals((long) profiles, metadata.metadataPublications(), "Metadata setup did not publish each identity once.");
		PhantomAssertions.assertTrue(metadata.maximumMetadataBatch() <= allowance, "Metadata setup exceeded its allowance.");
		PhantomAssertions.assertEquals(0L, metadata.profileOperations(), "Metadata setup entered the ordinary route.");
		PhantomAssertions.assertEquals(0L, metadata.historicalIntervals(), "Metadata setup advanced historical intervals.");
		PhantomAssertions.assertEquals(0L, metadata.productiveMinutes(), "Metadata setup awarded productive minutes.");
		PhantomAssertions.assertEquals(0L, metadata.calendarMinutes(), "Metadata setup changed the calendar cursor.");
	}

	/** One original ordinary pulse; metadata setup is explicit at relevant cold-start callsites. */
	private static PhantomPopulationEcologyService.DueReconciliation drainDue(PhantomPopulationEcologyService service, long profileId)
	{
		final var requested = service.requestBackgroundDue(profileId);
		if (requested.complete()) { return requested; }
		service.onPopulationPulse();
		return service.requestBackgroundDue(profileId);
	}

	private static PhantomPopulationEcologyService.PopulationEvents noEvents()
	{
		return new PhantomPopulationEcologyService.PopulationEvents()
		{
			@Override
			public void requestArchive(long profileId)
			{
			}

			@Override
			public void reconcilePopulation()
			{
			}

			@Override
			public void ecologyFenceChanged(long profileId)
			{
			}
		};
	}

	private static void advanceToReady(PhantomPopulationManager manager, long profileId)
	{
		for (int step = 0; step < 8; step++)
		{
			final ManagedSnapshot current = manager.find(profileId).orElseThrow();
			if (current.state().state() == PhantomPopulationState.State.READY)
			{
				return;
			}
			manager.advanceCreation(profileId);
		}
		throw new AssertionError("Synthetic replacement did not reach READY.");
	}

	private static void pulseUntil(PhantomPopulationManager manager, java.util.function.BooleanSupplier condition, int maximumPulses, String failure)
	{
		for (int pulse = 0; (pulse < maximumPulses) && !condition.getAsBoolean(); pulse++)
		{
			manager.onPulse();
		}
		PhantomAssertions.assertTrue(condition.getAsBoolean(), failure);
	}

	private static void stop(PhantomPopulationManager manager)
	{
		manager.beginStop();
		PhantomAssertions.assertTrue(manager.finishStop(), "Synthetic ecology PopulationManager did not stop.");
	}

	private static void assertNoRewardShortcut(PhantomTestContext context) throws Exception
	{
		final Path directory = context.moduleRoot().resolve("java/org/l2jmobius/gameserver/phantoms/population");
		final List<String> banned = List.of("setLevel(", "addExp", "setExp(", "teleToLocation(", "exp *=", "drop *=", "rewardMultiplier", "humanLevel");
		try (var paths = Files.list(directory))
		{
			for (Path path : paths.filter(value -> value.getFileName().toString().startsWith("PhantomPopulationEcology") && value.getFileName().toString().endsWith(".java")).toList())
			{
				final String source = Files.readString(path, StandardCharsets.UTF_8);
				for (String token : banned)
				{
					PhantomAssertions.assertFalse(source.contains(token), "Ecology source contains forbidden reward/rubber-band shortcut: " + token);
				}
			}
		}
	}

	private static String enabledConfig(String preset)
	{
		return """
			EnablePhantomSystem = True
			EnablePhantomDiagnostics = False
			MaxMaterializedPhantoms = 32
			MaxScheduledPhantomProfiles = 10000
			PhantomSchedulerPulseMillis = 100
			PhantomSchedulerProfilesPerPulse = 128
			PhantomPopulationTarget = 10
			PhantomPopulationActiveTarget = 5
			PhantomPopulationCreationInFlight = 2
			PhantomPopulationBoundariesPerPulse = 64
			PhantomPartyOperationsPerPulse = 64
			PhantomSocialCacheProfiles = 1024
			PhantomPopulationTimeZone = UTC
			EnablePhantomEcology = True
			PhantomEcologyPreset = %s
			PhantomEcologyWorldAgeDays = -1
			PhantomEcologyArchiveLimit = 1000
			""".formatted(preset);
	}

	private static long minute(Instant instant)
	{
		return instant.toEpochMilli() / MINUTE_MILLIS;
	}

	private record Simulation(int profiles, long medianAgeMinutes, long medianProductiveMinutes, long totalProductiveMinutes, int newcomers)
	{
	}

	private record Reconciliation(long cursor, long productiveMinutes, long elapsedMinutes, List<String> requestIds, boolean pendingFenceObserved, int maximumProfilesPerPulse, int maximumIntervalsPerPulse, long ongoingProductiveMinutes, long beforeMaterializedMinutes, long afterMaterializedMinutes)
	{
	}

	public static final class EcologyMemoryStore implements PersistencePort
	{
		private final Map<Long, StoredState> _states = new LinkedHashMap<>();
		private final PhantomPopulationTestDoubles.MemoryStore _population;
		private boolean _raceNextSave;

		public EcologyMemoryStore(PhantomPopulationTestDoubles.MemoryStore population)
		{
			_population = population;
		}

		@Override
		public synchronized Optional<StoredState> load(long profileId)
		{
			return Optional.ofNullable(_states.get(profileId));
		}

		@Override
		public synchronized StoredState insert(long profileId, PhantomPopulationEcologyState state)
		{
			return _states.computeIfAbsent(profileId, id -> new StoredState(state, 0));
		}

		@Override
		public synchronized StoredState save(long profileId, StoredState expected, PhantomPopulationEcologyState replacement)
		{
			if (_raceNextSave)
			{
				_raceNextSave = false;
				_states.put(profileId, new StoredState(expected.state(), expected.rowVersion() + 1));
			}
			if (_states.get(profileId) != expected)
			{
				throw new java.util.ConcurrentModificationException("Synthetic ecology row version changed.");
			}
			final StoredState saved = new StoredState(replacement, expected.rowVersion() + 1);
			_states.put(profileId, saved);
			return saved;
		}

		@Override
		public synchronized ArchivedResult archive(ManagedSnapshot population, StoredState ecology, long archiveGeneration, long nowEpochMinute)
		{
			final PhantomPopulationEcologyState archived = ecology.state().archived(archiveGeneration, nowEpochMinute, "ecology.turnover");
			final StoredState saved = save(population.profile().profileId(), ecology, archived);
			final ManagedSnapshot retired;
			if (_population != null)
			{
				retired = _population.updateState(population, population.state().retired());
			}
			else
			{
				final PhantomProfileComponent component = new PhantomProfileComponent(population.profile().profileId(), PhantomPopulationState.COMPONENT_TYPE, PhantomPopulationState.SCHEMA_VERSION, population.component().rowVersion() + 1, new byte[0], CREATED, CREATED);
				retired = new ManagedSnapshot(population.profile(), component, population.state().retired());
			}
			return new ArchivedResult(retired, saved);
		}

		private synchronized StoredState require(long profileId)
		{
			return Optional.ofNullable(_states.get(profileId)).orElseThrow();
		}

		private synchronized Optional<StoredState> optional(long profileId)
		{
			return Optional.ofNullable(_states.get(profileId));
		}
	}

	public static final class HistoricalMemoryPort implements HistoricalPort
	{
		private static final PhantomBackgroundState.Hashes HASHES = new PhantomBackgroundState.Hashes("knowledge", "topology", "progression", "commerce");
		private final Map<Long, Snapshot> _states = new HashMap<>();
		private final List<String> _requestIds = new ArrayList<>();
		private long _advancedMinutes;
		private Boolean _crashAfterSaveOnce;
		private int _injectedCrashes;

		private synchronized void crashNextAdvance(boolean afterSave)
		{
			_crashAfterSaveOnce = afterSave;
		}

		@Override
		public synchronized Optional<Snapshot> status(long profileId)
		{
			return Optional.ofNullable(_states.get(profileId));
		}

		@Override
		public synchronized PhantomHistoricalBackgroundService.Result begin(long profileId, long fromEpochMinute, long targetEpochMinute, long deterministicSeed)
		{
			final String requestId = digest(profileId + ":" + fromEpochMinute + ":" + targetEpochMinute + ":" + deterministicSeed);
			final Snapshot existing = _states.get(profileId);
			if ((existing != null) && existing.state().requestId().equals(requestId))
			{
				return PhantomHistoricalBackgroundService.Result.success(existing, 0);
			}
			if ((existing != null) && (existing.state().status() != Status.COMPLETE))
			{
				return PhantomHistoricalBackgroundService.Result.rejected(PhantomHistoricalBackgroundService.ResultStatusCode.CONFLICT, "synthetic.conflict", existing);
			}
			final PhantomBackgroundCatchupState state = new PhantomBackgroundCatchupState(Status.PENDING, requestId, deterministicSeed, fromEpochMinute, targetEpochMinute, fromEpochMinute, 0, 0, 1, 1, 1, 1, 0, digest("plan"), PhantomBackgroundState.MODEL_VERSION, HASHES, "").running();
			final Snapshot created = new Snapshot(state, existing == null ? 0 : existing.rowVersion() + 1);
			_states.put(profileId, created);
			_requestIds.add(requestId);
			return PhantomHistoricalBackgroundService.Result.success(created, 0);
		}

		@Override
		public synchronized PhantomHistoricalBackgroundService.Result advance(long profileId, int maximumIntervals, int maximumMinutes)
		{
			final Snapshot current = Optional.ofNullable(_states.get(profileId)).orElseThrow();
			final long remaining = current.state().targetEpochMinute() - current.state().cursorEpochMinute();
			final int advanced = Math.toIntExact(Math.min(remaining, Math.min(maximumIntervals, maximumMinutes)));
			if (Boolean.FALSE.equals(_crashAfterSaveOnce))
			{
				_crashAfterSaveOnce = null;
				_injectedCrashes++;
				throw new IllegalStateException("synthetic.crash_before_durable_save");
			}
			final Snapshot saved = new Snapshot(current.state().advanceTo(current.state().cursorEpochMinute() + advanced), current.rowVersion() + 1);
			_states.put(profileId, saved);
			_advancedMinutes += advanced;
			if (Boolean.TRUE.equals(_crashAfterSaveOnce))
			{
				_crashAfterSaveOnce = null;
				_injectedCrashes++;
				throw new IllegalStateException("synthetic.crash_after_durable_save");
			}
			return PhantomHistoricalBackgroundService.Result.success(saved, advanced);
		}

		private synchronized int injectedCrashes()
		{
			return _injectedCrashes;
		}

		private synchronized long advancedMinutes()
		{
			return _advancedMinutes;
		}

		private synchronized List<String> requestIds()
		{
			return List.copyOf(_requestIds);
		}

		private static String digest(String value)
		{
			try
			{
				return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
			}
			catch (Exception exception)
			{
				throw new IllegalStateException(exception);
			}
		}
	}
}
