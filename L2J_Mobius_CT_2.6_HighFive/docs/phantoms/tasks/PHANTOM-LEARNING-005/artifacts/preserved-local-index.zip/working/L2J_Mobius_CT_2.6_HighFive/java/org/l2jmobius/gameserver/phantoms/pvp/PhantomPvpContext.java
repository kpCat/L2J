/*
 * Copyright (c) 2013 L2jMobius
 */
package org.l2jmobius.gameserver.phantoms.pvp;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.l2jmobius.gameserver.model.World;
import org.l2jmobius.gameserver.model.actor.Player;
import org.l2jmobius.gameserver.model.actor.instance.Monster;
import org.l2jmobius.gameserver.phantoms.navigation.L2jNavigationBackend;
import org.l2jmobius.gameserver.phantoms.navigation.PhantomNativeTravelActions;
import org.l2jmobius.gameserver.phantoms.navigation.PhantomNavigationPoint;

import org.l2jmobius.gameserver.phantoms.combat.PhantomCombatBackend.ActorSnapshot;
import org.l2jmobius.gameserver.phantoms.combat.PhantomCombatBackend.PvpConsequenceSnapshot;
import org.l2jmobius.gameserver.phantoms.combat.PhantomCombatBackend.PvpTargetSnapshot;
import org.l2jmobius.gameserver.phantoms.combat.PhantomCombatMode;
import org.l2jmobius.gameserver.phantoms.combat.PhantomCombatService;
import org.l2jmobius.gameserver.phantoms.combat.PhantomCombatService.PvpObservation;
import org.l2jmobius.gameserver.phantoms.combat.PhantomCombatService.PvpObservedTarget;
import org.l2jmobius.gameserver.phantoms.decision.PhantomDomainRef;
import org.l2jmobius.gameserver.phantoms.farming.PhantomFarmingService;
import org.l2jmobius.gameserver.phantoms.farming.PhantomFarmingService.PvpEscalationEvidence;
import org.l2jmobius.gameserver.phantoms.party.PhantomPartyCoordinator;
import org.l2jmobius.gameserver.phantoms.party.PhantomPartyCoordinator.PvpProtectionEvidence;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.MemberKind;
import org.l2jmobius.gameserver.phantoms.player.PhantomMaterializationService;
import org.l2jmobius.gameserver.phantoms.pvp.PhantomPvpModel.Candidate;
import org.l2jmobius.gameserver.phantoms.pvp.PhantomPvpModel.Counterpart;
import org.l2jmobius.gameserver.phantoms.pvp.PhantomPvpModel.CounterpartKind;
import org.l2jmobius.gameserver.phantoms.pvp.PhantomPvpModel.RiskSnapshot;
import org.l2jmobius.gameserver.phantoms.pvp.PhantomPvpModel.Source;
import org.l2jmobius.gameserver.phantoms.social.PhantomPvpSocialBridge;
import org.l2jmobius.gameserver.phantoms.social.PhantomPvpSocialBridge.RevengeEvidence;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialModel.SubjectRef;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialModel.SubjectKind;

/**
 * Deterministic bounded causal-source join. It never scans World players or the
 * profile registry; all identities are exact lookups supplied by owner seams.
 */
public final class PhantomPvpContext
{
	public record Snapshot(Candidate candidate, RiskSnapshot risk, PhantomCombatMode mode, SubjectRef socialSubject, PhantomDomainRef conversationCounterpart, PhantomDomainRef helpCounterpart, String sourceEvidenceHash)
	{
		public Snapshot
		{
			Objects.requireNonNull(candidate);
			Objects.requireNonNull(risk);
			Objects.requireNonNull(mode);
			Objects.requireNonNull(socialSubject);
			Objects.requireNonNull(conversationCounterpart);
			if (!socialSubject.equals(subject(candidate.counterpart()))) { throw new IllegalArgumentException("PvP counterpart and social identity differ."); }
			sourceEvidenceHash = PhantomPvpModel.boundedHash(sourceEvidenceHash);
		}
	}

	private record SourceEvidence(Source source, int targetObjectId, String authorityHash, long expiryLogicalNanos, PhantomDomainRef helpCounterpart, SubjectRef expectedSubject)
	{
	}
	/** Exact native evidence at successful tactical arrival, bounded by the existing profile owner. */
	record RetreatRecovery(Counterpart counterpart, long incomingDamageNanos, double threatDistance)
	{
	}

	private static final long NANOS_PER_MINUTE = 60_000_000_000L;
	private final PhantomPvpPolicy _policy;
	private final PhantomCombatService _combat;
	private final PhantomPartyCoordinator _party;
	private final PhantomFarmingService _farming;
	private final PhantomPvpSocialBridge _social;
	private final PhantomMaterializationService _materialization;

	public PhantomPvpContext(PhantomPvpPolicy policy, PhantomCombatService combat, PhantomPartyCoordinator party, PhantomFarmingService farming, PhantomPvpSocialBridge social, PhantomMaterializationService materialization)
	{
		_policy = Objects.requireNonNull(policy);
		_combat = Objects.requireNonNull(combat);
		_party = Objects.requireNonNull(party);
		_farming = Objects.requireNonNull(farming);
		_social = Objects.requireNonNull(social);
		_materialization = Objects.requireNonNull(materialization);
	}

	public Optional<Snapshot> observe(long profileId, long logicalNanos)
	{
		return observe(profileId, logicalNanos, null, _ -> true);
	}
	Optional<Snapshot> observeAvailable(long profileId, long logicalNanos, java.util.function.Predicate<Candidate> admissible)
	{
		return observe(profileId, logicalNanos, null, admissible);
	}

	Optional<Snapshot> observeOwned(PhantomPvpModel.Encounter encounter, long logicalNanos)
	{
		return observe(encounter.profileId(), logicalNanos, encounter, _ -> true);
	}

	/** Exact owner/counterpart lookup only; retreat must not choose a direction from a stale target. */
	Optional<PhantomNavigationPoint> retreatThreat(PhantomPvpModel.Encounter encounter)
	{
		final Player actor = retreatActor(encounter.profileId()); final var target = World.getInstance().getPlayer(encounter.counterpart().currentObjectId());
		if (actor == null || target == null || target == actor || !target.isSpawned() || target.isAlikeDead() || target.isInvisible() || target.getInstanceId() != actor.getInstanceId() || actor.getWorldRegion() == null || !actor.getWorldRegion().isSurroundingRegion(target.getWorldRegion())) { return Optional.empty(); }
		return Optional.of(PhantomNativeTravelActions.point(target));
	}
	Optional<RetreatRecovery> retreatRecovery(PhantomPvpModel.Encounter encounter)
	{
		final Player actor = retreatActor(encounter.profileId()); final var threat = retreatThreat(encounter).orElse(null);
		return actor == null || threat == null ? Optional.empty() : Optional.of(new RetreatRecovery(encounter.counterpart(), actor.recentPlayerAttackNanos(encounter.counterpart().currentObjectId()), PhantomNativeTravelActions.point(actor).distanceTo(threat)));
	}

	boolean retreatWaypointSafe(long profileId, PhantomNavigationPoint waypoint)
	{
		final Player actor = retreatActor(profileId);
		return actor != null && !actor.isInStoreMode() && !actor.hasPendingOwnedStore() && actor.getInstanceId() == waypoint.instanceId()
			&& new L2jNavigationBackend().canWalkDirect(PhantomNativeTravelActions.point(actor), waypoint)
			&& PhantomNativeTravelActions.safePveWalkSegment(actor, waypoint.x(), waypoint.y(), waypoint.z(), List.copyOf(World.getInstance().getVisibleObjectsInRange(actor, Monster.class, 1200)), Set.of());
	}

	private Player retreatActor(long profileId)
	{
		final var lifetime = _materialization.find(profileId).orElse(null);
		if (lifetime == null || !lifetime.worldPresent() || !lifetime.actionAdmissionOpen()) { return null; }
		final var actor = World.getInstance().getPlayer(lifetime.characterObjectId());
		return actor != null && !actor.isAlikeDead() && actor.getNativeWorkOwner() != null && actor.getNativeWorkOwner().isCurrent() ? actor : null;
	}

	private Optional<Snapshot> observe(long profileId, long logicalNanos, PhantomPvpModel.Encounter owned, java.util.function.Predicate<Candidate> admissible)
	{
		if ((profileId <= 0) || (logicalNanos < 0))
		{
			return Optional.empty();
		}
		final long minute = logicalNanos / NANOS_PER_MINUTE;
		final List<PvpProtectionEvidence> partyEvidence = _party.pvpProtection(profileId, _policy.limits().helpFanout());
		final PvpEscalationEvidence farmingEvidence = _farming.pvpEscalation(profileId, minute).orElse(null);
		final Map<Integer, SourceEvidence> exact = new HashMap<>();
		for (PvpProtectionEvidence evidence : partyEvidence)
		{
			final var member = evidence.directive().targetMember();
			final PhantomDomainRef help = member.kind() == MemberKind.PHANTOM ? new PhantomDomainRef("profile", Long.toString(member.profileId())) : new PhantomDomainRef("character.object", Integer.toString(member.characterObjectId()));
			exact.putIfAbsent(evidence.directive().targetObjectId(), new SourceEvidence(Source.PARTY_DEFENSE, evidence.directive().targetObjectId(), evidence.authorityHash(), expiry(logicalNanos, _policy.limits().encounterTtlSeconds()), help, null));
		}
		if (farmingEvidence != null)
		{
			final var counterpart = _materialization.find(farmingEvidence.counterpartProfileId()).orElse(null);
			if ((counterpart != null) && counterpart.worldPresent())
			{
				exact.putIfAbsent(counterpart.characterObjectId(), new SourceEvidence(Source.FARMING_ESCALATION, counterpart.characterObjectId(), farmingEvidence.authorityHash(), Math.min(expiry(logicalNanos, _policy.limits().encounterTtlSeconds()), minuteNanos(farmingEvidence.expiryMinute())), null, null));
			}
		}
		// Existing party/farming owner inputs keep their slots; memory only fills the remaining bound.
		exact.keySet().retainAll(exact.keySet().stream().sorted().limit(10).toList());
		if (owned == null)
		{
			for (RevengeEvidence evidence : _social.revengeSources(profileId, minute))
			{
				if (exact.size() >= 10) { break; }
				final var remembered = evidence.subject();
				final var lifetime = remembered.kind() == SubjectKind.PHANTOM_PROFILE ? _materialization.find(remembered.id()).orElse(null) : null;
				final int objectId = remembered.kind() == SubjectKind.CHARACTER_OBJECT ? (int) remembered.id() : lifetime != null && lifetime.worldPresent() ? lifetime.characterObjectId() : 0;
				if ((objectId > 0) && remembered.equals(subject(objectId)))
				{
					exact.putIfAbsent(objectId, new SourceEvidence(Source.REVENGE, objectId, evidence.authorityHash(), Math.min(expiry(logicalNanos, _policy.limits().encounterTtlSeconds()), minuteNanos(evidence.expiryMinute())), null, remembered));
				}
			}
		}
		for (RevengeEvidence revenge : _social.revengeCandidates(profileId, 10, minute))
		{
			final SubjectRef subject = revenge.subject();
			final var counterpart = subject.kind() == org.l2jmobius.gameserver.phantoms.social.PhantomSocialModel.SubjectKind.PHANTOM_PROFILE ? _materialization.find(subject.id()).filter(lifetime -> lifetime.worldPresent()).orElse(null) : null;
			final int targetObjectId = subject.kind() == org.l2jmobius.gameserver.phantoms.social.PhantomSocialModel.SubjectKind.CHARACTER_OBJECT ? Math.toIntExact(subject.id()) : counterpart == null ? 0 : counterpart.characterObjectId();
			if (targetObjectId > 0)
			{
				exact.putIfAbsent(targetObjectId, new SourceEvidence(Source.REVENGE, targetObjectId, revenge.authorityHash(), Math.min(expiry(logicalNanos, _policy.limits().encounterTtlSeconds()), minuteNanos(revenge.expiryMinute())), null));
			}
		}
		final List<Integer> exactTargets = exact.values().stream().sorted(Comparator.comparingInt((SourceEvidence evidence) -> priority(evidence.source())).thenComparingInt(SourceEvidence::targetObjectId)).limit(10).map(SourceEvidence::targetObjectId).sorted().toList();
		final PvpObservation observation = (owned == null
			? _combat.observePvp(profileId, exactTargets, _policy.limits().observedAttackerLimit(), _policy.limits().localRiskPlayerLimit())
			: _combat.observeOwnedPvp(profileId, owned.counterpart().currentObjectId(), owned.authorityHash(), _policy.limits().observedAttackerLimit(), _policy.limits().localRiskPlayerLimit())).orElse(null);
		if ((observation == null) || observation.supportedModes().isEmpty())
		{
			return Optional.empty();
		}
		final List<ObservedEvidence> candidates = new ArrayList<>();
		for (PvpObservedTarget observed : observation.targets())
		{
			final int targetObjectId = observed.target().objectId();
			if (observed.actualAttacker())
			{
				final String attackAuthority = PhantomPvpModel.sha256("pvp.actual.attack", observation.actor().objectId(), targetObjectId, observation.actor().instanceId());
				candidates.add(new ObservedEvidence(new SourceEvidence(Source.ACTUAL_ATTACK, targetObjectId, attackAuthority, expiry(logicalNanos, _policy.limits().encounterTtlSeconds()), null, null), observed));
			}
			if (observed.declaredClanWar())
			{
				candidates.add(new ObservedEvidence(new SourceEvidence(Source.CLAN_WAR, targetObjectId, PhantomPvpModel.sha256("pvp.native.clan-war", observation.actor().objectId(), targetObjectId, observation.actor().instanceId()), expiry(logicalNanos, _policy.limits().encounterTtlSeconds()), null, null), observed));
			}
			final SourceEvidence supplied = exact.get(targetObjectId);
			if (supplied != null)
			{
				candidates.add(new ObservedEvidence(supplied, observed));
			}
			if (observed.selectedTarget())
			{
				final SubjectRef subject = subject(targetObjectId);
				final RevengeEvidence revenge = _social.revenge(profileId, subject, minute).orElse(null);
				if (revenge != null)
				{
					candidates.add(new ObservedEvidence(new SourceEvidence(Source.REVENGE, targetObjectId, revenge.authorityHash(), Math.min(expiry(logicalNanos, _policy.limits().encounterTtlSeconds()), minuteNanos(revenge.expiryMinute())), null, subject), observed));
				}
			}
		}
		candidates.sort(Comparator.comparingInt((ObservedEvidence item) -> priority(item._source.source())).thenComparingInt(item -> item._source.targetObjectId()).thenComparing(item -> item._source.authorityHash()));
		for (ObservedEvidence selected : candidates)
		{
			final Snapshot snapshot = snapshot(profileId, logicalNanos, observation, selected);
			if ((snapshot != null) && snapshot.candidate().currentAt(logicalNanos) && snapshot.risk().legal() && admissible.test(snapshot.candidate()))
			{
				// Already-owned warnings retain their admission. A new dispute needs real disposition/memory.
				if (owned == null && (snapshot.candidate().source() == Source.FARMING_ESCALATION || snapshot.candidate().source() == Source.REVENGE) && !_social.allowsProactiveDispute(profileId, snapshot.socialSubject(), minute, snapshot.candidate().source() == Source.FARMING_ESCALATION)) { continue; }
				return Optional.of(snapshot);
			}
		}
		return Optional.empty();
	}

	private Snapshot snapshot(long profileId, long logicalNanos, PvpObservation observation, ObservedEvidence selected)
	{
		final PvpTargetSnapshot target = selected._target.target();
		final ActorSnapshot actor = observation.actor();
		final Counterpart counterpart = counterpart(target.objectId());
		final SubjectRef socialSubject = subject(counterpart);
		if ((selected._source.expectedSubject() != null) && !selected._source.expectedSubject().equals(socialSubject)) { return null; }
		final String authority = PhantomPvpModel.sha256("pvp.current.authority", _policy.hash(), selected._source.source(), selected._source.authorityHash(), actor.objectId(), counterpart.kind(), counterpart.identity(), target.objectId(), actor.instanceId());
		final long expires = Math.min(selected._source.expiryLogicalNanos(), expiry(logicalNanos, _policy.limits().encounterTtlSeconds()));
		if (expires <= logicalNanos)
		{
			return null;
		}
		final boolean resolvable = target.player() && target.exactKnowledge() && !target.dead() && !target.alikeDead() && (target.instanceId() == actor.instanceId());
		final boolean visible = !target.invisible() && target.surroundingRegion();
		final Candidate candidate = new Candidate(profileId, counterpart, selected._source.source(), authority, logicalNanos, expires, true, resolvable, visible);
		final RiskSnapshot risk = risk(observation, selected._target);
		final PhantomDomainRef conversation = counterpart.kind() == CounterpartKind.PHANTOM_PROFILE ? new PhantomDomainRef("profile", Long.toString(counterpart.identity())) : new PhantomDomainRef("character.object", Integer.toString(counterpart.currentObjectId()));
		return new Snapshot(candidate, risk, observation.supportedModes().getFirst(), socialSubject, conversation, selected._source.helpCounterpart(), selected._source.authorityHash());
	}

	private RiskSnapshot risk(PvpObservation observation, PvpObservedTarget observed)
	{
		final ActorSnapshot actor = observation.actor();
		final PvpTargetSnapshot target = observed.target();
		final int hp = percent(actor.currentHp(), actor.maximumHp());
		final int effective = percent(actor.currentHp() + actor.currentCp(), actor.maximumHp() + actor.maximumCp());
		final int mp = percent(actor.currentMp(), actor.maximumMp());
		final int strength = clamp((int) Math.round((observation.actorLevel() * 10000.0) / target.level()), 0, 20000);
		final int forcedPk = forcedPkRisk(observed.consequences(), target.autoAttackable());
		return new RiskSnapshot(hp, effective, mp, target.hpBand(), target.effectivePoolBand(), strength, forcedPk, observed.localSupport().actorSupport(), observed.localSupport().targetSupport(), target.sameParty(), target.self(), target.peaceRestricted(), observed.canonicalContextAllowed(), target.autoAttackable());
	}

	private static int forcedPkRisk(PvpConsequenceSnapshot consequences, boolean autoAttackable)
	{
		if (autoAttackable)
		{
			return 0;
		}
		final int pkThreshold = Math.max(1, consequences.minimumPkForDrop());
		final int pkExposure = clamp((consequences.pkKills() * 2500) / pkThreshold, 0, 2500);
		final int karmaThreshold = Math.max(1, consequences.karmaDropLimit());
		final int karmaExposure = clamp((consequences.karma() * 2500) / karmaThreshold, 0, 2500);
		final int configuredDropExposure = clamp((int) Math.round(Math.max(consequences.weaponDropChance(), Math.max(consequences.equipmentDropChance(), consequences.inventoryDropChance())) * 100), 0, 2500);
		return clamp(1000 + pkExposure + karmaExposure + configuredDropExposure, 0, 10000);
	}

	private Counterpart counterpart(int objectId)
	{
		final var materialized = _materialization.findByCharacterObjectId(objectId).orElse(null);
		return (materialized != null) && materialized.worldPresent() ? new Counterpart(CounterpartKind.PHANTOM_PROFILE, materialized.profileId(), objectId) : new Counterpart(CounterpartKind.HUMAN_OBJECT, objectId, objectId);
	}

	private SubjectRef subject(int objectId)
	{
		return subject(counterpart(objectId));
	}

	private static SubjectRef subject(Counterpart counterpart)
	{
		return counterpart.kind() == CounterpartKind.PHANTOM_PROFILE ? SubjectRef.phantom(counterpart.identity()) : SubjectRef.character(counterpart.currentObjectId());
	}

	private static long expiry(long now, int seconds)
	{
		try
		{
			return Math.addExact(now, Math.multiplyExact(seconds, 1_000_000_000L));
		}
		catch (ArithmeticException exception)
		{
			return Long.MAX_VALUE;
		}
	}

	private static long minuteNanos(long minute)
	{
		try
		{
			return Math.multiplyExact(minute, NANOS_PER_MINUTE);
		}
		catch (ArithmeticException exception)
		{
			return Long.MAX_VALUE;
		}
	}

	private static int priority(Source source)
	{
		return switch (source)
		{
			case ACTUAL_ATTACK -> 0;
			case PARTY_DEFENSE -> 1;
			case FARMING_ESCALATION -> 2;
			case CLAN_WAR -> 3;
			case REVENGE -> 4;
		};
	}

	private static int percent(double current, double maximum)
	{
		return maximum <= 0 ? 0 : clamp((int) Math.round((current * 100) / maximum), 0, 100);
	}

	private static int clamp(int value, int minimum, int maximum)
	{
		return Math.max(minimum, Math.min(maximum, value));
	}

	private record ObservedEvidence(SourceEvidence _source, PvpObservedTarget _target)
	{
	}
}
