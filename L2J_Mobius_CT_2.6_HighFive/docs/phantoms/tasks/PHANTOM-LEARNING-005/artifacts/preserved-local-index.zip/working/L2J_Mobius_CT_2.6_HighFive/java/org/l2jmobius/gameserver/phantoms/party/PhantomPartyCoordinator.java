/*
 * Copyright (c) 2013 L2jMobius
 */
package org.l2jmobius.gameserver.phantoms.party;

import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

import org.l2jmobius.gameserver.model.groups.PartyDistributionType;
import org.l2jmobius.gameserver.model.groups.PartyInvitationDelivery;
import org.l2jmobius.gameserver.model.groups.PartyInvitationDelivery.DeliveryOutcome;
import org.l2jmobius.gameserver.model.groups.PartyInvitationDelivery.PartyInvitation;
import org.l2jmobius.gameserver.model.groups.PartyInvitationDelivery.PreparationOutcome;
import org.l2jmobius.gameserver.model.groups.PartyInvitationDelivery.TerminalOutcome;
import org.l2jmobius.gameserver.model.groups.PartyInvitationService;
import org.l2jmobius.gameserver.model.groups.PartyInvitationService.DeliveryRegistration;
import org.l2jmobius.gameserver.model.groups.PartyInvitationService.InvitationIdentity;
import org.l2jmobius.gameserver.model.groups.PartyInvitationService.InviteResult;
import org.l2jmobius.gameserver.model.groups.PartyInvitationService.MembershipOutcome;
import org.l2jmobius.gameserver.model.groups.PartyInvitationService.Response;
import org.l2jmobius.gameserver.phantoms.activity.PhantomSchedulerControlPort;
import org.l2jmobius.gameserver.phantoms.combat.PhantomCombatRequest;
import org.l2jmobius.gameserver.phantoms.combat.PhantomCombatService;
import org.l2jmobius.gameserver.phantoms.combat.PhantomCombatService.ExternalActionLease;
import org.l2jmobius.gameserver.phantoms.decision.PhantomCancellationToken;
import org.l2jmobius.gameserver.phantoms.decision.PhantomDomainRef;
import org.l2jmobius.gameserver.phantoms.decision.PhantomGoal;
import org.l2jmobius.gameserver.phantoms.decision.PhantomGoalStatus;
import org.l2jmobius.gameserver.phantoms.decision.PhantomGoalStore;
import org.l2jmobius.gameserver.phantoms.decision.PhantomGoalStore.StoredGoal;
import org.l2jmobius.gameserver.phantoms.party.PhantomPartyBackend.PartySnapshot;
import org.l2jmobius.gameserver.phantoms.party.PhantomPartyPersistencePort.StoredPartyState;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.DirectiveKind;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.CompanionCommand;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.CompanionMode;
import org.l2jmobius.gameserver.phantoms.navigation.PhantomNavigationPoint;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.MemberKind;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.MemberRef;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.MemberSnapshot;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.ObjectiveMode;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.OperationKind;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.OperationPhase;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.PartyOperation;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.PartyState;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.RoleAssignment;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.RoleMatchResult;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.RoleRequirement;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.RouteManifest;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.StateStatus;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.TacticalDirective;
import org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialAffiliationContextPort;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialEventSink;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialModel;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialModel.SocialEvent;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialModel.SubjectRef;

/**
 * Single-pulse party saga owner. It has no worker, timer or scheduled future.
 */
public final class PhantomPartyCoordinator implements PhantomSchedulerControlPort, PartyInvitationDelivery, PhantomPartyParticipationPort
{
	// Native invitation sequences are process-local. Distinguish new events after an ordinary JVM restart.
	private static final String INVITATION_SESSION = java.util.UUID.randomUUID().toString();
	public static final String FORM_GOAL = "party.form";
	public static final String JOIN_GOAL = "party.join";
	public static final String LEAD_GOAL = "party.lead";
	public static final String MEMBER_GOAL = "party.member";
	public static final String TRAVEL_GOAL = "party.travel";
	public static final String LEAVE_GOAL = "party.leave";
	public static final String EXPEL_GOAL = "party.expel_member";
	public static final String TRANSFER_LEADER_GOAL = "party.transfer_leader";
	private static final String ZERO_HASH = "0".repeat(64);
	private static final int PAGE_SIZE = 256;
	private static final int MAX_INBOUND_INVITES = 4096;
	private static final int MAX_TERMINAL_EVENTS = 4096;
	private static final int MAX_DUE_GROUPS = 4096;

	public enum State
	{
		NEW,
		RUNNING,
		STOPPING,
		STOPPED
	}

	public enum CompanionCommandOutcome
	{
		HOLDING,
		FOLLOWING,
		PENDING,
		REJECTED,
		STALE
	}

	/** Admit one current leader's intent without replacing a companion's party goal. */
	public CompanionCommandOutcome commandCompanion(long profileId, MemberRef speaker, long expectedGeneration, CompanionMode requested, String requestId)
	{
		final OperationClaim control = beginOperation();
		if (control == null)
		{
			return CompanionCommandOutcome.STALE;
		}
		try (control)
		{
			final StoredPartyState claim = _claims.get(profileId);
			final MemberRef actor = _backend.currentMember(profileId).orElse(null);
			final PartySnapshot nativeParty = actor == null ? null : _backend.observe(actor).orElse(null);
			final MemberSnapshot actorState = actor == null ? null : _backend.memberSnapshot(actor).orElse(null);
			final MemberSnapshot speakerState = speaker == null ? null : _backend.memberSnapshot(speaker).orElse(null);
			if (!committedClaim(claim) || (actor == null) || (actorState == null) || (speakerState == null) || actorState.dead() || speakerState.dead() || actor.equals(speaker) || (actorState.instanceId() != speakerState.instanceId()) || (nativeParty == null) || !nativeParty.leader().equals(speaker) || !nativeParty.members().contains(actor) || !claim.state().leader().equals(speaker) || (claim.state().groupGeneration() != expectedGeneration) || !claim.state().phantomMembers().contains(actor) || !Set.of(CompanionMode.HOLD, CompanionMode.FOLLOW).contains(requested))
			{
				return CompanionCommandOutcome.REJECTED;
			}
			final CompanionCommand previous = claim.state().command();
			if ((previous != null) && previous.actor().equals(actor) && previous.speaker().equals(speaker) && (previous.groupGeneration() == expectedGeneration) && ((requested == CompanionMode.FOLLOW) == (previous.mode() == CompanionMode.FOLLOW)))
			{
				advanceCompanionCommand(claim);
				return companionOutcome(profileId);
			}
			final CompanionCommand command = new CompanionCommand(requested == CompanionMode.FOLLOW ? CompanionMode.FOLLOW : CompanionMode.PENDING_HOLD, actor, speaker, Math.addExact(claim.rowVersion(), 1), expectedGeneration, new PhantomNavigationPoint(actorState.x(), actorState.y(), actorState.z(), actorState.instanceId()), _routes.holdRadius(), requestId);
			final StoredPartyState saved = save(profileId, claim.rowVersion(), claim.state().withCommand(command));
			putClaim(saved);
			if (requested == CompanionMode.FOLLOW)
			{
				_routes.cancelFollow(claim.state().groupId(), expectedGeneration, profileId);
			}
			else
			{
				advanceCompanionCommand(saved);
			}
			return companionOutcome(profileId);
		}
		catch (IllegalArgumentException exception)
		{
			return CompanionCommandOutcome.REJECTED;
		}
		catch (RuntimeException exception)
		{
			_metrics.conflict();
			return CompanionCommandOutcome.STALE;
		}
	}

	private CompanionCommandOutcome companionOutcome(long profileId)
	{
		final StoredPartyState claim = _claims.get(profileId);
		final CompanionCommand command = claim == null ? null : claim.state().command();
		if (command == null) { return CompanionCommandOutcome.STALE; }
		if (command.mode() == CompanionMode.FOLLOW) { return CompanionCommandOutcome.FOLLOWING; }
		final MemberSnapshot actor = _backend.memberSnapshot(command.actor()).orElse(null);
		return (command.mode() == CompanionMode.HOLD) && (actor != null) && !actor.moving() && !actor.casting() && !actor.attacking() && (command.anchor().distanceTo(new PhantomNavigationPoint(actor.x(), actor.y(), actor.z(), actor.instanceId())) <= command.radius()) ? CompanionCommandOutcome.HOLDING : CompanionCommandOutcome.PENDING;
	}

	private boolean holdsMovement(long profileId)
	{
		final StoredPartyState claim = _claims.get(profileId);
		return (claim != null) && (claim.state().command() != null) && (claim.state().command().mode() != CompanionMode.FOLLOW);
	}

	/** Support requests share the current party owner's movement restriction. */
	public boolean holdsPosition(long profileId)
	{
		return holdsMovement(profileId);
	}

	private boolean commandStopsCombat(long profileId)
	{
		if (!holdsMovement(profileId)) { return false; }
		return _backend.currentMember(profileId).flatMap(_backend::memberSnapshot).map(actor -> !actor.casting() && !actor.attacking()).orElse(true);
	}

	private void advanceCompanionCommand(StoredPartyState claim)
	{
		final CompanionCommand command = claim.state().command();
		if (command == null) { return; }
		final MemberRef current = _backend.currentMember(claim.profileId()).orElse(null);
		final MemberSnapshot actor = current == null ? null : _backend.memberSnapshot(current).orElse(null);
		final MemberSnapshot speaker = _backend.memberSnapshot(command.speaker()).orElse(null);
		final PartySnapshot party = current == null ? null : _backend.observe(current).orElse(null);
		if (!command.actor().equals(current) || (actor == null) || actor.dead() || (speaker == null) || speaker.dead() || (actor.instanceId() != command.anchor().instanceId()) || (actor.instanceId() != speaker.instanceId()) || (party == null) || !party.leader().equals(command.speaker()) || !party.members().contains(command.actor()))
		{
			try { putClaim(save(claim.profileId(), claim.rowVersion(), claim.state().withCommand(null))); }
			catch (RuntimeException exception) { _metrics.conflict(); }
			return;
		}
		if ((command.mode() != CompanionMode.PENDING_HOLD) || actor.casting() || actor.attacking()) { return; }
		_routes.cancelMemberMovement(claim.state().groupId(), claim.state().groupGeneration(), claim.profileId());
		final TacticalCombatClaim combat = _tacticalCombat.get(claim.profileId());
		if ((combat != null) && combat.operationKey().startsWith(tacticalScope(claim.state()))) { cancelTacticalCombat(combat); }
		final MemberSnapshot settled = _backend.memberSnapshot(current).orElse(null);
		if ((settled == null) || settled.moving() || settled.casting() || settled.attacking()) { return; }
		final CompanionCommand held = new CompanionCommand(CompanionMode.HOLD, command.actor(), command.speaker(), command.version(), command.groupGeneration(), new PhantomNavigationPoint(settled.x(), settled.y(), settled.z(), settled.instanceId()), command.radius(), command.requestId());
		try { putClaim(save(claim.profileId(), claim.rowVersion(), claim.state().withCommand(held))); }
		catch (RuntimeException exception) { _metrics.conflict(); }
	}

	private int advanceCompanionCommands(PartySnapshot party, int budget)
	{
		int examined = 0;
		for (MemberRef member : party.members())
		{
			if (examined >= budget) { break; }
			if (member.kind() != MemberKind.PHANTOM) { continue; }
			final StoredPartyState claim = _claims.get(member.profileId());
			if ((claim != null) && (claim.state().command() != null)) { advanceCompanionCommand(claim); examined++; }
		}
		return examined;
	}

	public enum CommandOutcome
	{
		ACCEPTED,
		IDEMPOTENT,
		NOT_RUNNING,
		GOAL_MISMATCH,
		STALE_GENERATION,
		CLAIM_EXISTS,
		NOT_LEADER,
		ROSTER_FULL,
		CANONICAL_REJECTED,
		PERSISTENCE_CONFLICT,
		TARGET_UNAVAILABLE
	}

	public enum PendingResponse
	{
		ACCEPT,
		REFUSE
	}

	public enum PendingResponseOutcome
	{
		COMPLETED,
		REJECTED,
		STALE,
		IDEMPOTENT,
		STOPPING
	}

	public enum RouteOutcome
	{
		READY,
		PENDING,
		FAILED,
		REJECTED,
		NOT_RUNNING,
		NOT_PHANTOM_LEADER,
		UNAVAILABLE
	}

	public record RouteRequestResult(RouteOutcome outcome, String routeId, long generation, PhantomDomainRef destination, org.l2jmobius.gameserver.phantoms.navigation.PhantomNavigationResult.Status navigationStatus, String reasonKey)
	{
	}

	public record PvpProtectionEvidence(TacticalDirective directive, long partyGeneration, String authorityHash)
	{
	}
	public enum ContentBindingOutcome
	{
		BOUND,
		IDEMPOTENT,
		NOT_RUNNING,
		GOAL_MISMATCH,
		CANONICAL_MISMATCH,
		CLAIM_CONFLICT,
		OPERATION_CONFLICT,
		PERSISTENCE_CONFLICT
	}

	public enum OperationStability
	{
		STABLE,
		PENDING,
		CONFLICT
	}

	public enum ManagedInvitationDecision
	{
		ACCEPT,
		REFUSE,
		DEFER,
		UNSUPPORTED
	}

	public record ContentBindingRequest(long leaderProfileId, long goalId, long goalRevision, String goalType, ObjectiveMode objectiveMode, PhantomDomainRef objectiveRef, List<RoleRequirement> requirements, MemberRef expectedLeader, List<MemberRef> expectedRoster, PartyDistributionType distribution, String rosterEvidenceHash)
	{
		public ContentBindingRequest
		{
			if ((leaderProfileId <= 0) || (goalId <= 0) || (goalRevision < 0) || !"rift.prepare".equals(goalType))
			{
				throw new IllegalArgumentException("Invalid content binding identity.");
			}
			Objects.requireNonNull(objectiveMode);
			Objects.requireNonNull(objectiveRef);
			requirements = List.copyOf(requirements);
			Objects.requireNonNull(expectedLeader);
			expectedRoster = List.copyOf(expectedRoster);
			Objects.requireNonNull(distribution);
			PhantomPartyModel.requireHash(rosterEvidenceHash, "Content binding roster evidence");
		}
	}

	public record ContentBindingResult(ContentBindingOutcome outcome, String groupId, long groupGeneration, long membershipRevision, MemberRef leader, String rosterEvidenceHash, String manifestHash, OperationStability stability, String reasonKey)
	{
		public boolean bound()
		{
			return (outcome == ContentBindingOutcome.BOUND) || (outcome == ContentBindingOutcome.IDEMPOTENT);
		}
	}

	public record ManagedInvitationContext(PartyInvitation invitation, long requesterProfileId, long inviteeProfileId, PartyState leaderClaim, PartyState inviteeClaim, PhantomGoal inviteeGoal, MemberSnapshot inviteeSnapshot)
	{
	}

	@FunctionalInterface
	public interface ManagedInvitationPolicy
	{
		ManagedInvitationDecision evaluate(ManagedInvitationContext context);
	}

	@FunctionalInterface
	public interface ManagedInvitationPolicyRegistration extends AutoCloseable
	{
		@Override
		void close();
	}
	private final PhantomPartyPersistencePort _store;
	private final PhantomGoalStore _goals;
	private final PhantomPartyBackend _backend;
	private final PhantomPartyRoleMatcher _roles;
	private final PhantomPartyRoleCatalog _roleCatalog;
	private final PhantomPartyRouteCoordinator _routes;
	private final PhantomPartyTactics _tactics;
	private final Supplier<String> _topologyHash;
	private final LongSupplier _clock;
	private final PhantomSocialEventSink _socialEvents;
	private final PhantomSocialAffiliationContextPort _affiliationContexts;
	private final LongSupplier _socialClock;
	private final LongSupplier _regroupEpochMillis;
	private final int _operationBudget;
	private final ArrayBlockingQueue<ManagedInvitation> _inbound = new ArrayBlockingQueue<>(MAX_INBOUND_INVITES);
	private final Map<Long, PartyInvitation> _pendingManagedInvitations = new ConcurrentHashMap<>();
	private final Map<String, ManagedInvitationPolicy> _managedInvitationPolicies = new ConcurrentHashMap<>();
	private final LinkedHashMap<ConversationResponseKey, PendingResponseOutcome> _conversationResponses = new LinkedHashMap<>();
	private final ArrayBlockingQueue<TerminalEvent> _terminalEvents = new ArrayBlockingQueue<>(MAX_TERMINAL_EVENTS);
	private final ArrayBlockingQueue<Long> _tacticalReleases = new ArrayBlockingQueue<>(MAX_INBOUND_INVITES);
	private final Map<Long, StoredPartyState> _claims = new ConcurrentHashMap<>();
	private final Map<String, GroupRuntime> _groups = new ConcurrentHashMap<>();
	private final Map<Long, ExternalActionLease> _tacticalActions = new ConcurrentHashMap<>();
	private final Map<Long, TacticalCombatClaim> _tacticalCombat = new ConcurrentHashMap<>();
	private final Object _indexLock = new Object();
	private final Object _lifecycleLock = new Object();
	private final Map<String, NavigableMap<Long, StoredPartyState>> _claimsByGroup = new HashMap<>();
	private final ArrayDeque<String> _dueGroups = new ArrayDeque<>();
	private final Set<String> _dueGroupSet = new HashSet<>();
	private final AtomicInteger _operationClaims = new AtomicInteger();
	private final AtomicInteger _persistenceClaims = new AtomicInteger();
	private final AtomicLong _socialEventsRecorded = new AtomicLong();
	private final AtomicLong _socialEventFailures = new AtomicLong();
	private final PhantomPartyMetrics _metrics = new PhantomPartyMetrics();
	private volatile State _state = State.NEW;
	private volatile DeliveryRegistration _deliveryRegistration;
	private volatile int _lastPulseExamined;
	private volatile int _maximumPulseExamined;
	private int _pulseLane;

	public PhantomPartyCoordinator(PhantomPartyPersistencePort store, PhantomGoalStore goals, PhantomPartyBackend backend, PhantomPartyRoleCatalog roleCatalog, PhantomPartyRouteCoordinator routes, PhantomPartyTactics tactics, Supplier<String> topologyHash, LongSupplier clock, int operationBudget)
	{
		this(store, goals, backend, roleCatalog, routes, tactics, topologyHash, clock, operationBudget, PhantomSocialEventSink.noop(), () -> System.currentTimeMillis() / 60000L, PhantomSocialAffiliationContextPort.noop());
	}

	public PhantomPartyCoordinator(PhantomPartyPersistencePort store, PhantomGoalStore goals, PhantomPartyBackend backend, PhantomPartyRoleCatalog roleCatalog, PhantomPartyRouteCoordinator routes, PhantomPartyTactics tactics, Supplier<String> topologyHash, LongSupplier clock, int operationBudget, PhantomSocialEventSink socialEvents, LongSupplier socialClock)
	{
		this(store, goals, backend, roleCatalog, routes, tactics, topologyHash, clock, operationBudget, socialEvents, socialClock, PhantomSocialAffiliationContextPort.noop());
	}

	public PhantomPartyCoordinator(PhantomPartyPersistencePort store, PhantomGoalStore goals, PhantomPartyBackend backend, PhantomPartyRoleCatalog roleCatalog, PhantomPartyRouteCoordinator routes, PhantomPartyTactics tactics, Supplier<String> topologyHash, LongSupplier clock, int operationBudget, PhantomSocialEventSink socialEvents, LongSupplier socialClock, PhantomSocialAffiliationContextPort affiliationContexts)
	{
		this(store, goals, backend, roleCatalog, routes, tactics, topologyHash, clock, operationBudget, socialEvents, socialClock, affiliationContexts, System::currentTimeMillis);
	}

	public PhantomPartyCoordinator(PhantomPartyPersistencePort store, PhantomGoalStore goals, PhantomPartyBackend backend, PhantomPartyRoleCatalog roleCatalog, PhantomPartyRouteCoordinator routes, PhantomPartyTactics tactics, Supplier<String> topologyHash, LongSupplier clock, int operationBudget, PhantomSocialEventSink socialEvents, LongSupplier socialClock, PhantomSocialAffiliationContextPort affiliationContexts, LongSupplier regroupEpochMillis)
	{
		_store = Objects.requireNonNull(store);
		_goals = Objects.requireNonNull(goals);
		_backend = Objects.requireNonNull(backend);
		_roleCatalog = Objects.requireNonNull(roleCatalog);
		_roles = new PhantomPartyRoleMatcher(roleCatalog);
		_routes = Objects.requireNonNull(routes);
		_tactics = Objects.requireNonNull(tactics);
		_topologyHash = Objects.requireNonNull(topologyHash);
		_clock = Objects.requireNonNull(clock);
		_socialEvents = Objects.requireNonNull(socialEvents);
		_socialClock = Objects.requireNonNull(socialClock);
		_regroupEpochMillis = Objects.requireNonNull(regroupEpochMillis);
		_affiliationContexts = Objects.requireNonNull(affiliationContexts);
		if ((operationBudget < 10) || (operationBudget > 10000))
		{
			throw new IllegalArgumentException("Party operation budget must be between 10 and 10000.");
		}
		_operationBudget = operationBudget;
	}

	public boolean start()
	{
		if (_state != State.NEW)
		{
			return false;
		}
		_deliveryRegistration = PartyInvitationService.getInstance().installManagedDelivery(this);
		try
		{
			long cursor = 0;
			while (true)
			{
				final List<StoredPartyState> page = readPage(cursor);
				if (page.isEmpty())
				{
					break;
				}
				for (StoredPartyState stored : page)
				{
					final StoredPartyState recovered = sanitizeAfterRestart(stored);
					putClaim(recovered);
					cursor = stored.profileId();
				}
				if (page.size() < PAGE_SIZE)
				{
					break;
				}
			}
			rebuildGroups();
			_state = State.RUNNING;
			return true;
		}
		catch (RuntimeException e)
		{
			_deliveryRegistration.close();
			_deliveryRegistration = null;
			_state = State.STOPPED;
			throw e;
		}
	}

	public ManagedInvitationPolicyRegistration installManagedInvitationPolicy(String goalType, ManagedInvitationPolicy policy)
	{
		Objects.requireNonNull(goalType);
		Objects.requireNonNull(policy);
		if (_state == State.STOPPING || _state == State.STOPPED)
		{
			throw new IllegalStateException("Party coordinator is stopping.");
		}
		if (_managedInvitationPolicies.putIfAbsent(goalType, policy) != null)
		{
			throw new IllegalStateException("Managed invitation policy already installed for " + goalType + '.');
		}
		return () -> _managedInvitationPolicies.remove(goalType, policy);
	}

	public ContentBindingResult bindContentGoal(ContentBindingRequest request)
	{
		Objects.requireNonNull(request);
		final OperationClaim control = beginOperation();
		if (control == null)
		{
			return bindingFailure(ContentBindingOutcome.NOT_RUNNING, request, "party.binding.not_running");
		}
		try (control)
		{
			if (!exactGoal(request.leaderProfileId(), request.goalId(), request.goalRevision(), request.goalType(), null))
			{
				return bindingFailure(ContentBindingOutcome.GOAL_MISMATCH, request, "party.binding.goal_mismatch");
			}
			final MemberRef leader = _backend.currentMember(request.leaderProfileId()).orElse(null);
			if ((leader == null) || !leader.equals(request.expectedLeader()))
			{
				return bindingFailure(ContentBindingOutcome.CANONICAL_MISMATCH, request, "party.binding.leader_changed");
			}
			final PartySnapshot observed = _backend.observe(leader).orElse(new PartySnapshot(leader, List.of(leader), request.distribution()));
			if (!observed.leader().equals(request.expectedLeader()) || !sameRoster(observed.members(), request.expectedRoster()) || (observed.distribution() != request.distribution()))
			{
				return bindingFailure(ContentBindingOutcome.CANONICAL_MISMATCH, request, "party.binding.roster_changed");
			}
			final List<MemberRef> phantoms = observed.members().stream().filter(member -> member.kind() == MemberKind.PHANTOM).sorted(Comparator.comparing(MemberRef::stableKey)).toList();
			final List<MemberRef> reals = observed.members().stream().filter(member -> member.kind() == MemberKind.REAL).sorted(Comparator.comparing(MemberRef::stableKey)).toList();
			final Map<MemberRef, MemberSnapshot> snapshots = snapshots(observed.members());
			if (snapshots.size() != observed.members().size())
			{
				return bindingFailure(ContentBindingOutcome.CANONICAL_MISMATCH, request, "party.binding.snapshot_stale");
			}
			final StoredPartyState leaderClaim = _claims.get(request.leaderProfileId());
			String groupId = PhantomPartyModel.stableGroupId(request.leaderProfileId(), request.goalId(), request.goalRevision());
			long generation = 1;
			long membershipRevision = 0;
			if (leaderClaim != null)
			{
				final PartyState state = leaderClaim.state();
				final PhantomPartyRouteCoordinator.RouteActivity routeActivity = routeActivity(state);
				if (routeActivity.nonTerminal())
				{
					return bindingFailure(ContentBindingOutcome.OPERATION_CONFLICT, request, "party.binding.route_active");
				}
				if (routeActivity.terminal())
				{
					_routes.cancel(state.groupId());
				}
				if (pendingMembership(state.operation()))
				{
					return bindingFailure(ContentBindingOutcome.OPERATION_CONFLICT, request, "party.binding.operation_pending");
				}
				if (committedClaim(leaderClaim))
				{
					if (!state.leader().equals(observed.leader()) || !sameRoster(roster(state), observed.members()))
					{
						return bindingFailure(ContentBindingOutcome.CLAIM_CONFLICT, request, "party.binding.claim_roster_conflict");
					}
					groupId = state.groupId();
					generation = state.groupGeneration();
					membershipRevision = state.membershipRevision();
				}
				else if (state.status() == StateStatus.SOLO)
				{
					generation = state.groupGeneration() + 1;
					membershipRevision = state.membershipRevision() + 1;
				}
				else
				{
					return bindingFailure(ContentBindingOutcome.CLAIM_CONFLICT, request, "party.binding.claim_conflict");
				}
			}
			for (MemberRef member : phantoms)
			{
				final StoredPartyState claim = _claims.get(member.profileId());
				if ((claim != null) && routeActivity(claim.state()).nonTerminal())
				{
					return bindingFailure(ContentBindingOutcome.OPERATION_CONFLICT, request, "party.binding.member_route_active");
				}
				if ((claim != null) && routeActivity(claim.state()).terminal())
				{
					_routes.cancel(claim.state().groupId());
				}
				if ((claim != null) && pendingMembership(claim.state().operation()))
				{
					return bindingFailure(ContentBindingOutcome.OPERATION_CONFLICT, request, "party.binding.member_operation_pending");
				}
				if ((claim != null) && committedClaim(claim) && (!claim.state().groupId().equals(groupId) || (claim.state().groupGeneration() != generation) || !sameRoster(roster(claim.state()), observed.members())))
				{
					return bindingFailure(ContentBindingOutcome.CLAIM_CONFLICT, request, "party.binding.member_claim_conflict");
				}
				if ((claim != null) && !committedClaim(claim) && (claim.state().status() != StateStatus.SOLO))
				{
					return bindingFailure(ContentBindingOutcome.CLAIM_CONFLICT, request, "party.binding.member_claim_conflict");
				}
			}
			final RoleMatchResult roles = _roles.match(request.objectiveMode(), request.requirements(), new ArrayList<>(snapshots.values()));
			final PartyState draft = state(groupId, generation, membershipRevision, StateStatus.LEADER, leader, phantoms, reals, request.objectiveMode(), request.objectiveRef(), request.requirements(), roles.assignments(), null, null, progressionEvidence(snapshots), "");
			final String manifest = draft.canonicalManifestHash();
			final PartyOperation operation = new PartyOperation(PhantomPartyModel.stableOperationId(groupId, generation, membershipRevision, OperationKind.SUPPORT, leader, null, request.goalId(), request.goalRevision(), manifest), OperationKind.SUPPORT, OperationPhase.COMMITTED, leader, null, request.goalId(), request.goalRevision(), manifest, 0, deadline(), "");
			boolean idempotent = true;
			for (MemberRef member : phantoms)
			{
				idempotent &= exactBoundClaim(_claims.get(member.profileId()), member, leader, groupId, generation, membershipRevision, manifest, request.goalId(), request.goalRevision());
			}
			if (!idempotent)
			{
				for (MemberRef member : phantoms)
				{
					final StoredPartyState current = _claims.get(member.profileId());
					final String ownRole = roles.assignments().stream().filter(assignment -> assignment.member().equals(member)).map(RoleAssignment::roleKey).findFirst().orElse("");
					final PartyState next = new PartyState(groupId, generation, membershipRevision, member.equals(leader) ? StateStatus.LEADER : StateStatus.MEMBER, leader, ownRole, manifest, phantoms, reals, request.objectiveMode(), request.objectiveRef(), request.requirements(), roles.assignments(), null, operation, draft.progressionHash(), draft.topologyHash(), "");
					try
					{
						putClaim(save(member.profileId(), current == null ? -1 : current.rowVersion(), next));
					}
					catch (RuntimeException e)
					{
						_metrics.conflict();
						return bindingFailure(ContentBindingOutcome.PERSISTENCE_CONFLICT, request, "party.binding.persistence_conflict");
					}
				}
				ensureGroup(groupId);
			}
			return new ContentBindingResult(idempotent ? ContentBindingOutcome.IDEMPOTENT : ContentBindingOutcome.BOUND, groupId, generation, membershipRevision, leader, request.rosterEvidenceHash(), manifest, OperationStability.STABLE, idempotent ? "party.binding.idempotent" : "party.binding.bound");
		}
	}

	public ContentBindingResult observeContentBinding(ContentBindingRequest request)
	{
		Objects.requireNonNull(request);
		final MemberRef leader = _backend.currentMember(request.leaderProfileId()).orElse(null);
		final PartySnapshot party = leader == null ? null : _backend.observe(leader).orElse(new PartySnapshot(leader, List.of(leader), request.distribution()));
		if ((leader == null) || (party == null) || !party.leader().equals(request.expectedLeader()) || !sameRoster(party.members(), request.expectedRoster()) || (party.distribution() != request.distribution()))
		{
			return bindingFailure(ContentBindingOutcome.CANONICAL_MISMATCH, request, "party.binding.roster_changed");
		}
		final StoredPartyState claim = _claims.get(request.leaderProfileId());
		if ((claim == null) || !committedClaim(claim) || !claim.state().leader().equals(leader) || !sameRoster(roster(claim.state()), party.members()))
		{
			return bindingFailure(ContentBindingOutcome.CLAIM_CONFLICT, request, "party.binding.claim_conflict");
		}
		final PhantomPartyRouteCoordinator.RouteActivity routeActivity = routeActivity(claim.state());
		if (routeActivity.nonTerminal())
		{
			return new ContentBindingResult(ContentBindingOutcome.OPERATION_CONFLICT, claim.state().groupId(), claim.state().groupGeneration(), claim.state().membershipRevision(), leader, request.rosterEvidenceHash(), claim.state().leaderManifestHash(), OperationStability.PENDING, "party.binding.route_active");
		}
		if (routeActivity.terminal())
		{
			_routes.cancel(claim.state().groupId());
			return new ContentBindingResult(ContentBindingOutcome.OPERATION_CONFLICT, claim.state().groupId(), claim.state().groupGeneration(), claim.state().membershipRevision(), leader, request.rosterEvidenceHash(), claim.state().leaderManifestHash(), OperationStability.PENDING, "party.binding.route_terminal_reconciled");
		}
		if (pendingMembership(claim.state().operation()))
		{
			return new ContentBindingResult(ContentBindingOutcome.OPERATION_CONFLICT, claim.state().groupId(), claim.state().groupGeneration(), claim.state().membershipRevision(), leader, request.rosterEvidenceHash(), claim.state().leaderManifestHash(), OperationStability.PENDING, "party.binding.operation_pending");
		}
		final PartyOperation operation = claim.state().operation();
		if ((operation == null) || (operation.leaderGoalId() != request.goalId()) || (operation.leaderGoalRevision() != request.goalRevision()) || !claim.state().objectiveRef().equals(request.objectiveRef()))
		{
			return bindingFailure(ContentBindingOutcome.CLAIM_CONFLICT, request, "party.binding.identity_changed");
		}
		return new ContentBindingResult(ContentBindingOutcome.IDEMPOTENT, claim.state().groupId(), claim.state().groupGeneration(), claim.state().membershipRevision(), leader, request.rosterEvidenceHash(), claim.state().leaderManifestHash(), OperationStability.STABLE, "party.binding.stable");
	}

	private static ContentBindingResult bindingFailure(ContentBindingOutcome outcome, ContentBindingRequest request, String reason)
	{
		return new ContentBindingResult(outcome, ZERO_HASH, 0, 0, request.expectedLeader(), request.rosterEvidenceHash(), ZERO_HASH, outcome == ContentBindingOutcome.OPERATION_CONFLICT ? OperationStability.PENDING : OperationStability.CONFLICT, reason);
	}

	private static boolean exactBoundClaim(StoredPartyState stored, MemberRef member, MemberRef leader, String groupId, long generation, long membershipRevision, String manifest, long goalId, long goalRevision)
	{
		if ((stored == null) || !committedClaim(stored))
		{
			return false;
		}
		final PartyOperation operation = stored.state().operation();
		return stored.state().groupId().equals(groupId) && (stored.state().groupGeneration() == generation) && (stored.state().membershipRevision() == membershipRevision) && stored.state().leader().equals(leader) && stored.state().leaderManifestHash().equals(manifest) && (operation != null) && (operation.kind() == OperationKind.SUPPORT) && (operation.phase() == OperationPhase.COMMITTED) && (operation.leaderGoalId() == goalId) && (operation.leaderGoalRevision() == goalRevision) && roster(stored.state()).contains(member);
	}

	private static boolean pendingMembership(PartyOperation operation)
	{
		return (operation != null) && Set.of(OperationKind.JOIN, OperationKind.LEAVE, OperationKind.EXPEL, OperationKind.TRANSFER_LEADER, OperationKind.ROUTE).contains(operation.kind()) && Set.of(OperationPhase.PREPARED, OperationPhase.CANONICAL_PENDING, OperationPhase.CANONICAL_OBSERVED).contains(operation.phase());
	}

	private static List<MemberRef> roster(PartyState state)
	{
		return java.util.stream.Stream.concat(state.phantomMembers().stream(), state.realMembers().stream()).sorted(Comparator.comparing(MemberRef::stableKey)).toList();
	}

	private static boolean sameRoster(List<MemberRef> left, List<MemberRef> right)
	{
		return left.stream().sorted(Comparator.comparing(MemberRef::stableKey)).toList().equals(right.stream().sorted(Comparator.comparing(MemberRef::stableKey)).toList());
	}
	public CommandOutcome form(long leaderProfileId, long goalId, long goalRevision, ObjectiveMode objective, PhantomDomainRef objectiveRef, List<RoleRequirement> requirements)
	{
		return formForGoal(leaderProfileId, goalId, goalRevision, FORM_GOAL, objective, objectiveRef, requirements);
	}

	public CommandOutcome formForGoal(long leaderProfileId, long goalId, long goalRevision, String expectedGoalType, ObjectiveMode objective, PhantomDomainRef objectiveRef, List<RoleRequirement> requirements)
	{
		final OperationClaim control = beginOperation();
		if (control == null)
		{
			return CommandOutcome.NOT_RUNNING;
		}
		try (control)
		{
			if ((expectedGoalType == null) || !exactGoal(leaderProfileId, goalId, goalRevision, expectedGoalType, null))
			{
				return CommandOutcome.GOAL_MISMATCH;
			}
			final String groupId = PhantomPartyModel.stableGroupId(leaderProfileId, goalId, goalRevision);
			final StoredPartyState existing = _claims.get(leaderProfileId);
			long expectedRowVersion = -1;
			long groupGeneration = 1;
			long membershipRevision = 0;
			if (existing != null)
			{
				final PartyOperation live = existing.state().operation();
				final var state = existing.state();
				final boolean retryFarm = live != null && live.kind() == OperationKind.JOIN && live.phase() == OperationPhase.ABORTED
					&& state.status() == StateStatus.LEADER && PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(state.objectiveRef().namespace())
					&& state.realMembers().isEmpty() && state.phantomMembers().size() >= 2 && state.phantomMembers().size() <= 5
					&& !routeActivity(state).nonTerminal() && state.phantomMembers().stream().allMatch(member -> _backend.autonomousFarmAvailable(member)
						&& (_tactics.combatOwner() == null || !_tactics.combatOwner().hasClaim(member.profileId())))
					&& _backend.observe(state.leader()).filter(party -> party.leader().equals(state.leader()) && sameRoster(roster(state), party.members())).isPresent();
				if (existing.state().groupId().equals(groupId) && (live != null) && (live.leaderGoalId() == goalId) && (live.leaderGoalRevision() == goalRevision) && (live.phase() != OperationPhase.ABORTED || retryFarm))
				{
					return CommandOutcome.IDEMPOTENT;
				}
				if ((existing.state().status() != StateStatus.SOLO) || ((live != null) && (live.leaderGoalId() == goalId) && (live.leaderGoalRevision() == goalRevision)))
				{
					return CommandOutcome.CLAIM_EXISTS;
				}
				expectedRowVersion = existing.rowVersion();
				groupGeneration = existing.state().groupGeneration() + 1;
				membershipRevision = existing.state().membershipRevision() + 1;
			}
			final MemberRef leader = _backend.currentMember(leaderProfileId).orElse(null);
			if (leader == null)
			{
				return CommandOutcome.TARGET_UNAVAILABLE;
			}
			final PartyState provisional = state(groupId, groupGeneration, membershipRevision, StateStatus.FORMING, leader, List.of(leader), List.of(), objective, objectiveRef, requirements, List.of(), null, null, progressionHash(leader), "");
			final String manifest = provisional.canonicalManifestHash();
			final PartyOperation operation = new PartyOperation(PhantomPartyModel.stableOperationId(groupId, groupGeneration, membershipRevision, OperationKind.FORM, leader, null, goalId, goalRevision, manifest), OperationKind.FORM, OperationPhase.PREPARED, leader, null, goalId, goalRevision, manifest, 0, deadline(), "");
			final PartyState prepared = state(groupId, groupGeneration, membershipRevision, StateStatus.FORMING, leader, List.of(leader), List.of(), objective, objectiveRef, requirements, List.of(), null, operation, progressionHash(leader), "");
			try
			{
				final StoredPartyState stored = save(leaderProfileId, expectedRowVersion, prepared);
				putClaim(stored);
				if ((existing != null) && !existing.state().groupId().equals(groupId))
				{
					removeGroup(existing.state().groupId());
				}
				ensureGroup(groupId);
				return CommandOutcome.ACCEPTED;
			}
			catch (RuntimeException e)
			{
				_metrics.conflict();
				return CommandOutcome.PERSISTENCE_CONFLICT;
			}
		}
	}

	public CommandOutcome invite(long leaderProfileId, MemberRef target, PartyDistributionType distribution)
	{
		final OperationClaim control = beginOperation();
		if (control == null)
		{
			return CommandOutcome.NOT_RUNNING;
		}
		try (control)
		{
		final StoredPartyState stored = _claims.get(leaderProfileId);
		if ((stored == null) || (stored.state().leader().profileId() != leaderProfileId))
		{
			return CommandOutcome.NOT_LEADER;
		}
		if ((stored.state().phantomMembers().size() + stored.state().realMembers().size()) >= PhantomPartyModel.MAX_ROSTER)
		{
			return CommandOutcome.ROSTER_FULL;
		}
		final StoredPartyState previousMemberClaim;
		if (PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(stored.state().objectiveRef().namespace()))
		{
			final var planned = PhantomAutonomousFarmParty.plannedProfiles(stored.state().objectiveRef());
			final var nativeParty = _backend.observe(stored.state().leader()).orElse(null);
			if (target.kind() != MemberKind.PHANTOM || !planned.contains(target.profileId()) || !stored.state().realMembers().isEmpty()
				|| nativeParty != null && (nativeParty.members().size() >= 5 || nativeParty.members().stream().anyMatch(member -> member.kind() != MemberKind.PHANTOM || !planned.contains(member.profileId())))) { return CommandOutcome.ROSTER_FULL; }
		}
		if (target.kind() == MemberKind.PHANTOM)
		{
			if ((target.profileId() == leaderProfileId) || committedClaim(_claims.get(target.profileId())) && !recoveringMember(stored, _claims.get(target.profileId()), target))
			{
				return CommandOutcome.CLAIM_EXISTS;
			}
			previousMemberClaim = _claims.get(target.profileId());
		}
		else
		{
			previousMemberClaim = null;
		}
		final PartyState current = stored.state();
		final PartyOperation base = current.operation();
		if ((base != null) && (base.kind() == OperationKind.JOIN) && !Set.of(OperationPhase.ABORTED, OperationPhase.COMMITTED).contains(base.phase()))
		{
			if (target.equals(base.member()) && base.phase() == OperationPhase.PREPARED && base.invitationSequence() == 0)
			{
				final var targetClaim = _claims.get(target.profileId());
				if (targetClaim == null || targetClaim.state().operation() == null || !base.equals(targetClaim.state().operation())) { return CommandOutcome.PERSISTENCE_CONFLICT; }
				if (deferRemoteJoin(stored, target)) { return CommandOutcome.IDEMPOTENT; }
				final var result = _backend.invite(current.leader(), target, distribution);
				if (!result.delivered()) { abort(stored, "invite.canonical_rejected"); moveToSolo(targetClaim, "invite.canonical_rejected"); return CommandOutcome.CANONICAL_REJECTED; }
				return sameInvitation(_claims.get(leaderProfileId).state().operation(), result.identity()) ? CommandOutcome.ACCEPTED : CommandOutcome.PERSISTENCE_CONFLICT;
			}
			if (target.equals(base.member()) && PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(current.objectiveRef().namespace()))
			{
				final var pending = _pendingManagedInvitations.get(target.profileId());
				if (pending != null && sameInvitation(base, pending.identity()))
				{
					final var recheck = new ManagedInvitation(pending, target.profileId());
					if (!_inbound.contains(recheck)) { _inbound.offer(recheck); }
				}
			}
			return target.equals(base.member()) ? CommandOutcome.IDEMPOTENT : CommandOutcome.CLAIM_EXISTS;
		}
		final long goalId = base == null ? 1 : base.leaderGoalId();
		final long goalRevision = base == null ? 0 : base.leaderGoalRevision();
		final String operationId = PhantomPartyModel.stableOperationId(current.groupId(), current.groupGeneration(), current.membershipRevision(), OperationKind.JOIN, current.leader(), target, goalId, goalRevision, current.leaderManifestHash());
		final PartyOperation operation = new PartyOperation(operationId, OperationKind.JOIN, OperationPhase.PREPARED, current.leader(), target, goalId, goalRevision, current.leaderManifestHash(), 0, deadline(), "");
		final StoredPartyState prepared;
		try
		{
			prepared = save(leaderProfileId, stored.rowVersion(), current.withOperation(StateStatus.INVITED_OUTBOUND, operation, ""));
			putClaim(prepared);
		}
		catch (RuntimeException e)
		{
			return CommandOutcome.PERSISTENCE_CONFLICT;
		}
		final StoredPartyState preparedMember;
		if (target.kind() == MemberKind.PHANTOM)
		{
			try
			{
				final List<MemberRef> phantomMembers = java.util.stream.Stream.concat(current.phantomMembers().stream(), java.util.stream.Stream.of(target)).distinct().sorted(Comparator.comparing(MemberRef::stableKey)).toList();
				final PartyState memberClaim = new PartyState(current.groupId(), current.groupGeneration(), current.membershipRevision(), StateStatus.INVITED_INBOUND, current.leader(), "", current.leaderManifestHash(), phantomMembers, current.realMembers(), current.objectiveMode(), current.objectiveRef(), current.requirements(), current.assignments(), current.route(), operation, progressionHash(target), current.topologyHash(), "");
				preparedMember = save(target.profileId(), previousMemberClaim == null ? -1 : previousMemberClaim.rowVersion(), memberClaim);
				putClaim(preparedMember);
			}
			catch (RuntimeException e)
			{
				abort(prepared, "invite.member_claim_conflict");
				return CommandOutcome.PERSISTENCE_CONFLICT;
			}
		}
		else
		{
			preparedMember = null;
		}
		if (deferRemoteJoin(prepared, target)) { return CommandOutcome.ACCEPTED; }
		final InviteResult result = _backend.invite(current.leader(), target, distribution);
		if (!result.delivered())
		{
			rollbackPreparedMember(target, previousMemberClaim, preparedMember, "invite.canonical_rejected");
			abort(prepared, "invite.canonical_rejected");
			return CommandOutcome.CANONICAL_REJECTED;
		}
		final StoredPartyState exactLeader = _claims.get(leaderProfileId);
		if ((exactLeader == null) || !sameInvitation(exactLeader.state().operation(), result.identity()))
		{
			PartyInvitationService.getInstance().cancel(result.identity());
			rollbackPreparedMember(target, previousMemberClaim, preparedMember, "invite.leader_claim_conflict");
			return CommandOutcome.PERSISTENCE_CONFLICT;
		}
		_metrics.inviteDelivered();
		return CommandOutcome.ACCEPTED;
		}
	}

	private boolean recoveringMember(StoredPartyState leader, StoredPartyState member, MemberRef target)
	{
		if (member == null || !Set.of(StateStatus.RECOVERING, StateStatus.MEMBER).contains(member.state().status())
			|| !leader.state().groupId().equals(member.state().groupId()) || leader.state().groupGeneration() != member.state().groupGeneration() || !leader.state().leader().equals(member.state().leader())
			|| !leader.state().leaderManifestHash().equals(member.state().leaderManifestHash())
			|| !member.state().phantomMembers().contains(target) || !leader.state().realMembers().isEmpty() || !member.state().realMembers().isEmpty()
			|| _backend.observe(target).isPresent()
			|| _backend.currentMember(target.profileId()).filter(target::equals).isEmpty() || _backend.memberSnapshot(target).isEmpty()) { return false; }
		final var operation = leader.state().operation();
		final var root = _goals.load(target.profileId()).map(StoredGoal::goal).orElse(null);
		final var leaderRoot = _goals.load(leader.profileId()).map(StoredGoal::goal).orElse(null);
		if (operation == null || leaderRoot == null || root == null || !regroupLeaderRoot(leader.state(), leaderRoot)) { return false; }
		return PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(leader.state().objectiveRef().namespace())
			? PhantomAutonomousFarmParty.plannedProfiles(leader.state().objectiveRef()).contains(target.profileId()) && PhantomAutonomousFarmParty.ordinaryIntent(leader.profileId(), leaderRoot) && PhantomAutonomousFarmParty.ordinaryIntent(target.profileId(), root)
			: root.status() == PhantomGoalStatus.ACTIVE && Set.of(MEMBER_GOAL, JOIN_GOAL).contains(root.goalType()) && goalTargets(root, leader.state().leader().characterObjectId());
	}

	private PartyOperation nativePending(PartyOperation operation, long sequence)
	{
		return new PartyOperation(operation.operationId(), operation.kind(), OperationPhase.CANONICAL_PENDING, operation.leader(), operation.member(), operation.leaderGoalId(), operation.leaderGoalRevision(), operation.manifestHash(), sequence, deadline(), "");
	}

	private boolean deferRemoteJoin(StoredPartyState leader, MemberRef target)
	{
		if (target.kind() != MemberKind.PHANTOM || leader.state().leader().kind() != MemberKind.PHANTOM) { return false; }
		final var actor = _backend.memberSnapshot(target).orElse(null); final var anchor = _backend.memberSnapshot(leader.state().leader()).orElse(null);
		if (actor != null && anchor != null && actor.instanceId() == anchor.instanceId() && Math.abs((long) actor.z() - anchor.z()) <= 200 && Math.hypot((long) actor.x() - anchor.x(), (long) actor.y() - anchor.y()) <= 1200) { advanceRegroup(leader, target, true); return false; }
		advanceRegroup(leader, target);
		return true;
	}

	/** One bounded distance observation per group slice; route/invitation retries never own this clock. */
	private void advanceRegroup(StoredPartyState leaderClaim, MemberRef actor)
	{
		advanceRegroup(leaderClaim, actor, false);
	}

	private void advanceRegroup(StoredPartyState leaderClaim, MemberRef actor, boolean observedNear)
	{
		final var runtime = _groups.get(leaderClaim.state().groupId()); final long logicalNow = _clock.getAsLong();
		if (runtime == null || !observedNear && logicalNow < runtime.regroupDue.getOrDefault(actor.profileId(), 0L)) { return; }
		try
		{
			final var own = _claims.get(actor.profileId()); final var current = _backend.memberSnapshot(actor).orElse(null);
			final var party = _backend.observe(leaderClaim.state().leader()).orElse(null); final var state = leaderClaim.state();
			if (own == null || current == null || current.dead() || current.instanceId() != 0 || holdsMovement(actor.profileId()) || actor.kind() != MemberKind.PHANTOM || state.leader().kind() != MemberKind.PHANTOM || !state.realMembers().isEmpty()
				|| !own.state().groupId().equals(state.groupId()) || own.state().groupGeneration() != state.groupGeneration() || !own.state().leaderManifestHash().equals(state.leaderManifestHash()) || !own.state().leader().equals(state.leader())
				|| _backend.currentMember(actor.profileId()).filter(actor::equals).isEmpty() || party == null || !party.leader().equals(state.leader()) || party.members().stream().anyMatch(ref -> ref.kind() != MemberKind.PHANTOM)) { return; }
			final var ownOp = own.state().operation();
			final boolean pending = ownOp != null && ownOp.kind() == OperationKind.JOIN && ownOp.phase() == OperationPhase.PREPARED && ownOp.invitationSequence() == 0 && actor.equals(ownOp.member()) && ownOp.equals(state.operation());
			if (!committedClaim(own) && !pending) { return; }
			final var planned = PhantomAutonomousFarmParty.plannedProfiles(state.objectiveRef());
			final var roster = planned.isEmpty() ? roster(own.state()) : planned.stream().map(_backend::currentMember).flatMap(Optional::stream).toList();
			if (!planned.isEmpty() && roster.size() != planned.size() || !roster.containsAll(party.members())) { return; }
			runtime.regroupDue.keySet().retainAll(roster.stream().map(MemberRef::profileId).toList());
			runtime.regroupDue.put(actor.profileId(), logicalNow + 5_000_000_000L);
			final var observations = party.members().stream().map(_backend::memberSnapshot).flatMap(Optional::stream).toList();
			if (observations.size() != party.members().size()) { return; }
			final var majority = PhantomPartyRegroupState.majority(actor, roster, observations);
			if (majority.isEmpty() || majority.stream().anyMatch(ref -> _backend.memberSnapshot(ref).map(member -> member.instanceId() != current.instanceId()).orElse(true))) { return; }
			final Map<Long, StoredPartyState> peerClaims = new LinkedHashMap<>(); final Map<Long, StoredGoal> peerRoots = new LinkedHashMap<>();
			for (var peer : majority)
			{
				final var claim = _claims.get(peer.profileId()); final var root = _goals.load(peer.profileId()).orElse(null);
				if (claim == null || !committedClaim(claim) && claim != leaderClaim || root == null || root.goal().status() != PhantomGoalStatus.ACTIVE
					|| !claim.state().groupId().equals(state.groupId()) || claim.state().groupGeneration() != state.groupGeneration() || !claim.state().leaderManifestHash().equals(state.leaderManifestHash()) || !claim.state().leader().equals(state.leader()) || _backend.currentMember(peer.profileId()).filter(peer::equals).isEmpty()
					|| PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(state.objectiveRef().namespace()) && !PhantomAutonomousFarmParty.ordinaryIntent(peer.profileId(), root.goal())) { return; }
				peerClaims.put(peer.profileId(), claim); peerRoots.put(peer.profileId(), root);
			}
			final boolean far = observations.stream().filter(member -> majority.contains(member.ref())).allMatch(member -> Math.abs((long) current.z() - member.z()) > 200 || Math.hypot((long) current.x() - member.x(), (long) current.y() - member.y()) > 1200);
			final var ownRoot = _goals.load(actor.profileId()).orElse(null); final var leaderRoot = _goals.load(state.leader().profileId()).orElse(null);
			if (ownRoot == null || leaderRoot == null || ownRoot.goal().status() != PhantomGoalStatus.ACTIVE || !regroupLeaderRoot(state, leaderRoot.goal())) { return; }
			final String intent = PhantomPartyModel.sha256(actor.stableKey() + '|' + state.leader().stableKey() + '|' + ownRoot.goal().goalId() + '|' + ownRoot.goal().revision() + '|' + leaderRoot.goal().goalId() + '|' + leaderRoot.goal().revision() + '|' + state.objectiveRef() + '|' + roster.stream().map(MemberRef::stableKey).sorted().toList());
			final var previous = _store.loadRegroupClock(actor.profileId()).orElse(null);
			if (!far && (previous == null || previous.state().farSinceMillis() == 0)) { return; }
			final long now = _regroupEpochMillis.getAsLong();
			final var observed = PhantomPartyRegroupState.observe(previous == null ? null : previous.state(), actor, intent, far, now);
			final java.util.function.BooleanSupplier currentOwner = () -> _state == State.RUNNING && _claims.get(actor.profileId()) == own && _claims.get(leaderClaim.profileId()) == leaderClaim && !holdsMovement(actor.profileId())
				&& peerClaims.entrySet().stream().allMatch(entry -> _claims.get(entry.getKey()) == entry.getValue());
			final java.util.function.BooleanSupplier authority = () -> currentOwner.getAsBoolean()
				&& _store.load(actor.profileId()).filter(own::equals).isPresent() && _store.load(leaderClaim.profileId()).filter(leaderClaim::equals).isPresent()
				&& _goals.load(actor.profileId()).filter(ownRoot::equals).isPresent() && _goals.load(state.leader().profileId()).filter(leaderRoot::equals).isPresent()
				&& peerClaims.entrySet().stream().allMatch(entry -> _claims.get(entry.getKey()) == entry.getValue() && _store.load(entry.getKey()).filter(entry.getValue()::equals).isPresent() && _goals.load(entry.getKey()).filter(peerRoots.get(entry.getKey())::equals).isPresent());
			if (!authority.getAsBoolean()) { return; }
			final var saved = _store.saveRegroupClock(actor.profileId(), previous == null ? -1 : previous.rowVersion(), observed);
			if (!far || !authority.getAsBoolean()) { return; }
			if (!observed.due(now))
			{
				final var anchor = observations.stream().filter(member -> member.ref().equals(majority.getFirst())).findFirst().orElseThrow();
				// Navigation polls cancellation in hot loops: only the current in-memory owner
				// and the existing refreshed source view belong in that callback, never JDBC.
				_routes.follow(state.groupId(), state.groupGeneration(), current, anchor, _topologyHash.get(), logicalNow, 3, () -> !currentOwner.getAsBoolean() || PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(state.objectiveRef().namespace()) && !currentFarmIntent(state));
				return;
			}
			if (current.casting() || current.attacking() || _tactics.combatOwner() == null || !authority.getAsBoolean()) { return; }
			_routes.cancelMemberMovement(state.groupId(), state.groupGeneration(), actor.profileId());
			final var acquired = _tactics.combatOwner().acquireExternalAction(new PhantomCombatService.ExternalActionRequest(actor.profileId(), PhantomCombatService.ExternalActionKind.PARTY_REJOIN, "party.regroup:" + intent, logicalNow + 5_000_000_000L, () -> !currentOwner.getAsBoolean()));
			if (acquired.lease() == null) { return; }
			try (var lease = acquired.lease())
			{
				if (!authority.getAsBoolean() || !lease.regroupReady()) { return; }
				final var reserved = _store.saveRegroupClock(actor.profileId(), saved.rowVersion(), observed.reserve(now));
				final var outcome = lease.regroupParty(actor, state.leader(), roster, majority, () -> authority.getAsBoolean() && _store.loadRegroupClock(actor.profileId()).filter(reserved::equals).isPresent());
				java.util.logging.Logger.getLogger(PhantomPartyCoordinator.class.getName()).info("Phantom party regroup profile=" + actor.profileId() + " pendingJoin=" + pending + " farSince=" + observed.farSinceMillis() + " observed=" + now + " cooldownUntil=" + reserved.state().cooldownUntilMillis() + " outcome=" + outcome);
			}
		}
		catch (RuntimeException exception) { _metrics.conflict(); }
	}

	private static boolean regroupLeaderRoot(PartyState state, PhantomGoal root)
	{
		final var operation = state.operation();
		if (operation == null || root.status() != PhantomGoalStatus.ACTIVE || root.goalId() != operation.leaderGoalId()) { return false; }
		return root.revision() == operation.leaderGoalRevision() || LEAD_GOAL.equals(root.goalType()) && operation.leaderGoalRevision() < Long.MAX_VALUE && root.revision() == operation.leaderGoalRevision() + 1;
	}

	public CommandOutcome inviteTarget(long leaderProfileId, PhantomDomainRef target, PartyDistributionType distribution)
	{
		if (target == null)
		{
			return CommandOutcome.TARGET_UNAVAILABLE;
		}
		try
		{
			if ("profile".equals(target.namespace()))
			{
				final MemberRef member = _backend.currentMember(Long.parseLong(target.key())).orElse(null);
				return member == null ? CommandOutcome.TARGET_UNAVAILABLE : invite(leaderProfileId, member, distribution);
			}
			if ("character.object".equals(target.namespace()))
			{
				final int objectId = Integer.parseInt(target.key());
				final OptionalLong managed = _backend.managedProfileId(objectId);
				return invite(leaderProfileId, managed.isPresent() ? MemberRef.phantom(managed.getAsLong(), objectId) : MemberRef.real(objectId), distribution);
			}
		}
		catch (NumberFormatException e)
		{
			return CommandOutcome.TARGET_UNAVAILABLE;
		}
		return CommandOutcome.TARGET_UNAVAILABLE;
	}

	public boolean committed(long profileId)
	{
		return committedClaim(_claims.get(profileId));
	}

	@Override
	public boolean blocksBackground(long profileId)
	{
		final StoredPartyState claim = _claims.get(profileId);
		if (claim == null)
		{
			return false;
		}
		if (Set.of(StateStatus.LEADER, StateStatus.MEMBER, StateStatus.RECOVERING).contains(claim.state().status()))
		{
			return true;
		}
		final PartyOperation operation = claim.state().operation();
		return (operation != null) && (Set.of(OperationPhase.CANONICAL_PENDING, OperationPhase.CANONICAL_OBSERVED).contains(operation.phase()) || operation.kind() == OperationKind.JOIN && operation.phase() == OperationPhase.PREPARED);
	}

	public RouteRequestResult requestRoute(long leaderProfileId, PhantomDomainRef destinationRef, org.l2jmobius.gameserver.phantoms.navigation.PhantomNavigationPoint destination)
	{
		final OperationClaim control = beginOperation();
		if (control == null)
		{
			return new RouteRequestResult(RouteOutcome.NOT_RUNNING, ZERO_HASH, 0, destinationRef, null, "party.route.not_running");
		}
		try (control)
		{
			final StoredPartyState claim = _claims.get(leaderProfileId);
			if ((claim == null) || (claim.state().status() != StateStatus.LEADER) || (claim.state().leader().kind() != MemberKind.PHANTOM) || (claim.state().leader().profileId() != leaderProfileId))
			{
				return new RouteRequestResult(RouteOutcome.NOT_PHANTOM_LEADER, ZERO_HASH, 0, destinationRef, null, "party.route.not_phantom_leader");
			}
			final PhantomPartyRouteCoordinator.RouteActivity routeActivity = routeActivity(claim.state());
			if (routeActivity.nonTerminal())
			{
				return new RouteRequestResult(RouteOutcome.PENDING, routeActivity.routeId(), routeActivity.generation(), routeActivity.destination(), routeActivity.navigationStatus(), routeActivity.reasonKey());
			}
			if (routeActivity.terminal())
			{
				_routes.cancel(claim.state().groupId());
				if (routeActivity.navigationStatus() != null)
				{
					final RouteOutcome terminal = switch (routeActivity.status())
					{
						case REJECTED -> RouteOutcome.REJECTED;
						case UNAVAILABLE -> RouteOutcome.UNAVAILABLE;
						default -> RouteOutcome.FAILED;
					};
					return new RouteRequestResult(terminal, routeActivity.routeId(), routeActivity.generation(), routeActivity.destination(), routeActivity.navigationStatus(), routeActivity.reasonKey());
				}
				return new RouteRequestResult(RouteOutcome.PENDING, routeActivity.routeId(), routeActivity.generation(), routeActivity.destination(), null, "party.route.terminal_reconciled");
			}
			final MemberSnapshot leader = _backend.memberSnapshot(claim.state().leader()).orElse(null);
			if (leader == null)
			{
				return new RouteRequestResult(RouteOutcome.UNAVAILABLE, ZERO_HASH, claim.state().groupGeneration(), destinationRef, null, "party.route.leader_unavailable");
			}
			final PhantomPartyRouteCoordinator.RouteAttempt attempt = _routes.request(claim.state().groupId(), claim.state().groupGeneration(), leader, destinationRef, destination, claim.state().topologyHash(), Math.max(0, _clock.getAsLong()), deadline());
			if (attempt.status() == PhantomPartyRouteCoordinator.AttemptStatus.READY)
			{
				persistRoute(claim.state().groupId(), attempt.route());
			}
			final RouteOutcome outcome = switch (attempt.status())
			{
				case READY -> RouteOutcome.READY;
				case PENDING -> RouteOutcome.PENDING;
				case FAILED -> RouteOutcome.FAILED;
				case REJECTED -> RouteOutcome.REJECTED;
				case NONE, UNAVAILABLE -> RouteOutcome.UNAVAILABLE;
			};
			return new RouteRequestResult(outcome, attempt.routeId(), attempt.generation(), attempt.destination(), attempt.navigationStatus(), attempt.reasonKey());
		}
	}

	public PhantomPartyRouteCoordinator.RouteActivity observeRouteActivity(long leaderProfileId)
	{
		final StoredPartyState claim = _claims.get(leaderProfileId);
		return claim == null ? PhantomPartyRouteCoordinator.RouteActivity.none() : routeActivity(claim.state());
	}


	public List<PvpProtectionEvidence> pvpProtection(long helperProfileId, int limit)
	{
		if ((_state != State.RUNNING) || (limit < 1) || (limit > 8))
		{
			return List.of();
		}
		final StoredPartyState stored = _claims.get(helperProfileId);
		final MemberRef helper = _backend.currentMember(helperProfileId).orElse(null);
		if ((stored == null) || (helper == null) || (helper.kind() != MemberKind.PHANTOM) || !Set.of(StateStatus.LEADER, StateStatus.MEMBER).contains(stored.state().status()))
		{
			return List.of();
		}
		final PartySnapshot canonical = _backend.observe(helper).orElse(null);
		if ((canonical == null) || !canonical.members().contains(helper) || (canonical.members().size() > 9))
		{
			return List.of();
		}
		final long generation = stored.state().groupGeneration();
		final long revision = stored.state().membershipRevision();
		// Assigned support keeps the existing PartyTactics lease for heal/buff work.
		// Its own ACTUAL_ATTACK self-defense is observed separately by PvP context.
		for (var assignment : stored.state().assignments())
		{
			if (!assignment.member().equals(helper)) { continue; }
			try { if (_roleCatalog.require(assignment.roleKey()).support()) { return List.of(); } }
			catch (IllegalArgumentException staleRole) { return List.of(); }
		}
		return _tactics.planPvpProtection(helper, limit).stream().filter(directive -> canonical.members().contains(directive.targetMember())).map(directive -> new PvpProtectionEvidence(directive, generation, PhantomPartyModel.sha256(stored.state().groupId() + '|' + generation + '|' + revision + '|' + directive.targetMember().stableKey() + '|' + directive.targetObjectId()))).toList();
	}
	public boolean reconcileTerminalRoute(long leaderProfileId, String expectedRouteId)
	{
		final StoredPartyState claim = _claims.get(leaderProfileId);
		if (claim == null)
		{
			return false;
		}
		final PhantomPartyRouteCoordinator.RouteActivity activity = routeActivity(claim.state());
		if (!activity.terminal() || !activity.routeId().equals(expectedRouteId))
		{
			return false;
		}
		_routes.cancel(claim.state().groupId());
		return true;
	}

	private PhantomPartyRouteCoordinator.RouteActivity routeActivity(PartyState state)
	{
		return _routes.observe(state.groupId(), state.route(), roster(state));
	}

	public CommandOutcome leave(long profileId, long goalId, long goalRevision, long expectedGeneration)
	{
		return membership(profileId, goalId, goalRevision, expectedGeneration, LEAVE_GOAL, OperationKind.LEAVE, null);
	}

	public CommandOutcome expelTarget(long profileId, long goalId, long goalRevision, long expectedGeneration, PhantomDomainRef target)
	{
		final MemberRef member = resolveMember(target);
		return member == null ? CommandOutcome.TARGET_UNAVAILABLE : membership(profileId, goalId, goalRevision, expectedGeneration, EXPEL_GOAL, OperationKind.EXPEL, member);
	}

	public CommandOutcome transferLeaderTarget(long profileId, long goalId, long goalRevision, long expectedGeneration, PhantomDomainRef target)
	{
		final MemberRef member = resolveMember(target);
		return member == null ? CommandOutcome.TARGET_UNAVAILABLE : membership(profileId, goalId, goalRevision, expectedGeneration, TRANSFER_LEADER_GOAL, OperationKind.TRANSFER_LEADER, member);
	}

	public CommandOutcome travel(long profileId, long goalId, long goalRevision, long expectedGeneration, PhantomDomainRef destinationRef, org.l2jmobius.gameserver.phantoms.navigation.PhantomNavigationPoint destination)
	{
		final OperationClaim control = beginOperation();
		if (control == null)
		{
			return CommandOutcome.NOT_RUNNING;
		}
		try (control)
		{
			final StoredPartyState claim = exactCommandClaim(profileId, goalId, goalRevision, expectedGeneration, TRAVEL_GOAL, null);
			if (claim == null)
			{
				return commandMismatch(profileId, goalId, goalRevision, expectedGeneration, TRAVEL_GOAL, null);
			}
			final PartyOperation live = claim.state().operation();
			if ((live != null) && (live.kind() == OperationKind.ROUTE) && (live.leaderGoalId() == goalId) && (live.leaderGoalRevision() == goalRevision) && (live.phase() == OperationPhase.COMMITTED))
			{
				return CommandOutcome.IDEMPOTENT;
			}
			final PartyOperation operation = operation(claim.state(), OperationKind.ROUTE, null, goalId, goalRevision);
			try
			{
				putClaim(save(profileId, claim.rowVersion(), claim.state().withOperation(claim.state().status(), operation, "")));
			}
			catch (RuntimeException e)
			{
				return CommandOutcome.PERSISTENCE_CONFLICT;
			}
			final RouteRequestResult route = requestRoute(profileId, destinationRef, destination);
			return Set.of(RouteOutcome.READY, RouteOutcome.PENDING).contains(route.outcome()) ? CommandOutcome.ACCEPTED : CommandOutcome.CANONICAL_REJECTED;
		}
	}

	@Override
	public OptionalLong managedIdentity(int characterObjectId)
	{
		return _state == State.RUNNING ? _backend.managedProfileId(characterObjectId) : OptionalLong.empty();
	}

	@Override
	public PreparationOutcome prepare(PartyInvitation invitation, OptionalLong managedRequester, OptionalLong managedInvitee)
	{
		final OperationClaim control = beginOperation();
		if (control == null)
		{
			return PreparationOutcome.STOPPING;
		}
		try (control)
		{
			StoredPartyState previousLeader = null;
			StoredPartyState pendingLeader = null;
			StoredPartyState previousMember = null;
			StoredPartyState pendingMember = null;
			try
			{
				if (managedRequester.isPresent())
				{
					previousLeader = _claims.get(managedRequester.getAsLong());
					if ((previousLeader == null) || !sameParticipants(previousLeader.state().operation(), invitation.identity()) || (previousLeader.state().operation().phase() != OperationPhase.PREPARED))
					{
						return PreparationOutcome.REJECTED;
					}
					final PartyOperation exact = nativePending(previousLeader.state().operation(), invitation.identity().sequence());
					pendingLeader = save(previousLeader.profileId(), previousLeader.rowVersion(), previousLeader.state().withOperation(StateStatus.INVITED_OUTBOUND, exact, ""));
					putClaim(pendingLeader);
				}
				if (managedInvitee.isPresent())
				{
					previousMember = _claims.get(managedInvitee.getAsLong());
					final PartyState memberState;
					if ((previousMember != null) && sameParticipants(previousMember.state().operation(), invitation.identity()) && (previousMember.state().operation().phase() == OperationPhase.PREPARED))
					{
						final PartyOperation exact = nativePending(previousMember.state().operation(), invitation.identity().sequence());
						memberState = previousMember.state().withOperation(StateStatus.INVITED_INBOUND, exact, "");
					}
					else if (managedRequester.isEmpty())
					{
						final StoredGoal existingGoal = _goals.load(managedInvitee.getAsLong()).orElse(null);
						if ((existingGoal != null) && JOIN_GOAL.equals(existingGoal.goal().goalType()) && ((existingGoal.goal().status() != PhantomGoalStatus.ACTIVE) || !goalTargets(existingGoal.goal(), invitation.requesterObjectId())))
						{
							return PreparationOutcome.REJECTED;
						}
						final MemberRef member = _backend.currentMember(managedInvitee.getAsLong()).orElse(null);
						if (member == null)
						{
							return PreparationOutcome.REJECTED;
						}
						memberState = null;
					}
					else
					{
						throw new IllegalStateException("Managed invitation member preparation is not exact.");
					}
					if (memberState != null)
					{
						pendingMember = save(managedInvitee.getAsLong(), previousMember == null ? -1 : previousMember.rowVersion(), memberState);
						putClaim(pendingMember);
					}
				}
				return PreparationOutcome.ACCEPTED;
			}
			catch (RuntimeException e)
			{
				rollbackPreparation(previousLeader, pendingLeader, previousMember, pendingMember);
				return PreparationOutcome.REJECTED;
			}
		}
	}

	@Override
	public DeliveryOutcome deliver(PartyInvitation invitation, long managedIdentity)
	{
		final OperationClaim control = beginOperation();
		if (control == null)
		{
			return DeliveryOutcome.STOPPING;
		}
		try (control)
		{
			final PartyInvitation previous = _pendingManagedInvitations.putIfAbsent(managedIdentity, invitation);
			if ((previous != null) && !previous.identity().equals(invitation.identity()))
			{
				return DeliveryOutcome.BACKPRESSURE;
			}
			if (previous != null)
			{
				return DeliveryOutcome.ACCEPTED;
			}
			if (!_inbound.offer(new ManagedInvitation(invitation, managedIdentity)))
			{
				_pendingManagedInvitations.remove(managedIdentity, invitation);
				return DeliveryOutcome.BACKPRESSURE;
			}
			return DeliveryOutcome.ACCEPTED;
		}
	}

	@Override
	public void terminal(PartyInvitation invitation, OptionalLong managedRequester, OptionalLong managedInvitee, TerminalOutcome outcome, String reasonKey)
	{
		final OperationClaim control = beginTerminalOperation();
		if (control == null)
		{
			return;
		}
		try (control)
		{
			managedInvitee.ifPresent(profileId -> _pendingManagedInvitations.remove(profileId, invitation));
			managedInvitee.ifPresent(profileId -> _inbound.removeIf(entry -> (entry.profileId() == profileId) && entry.invitation().identity().equals(invitation.identity())));
			final TerminalEvent event = new TerminalEvent(invitation, managedRequester, managedInvitee, outcome, reasonKey);
			if (_state == State.STOPPING)
			{
				processTerminal(event);
			}
			else if (!_terminalEvents.offer(event))
			{
				processTerminal(event);
			}
		}
	}

	@Override
	public void onPulse()
	{
		final OperationClaim control = beginOperation();
		if (control == null)
		{
			return;
		}
		try (control)
		{
			_metrics.pulse();
			int used = 0;
			int emptyLanes = 0;
			while ((used < _operationBudget) && (emptyLanes < 4))
			{
				final int lane = Math.floorMod(_pulseLane++, 4);
				int examined = 0;
				if (lane == 0)
				{
					final TerminalEvent event = _terminalEvents.poll();
					if (event != null)
					{
						examined = 1 + (event.managedRequester().isPresent() ? 1 : 0) + (event.managedInvitee().isPresent() ? 1 : 0);
						if ((used + examined) <= _operationBudget)
						{
							processTerminal(event);
						}
						else
						{
							_terminalEvents.offer(event);
							examined = 0;
						}
					}
				}
				else if (lane == 1)
				{
					final ManagedInvitation invitation = _inbound.poll();
					if (invitation != null)
					{
						processManagedInvitation(invitation);
						examined = 1;
					}
				}
				else if (lane == 2)
				{
					final Long profileId = _tacticalReleases.poll();
					if (profileId != null)
					{
						final var claim = _claims.get(profileId);
						final var authority = claim == null ? null : claim.state();
						final var group = authority == null ? null : _groups.get(authority.groupId());
						// A slow native observation may expire the cache after lane 3 refreshed it.
						// Reconcile roots here before interpreting expiry as cancellation of a cast.
						final boolean refresh = group != null && PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(authority.objectiveRef().namespace()) && currentFarmIntentView(authority) == null;
						final int required = 1 + (refresh ? PhantomAutonomousFarmParty.plannedProfiles(authority.objectiveRef()).size() : 0);
						if (used + required <= _operationBudget)
						{
							try { if (refresh) { refreshFarmIntent(group, authority); } }
							catch (RuntimeException failure) { _tacticalReleases.offer(profileId); throw failure; }
							releaseTacticalAction(profileId);
							examined = required;
						}
						else { _tacticalReleases.offer(profileId); }
					}
				}
				else
				{
					final GroupRuntime group = pollDueGroup();
					if (group != null)
					{
						final int required = 1 + claimCount(group.groupId());
						if ((used + required) <= _operationBudget)
						{
							examined = reconcile(group, _operationBudget - used);
							if (_groups.containsKey(group.groupId()))
							{
								scheduleGroup(group.groupId());
							}
						}
						else
						{
							scheduleGroup(group.groupId());
						}
					}
				}
				if (examined == 0)
				{
					emptyLanes++;
					continue;
				}
				emptyLanes = 0;
				used += examined;
				for (int operation = 0; operation < examined; operation++)
				{
					_metrics.operation();
				}
			}
			if (used >= _operationBudget)
			{
				_metrics.budgetExhausted();
			}
			_lastPulseExamined = used;
			_maximumPulseExamined = Math.max(_maximumPulseExamined, used);
		}
	}

	public void beginStop()
	{
		synchronized (_lifecycleLock)
		{
			if ((_state == State.STOPPING) || (_state == State.STOPPED))
			{
				return;
			}
			_state = State.STOPPING;
		}
		final DeliveryRegistration registration = _deliveryRegistration;
		if (registration != null)
		{
			registration.close();
			_deliveryRegistration = null;
		}
		_inbound.clear();
		_pendingManagedInvitations.clear();
		_managedInvitationPolicies.clear();
		_routes.beginStop();
		_tacticalActions.values().forEach(ExternalActionLease::close);
		_tacticalActions.clear();
		_tacticalCombat.values().forEach(this::cancelTacticalCombat);
		_tacticalReleases.clear();
	}

	public boolean finishStop()
	{
		if (_state == State.NEW)
		{
			_state = State.STOPPED;
			return true;
		}
		if (_state == State.RUNNING)
		{
			beginStop();
		}
		// No new scheduler pulse is admitted after beginStop. Finish already accepted
		// terminal work through the same owner, bounded by the ordinary operation budget.
		final OperationClaim terminalControl = beginTerminalOperation();
		if (terminalControl != null)
		{
			try (terminalControl)
			{
				for (int used = 0; used + 3 <= _operationBudget; used += 3)
				{
					final TerminalEvent event = _terminalEvents.poll();
					if (event == null) { break; }
					processTerminal(event);
				}
			}
		}
		for (TacticalCombatClaim claim : List.copyOf(_tacticalCombat.values()))
		{
			releaseTacticalCombat(claim);
		}
		final PhantomPartyRouteCoordinator.Snapshot route = _routes.snapshot();
		final DeliveryRegistration registration = _deliveryRegistration;
		if ((_operationClaims.get() != 0) || (_persistenceClaims.get() != 0) || !_terminalEvents.isEmpty() || !_inbound.isEmpty() || !_tacticalReleases.isEmpty() || !_tacticalActions.isEmpty() || !_tacticalCombat.isEmpty() || ((registration != null) && (registration.pendingInvitations() != 0)) || (route.navigationClaims() != 0) || (route.movementClaims() != 0))
		{
			return false;
		}
		synchronized (_lifecycleLock)
		{
			if (_operationClaims.get() != 0)
			{
				return false;
			}
			_state = State.STOPPED;
		}
		return true;
	}

	public Snapshot snapshot()
	{
		final PhantomPartyRouteCoordinator.Snapshot route = _routes.snapshot();
		return new Snapshot(_state, _claims.size(), _groups.size(), _terminalEvents.size(), _inbound.size(), _operationClaims.get(), _persistenceClaims.get(), route.navigationClaims(), route.movementClaims(), _tacticalActions.size() + _tacticalCombat.size(), _operationBudget, _lastPulseExamined, _maximumPulseExamined, _socialEventsRecorded.get(), _socialEventFailures.get(), _metrics.snapshot());
	}

	public Optional<StoredPartyState> claim(long profileId)
	{
		return Optional.ofNullable(_claims.get(profileId));
	}

	/** A factual group pull still enters the same tactical combat owner as ASSIST. */
	public boolean requestAutonomousFarm(long leaderProfileId)
	{
		final OperationClaim control = beginOperation();
		if (control == null) { return false; }
		try (control)
		{
			final StoredPartyState stored = _claims.get(leaderProfileId);
			if (!committedClaim(stored) || stored.state().leader().profileId() != leaderProfileId || !PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(stored.state().objectiveRef().namespace())) { return false; }
			final PartyState authority = stored.state();
			final PartyOperation operation = authority.operation();
			final PartySnapshot party = _backend.observe(authority.leader()).orElse(null);
			if (operation == null || !currentFarmReady(authority, party)
				|| party == null || !party.leader().equals(authority.leader()) || party.members().size() < 2 || party.members().size() > 5 || !sameRoster(roster(authority), party.members()) || !authority.realMembers().isEmpty()) { return false; }
			final Set<MemberRef> supportMembers = authority.assignments().stream().filter(assignment -> assignment.roleKey().startsWith("support.")).map(RoleAssignment::member).collect(java.util.stream.Collectors.toSet());
			// The current native episode owns its completion and loot. A next-pull search
			// must not cancel it merely because the killed target is no longer selectable.
			if (_tacticalCombat.containsKey(leaderProfileId) || _tacticalActions.containsKey(leaderProfileId)) { return true; }
			final var target = _backend.autonomousFarmTarget(party, supportMembers);
			if (target.isEmpty())
			{
				for (MemberRef member : party.members())
				{
					final TacticalCombatClaim active = _tacticalCombat.get(member.profileId());
					if (active != null) { cancelTacticalCombat(active); }
				}
				return false;
			}
			final var actor = _backend.memberSnapshot(authority.leader()).orElse(null);
			if (actor == null || actor.dead() || actor.casting() || actor.attacking()) { return false; }
			final TacticalDirective directive = new TacticalDirective(DirectiveKind.ASSIST_TARGET, authority.leader(), authority.leader(), target.getAsInt(), "", "", "", 0, 0, "farm.group.native_target", 6000);
			if (_tactics.combatMode(directive).isEmpty()) { return false; }
			dispatchTacticalCombat(directive, tacticalScope(authority) + "assist_target." + leaderProfileId, authority);
			return _tacticalCombat.containsKey(leaderProfileId);
		}
	}

	public Optional<PartyInvitation> pendingInvitation(long profileId)
	{
		return _state == State.RUNNING ? Optional.ofNullable(_pendingManagedInvitations.get(profileId)) : Optional.empty();
	}

	/** Reconcile only native absence after a fenced restart or an aborted first farm invitation. */
	public boolean reconcileAutonomousFarmAbsence(long profileId, long goalId, long goalRevision)
	{
		final var control = beginOperation();
		if (control == null) { return false; }
		try (control)
		{
			final var stored = _claims.get(profileId);
			if (stored == null) { return false; }
			final var state = stored.state(); final var operation = state.operation();
			final var planned = PhantomAutonomousFarmParty.plannedProfiles(state.objectiveRef());
			final boolean restartConflict = state.status() == StateStatus.INCONSISTENT && "restart.claim_conflict".equals(state.lastFailureKey())
				&& operation != null && operation.phase() == OperationPhase.CANONICAL_OBSERVED && !_groups.containsKey(state.groupId());
			final var routes = _routes.snapshot();
			// A refused first JOIN can retain a leader claim without ever creating native Party.
			// Reconcile only that exact empty formation; no native leave or owner cancellation.
			final boolean absentFormation = state.status() == StateStatus.LEADER && state.leader().profileId() == profileId
				&& state.phantomMembers().equals(List.of(state.leader())) && state.route() == null
				&& operation != null && operation.kind() == OperationKind.JOIN && operation.phase() == OperationPhase.ABORTED
				&& operation.leaderGoalId() == goalId && operation.leaderGoalRevision() == goalRevision
				&& routes.navigationClaims() == 0 && routes.routeClaims() == 0 && routes.deadlineClaims() == 0 && routes.movementClaims() == 0
				&& (_tactics.combatOwner() == null || !_tactics.combatOwner().hasClaim(profileId));
			if ((!restartConflict && !absentFormation) || !state.realMembers().isEmpty() || state.command() != null
				|| !planned.contains(profileId) || !planned.contains(state.leader().profileId())) { return false; }
			final MemberRef actor = state.phantomMembers().stream().filter(member -> member.profileId() == profileId).findFirst().orElse(null);
			final var root = _goals.load(profileId).orElse(null);
			if (actor == null || root == null || root.goal().goalId() != goalId || root.goal().revision() != goalRevision
				|| !PhantomAutonomousFarmParty.ordinaryIntent(profileId, root.goal()) || !farmAbsenceObserved(profileId, actor, root) || _claims.get(profileId) != stored) { return false; }
			final var repaired = moveToSolo(stored, "party.farm.native_absence_reconciled");
			if (repaired == null || _claims.get(profileId) != repaired || repaired.state().status() != StateStatus.SOLO || repaired.state().operation() != null
				|| repaired.state().groupGeneration() != state.groupGeneration() + 1 || repaired.state().membershipRevision() != state.membershipRevision() + 1) { return false; }
			if (farmAbsenceObserved(profileId, actor, root) && _claims.get(profileId) == repaired) { return true; }
			// Only this exact repaired row may be fenced again; a newer JOIN always wins its CAS.
			try { putClaim(save(profileId, repaired.rowVersion(), state)); }
			catch (RuntimeException exception) { _metrics.conflict(); }
			return false;
		}
	}

	private boolean farmAbsenceObserved(long profileId, MemberRef actor, StoredGoal root)
	{
		return _inbound.isEmpty() && _terminalEvents.isEmpty() && !_tacticalActions.containsKey(profileId) && !_tacticalCombat.containsKey(profileId)
			&& _pendingManagedInvitations.values().stream().noneMatch(invitation -> invitation.requesterObjectId() == actor.characterObjectId() || invitation.inviteeObjectId() == actor.characterObjectId())
			&& actor.equals(_backend.currentMember(profileId).orElse(null)) && _backend.autonomousFarmAvailable(actor)
			&& _backend.currentForce(actor).status() == PhantomPartyBackend.CurrentForceStatus.PARTY_ABSENT && _goals.load(profileId).filter(root::equals).isPresent();
	}

	/** An obsolete prepared leader can leave a committed core member without a materializable owner. */
	private void reconcileObsoleteFarmOrphan(StoredPartyState stored)
	{
		final var state = stored.state(); final var operation = state.operation();
		final long profileId = stored.profileId();
		final var planned = PhantomAutonomousFarmParty.plannedProfiles(state.objectiveRef());
		if (state.status() != StateStatus.RECOVERING || operation == null || operation.kind() != OperationKind.JOIN || operation.phase() != OperationPhase.COMMITTED
			|| state.leader().profileId() == profileId || !state.realMembers().isEmpty() || state.command() != null || state.route() != null
			|| !planned.contains(profileId) || !planned.contains(state.leader().profileId()) || state.phantomMembers().stream().anyMatch(member -> member.kind() != MemberKind.PHANTOM || !planned.contains(member.profileId()))) { return; }
		final var leader = _claims.get(state.leader().profileId());
		final var leaderRoot = _goals.load(state.leader().profileId()).orElse(null);
		final var root = _goals.load(profileId).orElse(null);
		final var actor = state.phantomMembers().stream().filter(member -> member.profileId() == profileId).findFirst().orElse(null);
		if (leader == null || leader.state().status() != StateStatus.SOLO || leader.state().groupGeneration() <= state.groupGeneration() || leader.state().groupId().equals(state.groupId())
			|| leaderRoot == null || (leaderRoot.goal().goalId() == operation.leaderGoalId() && leaderRoot.goal().revision() == operation.leaderGoalRevision())
			|| root == null || actor == null || !PhantomAutonomousFarmParty.ordinaryIntent(profileId, root.goal()) || !obsoleteFarmAbsence(stored, leader, root, leaderRoot, actor)) { return; }
		_backend.withUnmaterializedNativeAbsence(actor, () ->
		{
			if (!obsoleteFarmAbsence(stored, leader, root, leaderRoot, actor)) { return false; }
			final var repaired = moveToSolo(stored, "party.farm.obsolete_absent_core_reconciled");
			if (repaired == null) { return false; }
			if (obsoleteFarmAbsence(repaired, leader, root, leaderRoot, actor)) { return true; }
			// The native identity lease still prevents admission while only our row is restored.
			if (_claims.get(profileId) == repaired)
			{
				try { putClaim(save(profileId, repaired.rowVersion(), state)); }
				catch (RuntimeException exception) { _metrics.conflict(); }
			}
			return false;
		});
	}

	private boolean obsoleteFarmAbsence(StoredPartyState stored, StoredPartyState leader, StoredGoal root, StoredGoal leaderRoot, MemberRef actor)
	{
		final long profileId = stored.profileId();
		return _claims.get(profileId) == stored && _claims.get(leader.profileId()) == leader && _inbound.isEmpty() && _terminalEvents.isEmpty()
			&& !_tacticalActions.containsKey(profileId) && !_tacticalCombat.containsKey(profileId) && (_tactics.combatOwner() == null || !_tactics.combatOwner().hasClaim(profileId))
			&& _pendingManagedInvitations.values().stream().noneMatch(invitation -> invitation.requesterObjectId() == actor.characterObjectId() || invitation.inviteeObjectId() == actor.characterObjectId())
			&& _goals.load(profileId).filter(root::equals).isPresent() && _goals.load(leader.profileId()).filter(leaderRoot::equals).isPresent();
	}

	/** A supply handoff waits for native combat, pickup, support and group movement to finish. */
	public boolean releaseAutonomousFarmForPreparation(long profileId, long goalId, long goalRevision)
	{
		final var control = beginOperation();
		if (control == null) { return false; }
		try (control)
		{
			final var claim = _claims.get(profileId);
			if (!committedClaim(claim) || !PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(claim.state().objectiveRef().namespace()) || !claim.state().realMembers().isEmpty()) { return false; }
			final var root = _goals.load(profileId).orElse(null);
			if (root == null || root.goal().goalId() != goalId || root.goal().revision() != goalRevision || !PhantomAutonomousFarmParty.ordinaryIntent(profileId, root.goal()) || routeActivity(claim.state()).nonTerminal()) { return false; }
			for (var member : roster(claim.state()))
			{
				final var snapshot = _backend.memberSnapshot(member).orElse(null);
				if (snapshot == null || snapshot.dead() || snapshot.casting() || snapshot.attacking() || snapshot.moving() || _tacticalActions.containsKey(member.profileId()) || _tacticalCombat.containsKey(member.profileId())
					|| _tactics.combatOwner() != null && _tactics.combatOwner().hasClaim(member.profileId())
					|| _pendingManagedInvitations.values().stream().anyMatch(invitation -> invitation.requesterObjectId() == member.characterObjectId() || invitation.inviteeObjectId() == member.characterObjectId())) { return false; }
			}
			return _claims.get(profileId) == claim && _goals.load(profileId).filter(root::equals).isPresent() && releaseAutonomousFarm(claim.state().leader().profileId());
		}
	}

	/** Quiet farm members return through the existing native membership/CAS owner. */
	public boolean releaseAutonomousFarm(long leaderProfileId)
	{
		final var control = beginOperation();
		if (control == null) { return false; }
		try (control)
		{
			final var stored = _claims.get(leaderProfileId);
			if (!committedClaim(stored) || stored.state().leader().profileId() != leaderProfileId || !PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(stored.state().objectiveRef().namespace()) || !stored.state().realMembers().isEmpty()) { return false; }
			final var members = roster(stored.state()).stream().sorted(Comparator.comparingInt((MemberRef member) -> member.profileId() == leaderProfileId ? 1 : 0)).toList();
			for (var member : members)
			{
				final var active = _tacticalCombat.get(member.profileId());
				if (active != null) { cancelTacticalCombat(active); }
			}
			for (var member : members)
			{
				final var observed = _backend.memberSnapshot(member).orElse(null);
				if (observed != null && (observed.casting() || observed.attacking())) { return false; }
				// Missing snapshots are safe only when all observable native rosters prove absence.
				for (var other : members)
				{
					final var nativeParty = _backend.observe(other).orElse(null);
					if (nativeParty != null && (nativeParty.members().stream().anyMatch(ref -> ref.kind() != MemberKind.PHANTOM || !members.contains(ref)) || observed == null && nativeParty.members().contains(member))) { return false; }
				}
			}
			for (var member : members)
			{
				final var current = _claims.get(member.profileId());
				if (!committedClaim(current)) { continue; }
				final var root = _goals.load(member.profileId()).map(StoredGoal::goal).orElse(null);
				final var prior = current.state().operation();
				if (root == null && prior == null) { return false; }
				final var outcome = membership(member.profileId(), root == null ? prior.leaderGoalId() : root.goalId(), root == null ? prior.leaderGoalRevision() : root.revision(), current.state().groupGeneration(), root == null ? "" : root.goalType(), OperationKind.LEAVE, null, true);
				if (outcome != CommandOutcome.ACCEPTED && outcome != CommandOutcome.IDEMPOTENT) { return false; }
			}
			return true;
		}
	}

	public Optional<PendingResponseOutcome> conversationResponseOutcome(String planId, InvitationIdentity exactIdentity, PendingResponse response)
	{
		Objects.requireNonNull(exactIdentity);
		Objects.requireNonNull(response);
		if ((planId == null) || !planId.matches("[A-F0-9]{64}"))
		{
			return Optional.empty();
		}
		synchronized (_indexLock)
		{
			return Optional.ofNullable(_conversationResponses.get(new ConversationResponseKey(planId, exactIdentity, response)));
		}
	}

	public PendingResponseOutcome respondToPending(long profileId, InvitationIdentity exactIdentity, PendingResponse response, String planId)
	{
		return respondToPending(profileId, exactIdentity, response, planId, false);
	}

	public PendingResponseOutcome respondToPending(long profileId, InvitationIdentity exactIdentity, PendingResponse response, String planId, boolean requireInvitationEvidence)
	{
		Objects.requireNonNull(exactIdentity);
		Objects.requireNonNull(response);
		if ((planId == null) || !planId.matches("[A-F0-9]{64}"))
		{
			return PendingResponseOutcome.REJECTED;
		}
		final ConversationResponseKey responseKey = new ConversationResponseKey(planId, exactIdentity, response);
		synchronized (_indexLock)
		{
			final PendingResponseOutcome replay = _conversationResponses.get(responseKey);
			if (replay != null)
			{
				return replay == PendingResponseOutcome.COMPLETED ? PendingResponseOutcome.IDEMPOTENT : replay;
			}
			if (_conversationResponses.keySet().stream().anyMatch(key -> key.planId().equals(planId)))
			{
				return PendingResponseOutcome.REJECTED;
			}
		}
		final OperationClaim control = beginOperation();
		if (control == null)
		{
			return PendingResponseOutcome.STOPPING;
		}
		PendingResponseOutcome outcome;
		try (control)
		{
			final PartyInvitation invitation = _pendingManagedInvitations.get(profileId);
			if ((invitation == null) || !invitation.identity().equals(exactIdentity))
			{
				outcome = PendingResponseOutcome.STALE;
			}
			else
			{
				final MemberRef invitee = _backend.currentMember(profileId).orElse(null);
				final StoredGoal goal = _goals.load(profileId).orElse(null);
				final boolean exactConsent = (response == PendingResponse.REFUSE) || ((goal != null) && (goal.goal().status() == PhantomGoalStatus.ACTIVE) && JOIN_GOAL.equals(goal.goal().goalType()) && goalTargets(goal.goal(), invitation.requesterObjectId()) && goal.goal().purposeKey().equals("conversation.action") && goal.goal().reasonKey().equals("conversation.party.accept") && goalMatchesPlan(goal.goal(), planId) && (!requireInvitationEvidence || goalMatchesInvitation(goal.goal(), exactIdentity)));
				if ((invitee == null) || !exactConsent)
				{
					outcome = PendingResponseOutcome.REJECTED;
				}
				else
				{
					final PartyInvitationService.RespondResult result = _backend.respond(invitee, response == PendingResponse.ACCEPT ? Response.ACCEPT : Response.REFUSE, exactIdentity);
					outcome = (response == PendingResponse.ACCEPT) ? ((result != null) && result.accepted() ? PendingResponseOutcome.COMPLETED : PendingResponseOutcome.REJECTED) : ((result != null) && (result.outcome() == PartyInvitationService.RespondOutcome.REFUSED) ? PendingResponseOutcome.COMPLETED : PendingResponseOutcome.REJECTED);
					if (response == PendingResponse.ACCEPT)
					{
						if ((result != null) && result.accepted())
						{
							_metrics.inviteAccepted();
						}
						else
						{
							_metrics.inviteRefused();
						}
					}
					else
					{
						_metrics.inviteRefused();
					}
				}
			}
		}
		synchronized (_indexLock)
		{
			_conversationResponses.put(responseKey, outcome);
			while (_conversationResponses.size() > 512)
			{
				_conversationResponses.remove(_conversationResponses.keySet().iterator().next());
			}
		}
		return outcome;
	}

	private static boolean goalMatchesInvitation(PhantomGoal goal, InvitationIdentity identity)
	{
		return Objects.equals(goal.constraints().get("party.invitation"), identity.sequence()) && Objects.equals(goal.constraints().get("party.requester"), (long) identity.requesterObjectId()) && Objects.equals(goal.constraints().get("party.invitee"), (long) identity.inviteeObjectId());
	}

	private record ConversationResponseKey(String planId, InvitationIdentity identity, PendingResponse response)
	{
	}

	private static boolean goalMatchesPlan(PhantomGoal goal, String planId)
	{
		for (int index = 0; index < 4; index++)
		{
			final long expected = Long.parseUnsignedLong(planId.substring(index * 16, (index + 1) * 16), 16);
			if (!Objects.equals(goal.constraints().get("conversation.plan." + index), expected))
			{
				return false;
			}
		}
		return true;
	}

	private void processManagedInvitation(ManagedInvitation managed)
	{
		final PartyInvitation invitation = managed.invitation();
		final MemberRef invitee = _backend.currentMember(managed.profileId()).orElse(null);
		if (invitee == null)
		{
			PartyInvitationService.getInstance().cancel(invitation.identity());
			return;
		}
		final StoredGoal storedGoal = _goals.load(managed.profileId()).orElse(null);
		if ((storedGoal != null) && conversationOwnsAccept(storedGoal.goal()))
		{
			return;
		}
		if (retainedMemberConsent(managed.profileId(), storedGoal, invitation))
		{
			final var requester = _claims.get(_backend.managedProfileId(invitation.requesterObjectId()).orElse(0)).state().leader();
			if (_backend.autonomousFarmConsentAvailable(requester, invitee, invitation.identity())) { respondManaged(invitee, invitation, ManagedInvitationDecision.ACCEPT); }
			return;
		}
		final boolean explicitConsent = (storedGoal != null) && (storedGoal.goal().status() == PhantomGoalStatus.ACTIVE) && JOIN_GOAL.equals(storedGoal.goal().goalType()) && goalTargets(storedGoal.goal(), invitation.requesterObjectId());
		if (explicitConsent)
		{
			respondManaged(invitee, invitation, ManagedInvitationDecision.ACCEPT);
			return;
		}
		if ((storedGoal != null) && JOIN_GOAL.equals(storedGoal.goal().goalType()))
		{
			respondManaged(invitee, invitation, ManagedInvitationDecision.REFUSE);
			return;
		}
		final OptionalLong requesterProfile = _backend.managedProfileId(invitation.requesterObjectId());
		final long requesterProfileId = requesterProfile.orElse(0);
		final StoredGoal requesterGoal = requesterProfile.isPresent() ? _goals.load(requesterProfileId).orElse(null) : null;
		if (requesterProfile.isPresent() && ((requesterGoal == null) || (requesterGoal.goal().status() != PhantomGoalStatus.ACTIVE)))
		{
			return;
		}
		final ManagedInvitationPolicy policy = _managedInvitationPolicies.get(requesterProfile.isEmpty() ? PhantomRealPartyInvitationPolicy.POLICY_KEY : requesterGoal.goal().goalType());
		if (policy == null)
		{
			return;
		}
		final StoredPartyState leaderClaim = _claims.get(requesterProfileId);
		final StoredPartyState inviteeClaim = _claims.get(managed.profileId());
		final MemberSnapshot inviteeSnapshot = _backend.memberSnapshot(invitee).orElse(null);
		final ManagedInvitationDecision decision;
		try
		{
			decision = Objects.requireNonNullElse(policy.evaluate(new ManagedInvitationContext(invitation, requesterProfileId, managed.profileId(), leaderClaim == null ? null : leaderClaim.state(), inviteeClaim == null ? null : inviteeClaim.state(), storedGoal == null ? null : storedGoal.goal(), inviteeSnapshot)), ManagedInvitationDecision.DEFER);
		}
		catch (RuntimeException e)
		{
			return;
		}
		if ((decision == ManagedInvitationDecision.ACCEPT) || (decision == ManagedInvitationDecision.REFUSE))
		{
			respondManaged(invitee, invitation, decision);
		}
	}

	private void respondManaged(MemberRef invitee, PartyInvitation invitation, ManagedInvitationDecision decision)
	{
		final PartyInvitationService.RespondResult response = _backend.respond(invitee, decision == ManagedInvitationDecision.ACCEPT ? Response.ACCEPT : Response.REFUSE, invitation.identity());
		if ((decision == ManagedInvitationDecision.ACCEPT) && response.accepted())
		{
			_metrics.inviteAccepted();
		}
		else
		{
			_metrics.inviteRefused();
		}
	}

	/** Existing MEMBER intent retains consent only to its exact owned Phantom leader during rejoin. */
	private boolean retainedMemberConsent(long profileId, StoredGoal stored, PartyInvitation invitation)
	{
		if (stored == null || stored.goal().status() != PhantomGoalStatus.ACTIVE || !MEMBER_GOAL.equals(stored.goal().goalType()) || !goalTargets(stored.goal(), invitation.requesterObjectId())) { return false; }
		final long requester = _backend.managedProfileId(invitation.requesterObjectId()).orElse(0);
		final var leader = _claims.get(requester); final var member = _claims.get(profileId);
		if (leader == null || member == null || leader.state().leader().kind() != MemberKind.PHANTOM || leader.state().leader().profileId() != requester || leader.state().leader().characterObjectId() != invitation.requesterObjectId()
			|| !leader.state().realMembers().isEmpty() || !member.state().realMembers().isEmpty() || !leader.state().groupId().equals(member.state().groupId()) || leader.state().groupGeneration() != member.state().groupGeneration() || !leader.state().leaderManifestHash().equals(member.state().leaderManifestHash())
			|| !sameInvitation(leader.state().operation(), invitation.identity()) || !sameInvitation(member.state().operation(), invitation.identity()) || member.state().operation().member() == null || member.state().operation().member().profileId() != profileId || member.state().operation().member().characterObjectId() != invitation.inviteeObjectId()) { return false; }
		final var root = _goals.load(requester).map(StoredGoal::goal).orElse(null);
		return root != null && regroupLeaderRoot(leader.state(), root);
	}
	private static boolean conversationOwnsAccept(PhantomGoal goal)
	{
		if ((goal.status() != PhantomGoalStatus.ACTIVE) || !JOIN_GOAL.equals(goal.goalType()) || !goal.purposeKey().equals("conversation.action") || !goal.reasonKey().equals("conversation.party.accept"))
		{
			return false;
		}
		for (int index = 0; index < 4; index++)
		{
			if (!goal.constraints().containsKey("conversation.plan." + index))
			{
				return false;
			}
		}
		return goal.constraints().containsKey("party.invitation") && goal.constraints().containsKey("party.requester") && goal.constraints().containsKey("party.invitee");
	}

	private void processTerminal(TerminalEvent event)
	{
		final PartyInvitation invitation = event.invitation();
		if (event.outcome() != TerminalOutcome.ACCEPTED)
		{
			abortManagedInvitation(invitation, event.managedRequester(), event.managedInvitee(), event.reasonKey());
			emitInvitationTerminal(event);
			return;
		}
		event.managedRequester().ifPresent(profileId -> markObservedExact(profileId, invitation.identity()));
		event.managedInvitee().ifPresent(profileId -> markObservedExact(profileId, invitation.identity()));
		if (event.managedRequester().isPresent())
		{
			ensureGroup(groupForLeader(event.managedRequester().getAsLong()));
		}
		if (event.managedInvitee().isPresent())
		{
			final long profileId = event.managedInvitee().getAsLong();
			final MemberRef invitee = _backend.currentMember(profileId).orElse(null);
			final Optional<PartySnapshot> observed = invitee == null ? Optional.empty() : _backend.observe(invitee);
			if (observed.isPresent() && (observed.get().leader().kind() == MemberKind.REAL))
			{
				commitRealLedMember(profileId, _goals.load(profileId).orElse(null), observed.get(), invitation.identity());
			}
			else if (observed.isPresent())
			{
				ensureGroup(groupForLeader(observed.get().leader().profileId()));
			}
		}
		emitInvitationTerminal(event);
	}

	private void markObservedExact(long profileId, InvitationIdentity identity)
	{
		final StoredPartyState current = _claims.get(profileId);
		if ((current == null) || !sameInvitation(current.state().operation(), identity))
		{
			return;
		}
		try
		{
			final PartyOperation observed = current.state().operation().withPhase(OperationPhase.CANONICAL_OBSERVED, identity.sequence(), "");
			putClaim(save(profileId, current.rowVersion(), current.state().withOperation(current.state().status(), observed, "")));
		}
		catch (RuntimeException e)
		{
			markInconsistent(current, "invite.observation_conflict");
		}
	}

	private void rollbackPreparation(StoredPartyState previousLeader, StoredPartyState pendingLeader, StoredPartyState previousMember, StoredPartyState pendingMember)
	{
		rollbackPreparationSide(previousMember, pendingMember, "invite.member_prepare_rollback_conflict");
		rollbackPreparationSide(previousLeader, pendingLeader, "invite.leader_prepare_rollback_conflict");
	}

	private void rollbackPreparationSide(StoredPartyState previous, StoredPartyState pending, String failure)
	{
		if (pending == null)
		{
			return;
		}
		final StoredPartyState current = _claims.get(pending.profileId());
		if ((current == null) || (current.rowVersion() != pending.rowVersion()))
		{
			return;
		}
		if (previous == null)
		{
			moveToSolo(current, failure);
			return;
		}
		try
		{
			putClaim(save(current.profileId(), current.rowVersion(), previous.state()));
		}
		catch (RuntimeException e)
		{
			markInconsistent(current, failure);
		}
	}

	private int reconcile(GroupRuntime runtime, int remainingBudget)
	{
		final List<StoredPartyState> groupClaims = claims(runtime.groupId());
		int examined = 1 + groupClaims.size();
		if (examined > remainingBudget)
		{
			return 0;
		}
		if (groupClaims.isEmpty())
		{
			removeGroup(runtime.groupId());
			return examined;
		}
		final var sourceAuthority = groupClaims.stream().filter(claim -> claim.profileId() == claim.state().leader().profileId()).findFirst().orElse(groupClaims.getFirst()).state();
		final boolean refreshedFarmSource = PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(sourceAuthority.objectiveRef().namespace()) && currentFarmIntentView(sourceAuthority) == null;
		if (PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(sourceAuthority.objectiveRef().namespace())) { refreshFarmIntent(runtime, sourceAuthority); }
		if (PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(sourceAuthority.objectiveRef().namespace()) && !currentFarmIntent(sourceAuthority))
		{
			if (!releaseAutonomousFarm(sourceAuthority.leader().profileId()) && refreshedFarmSource) { groupClaims.forEach(this::reconcileObsoleteFarmOrphan); }
			return examined;
		}
		for (StoredPartyState claim : groupClaims)
		{
			final PartyOperation operation = claim.state().operation();
			if ((operation != null) && (operation.phase() == OperationPhase.CANONICAL_PENDING) && (operation.invitationSequence() > 0) && (_clock.getAsLong() >= operation.deadlineLogicalNanos()) && (operation.member() != null))
			{
				final InvitationIdentity identity = new InvitationIdentity(operation.invitationSequence(), operation.leader().characterObjectId(), operation.member().characterObjectId());
				if (!PartyInvitationService.getInstance().expire(identity))
				{
					PartyInvitationService.getInstance().cancel(identity);
				}
				return examined;
			}
			if ((operation != null) && (operation.phase() == OperationPhase.ABORTED))
			{
				return examined;
			}
		}
		if (groupClaims.stream().map(claim -> claim.state().operation()).anyMatch(operation -> (operation != null) && (operation.kind() == OperationKind.JOIN) && (operation.phase() == OperationPhase.CANONICAL_PENDING)))
		{
			return examined;
		}
		MemberRef leader = groupClaims.getFirst().state().leader();
		if (leader.kind() != MemberKind.PHANTOM)
		{
			return reconcileRealLed(runtime, groupClaims, remainingBudget);
		}
		final PartyState groupAuthority = groupClaims.stream().filter(claim -> claim.profileId() == claim.state().leader().profileId()).findFirst().orElse(groupClaims.getFirst()).state();
		final boolean farmRecovery = PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(groupAuthority.objectiveRef().namespace());
		final var planned = PhantomAutonomousFarmParty.plannedProfiles(groupAuthority.objectiveRef());
		final List<MemberRef> expected = farmRecovery ? planned.stream().map(_backend::currentMember).flatMap(Optional::stream).toList()
			: groupClaims.stream().flatMap(claim -> claim.state().phantomMembers().stream()).distinct().sorted(Comparator.comparing(MemberRef::stableKey)).toList();
		if (farmRecovery && (planned.size() < 2 || expected.size() != planned.size())) { return examined; }
		if (!_backend.materialize(leader.profileId()))
		{
			final MemberRef elected = expected.stream().min(Comparator.comparingLong(MemberRef::profileId)).orElse(leader);
			if (!elected.equals(leader) && _backend.materialize(elected.profileId()))
			{
				electLeader(groupClaims, elected);
				leader = elected;
			}
			else
			{
				return examined;
			}
		}
		final Optional<PartySnapshot> observed = _backend.observe(leader);
		if (observed.isEmpty())
		{
			if (groupClaims.stream().anyMatch(claim -> !claim.state().realMembers().isEmpty()))
			{
				releaseLostMixedGroup(runtime, groupClaims);
				return examined;
			}
			final MemberRef expectedLeader = leader;
			final MemberRef missing = expected.stream().filter(member -> !member.equals(expectedLeader)).filter(member -> _backend.materialize(member.profileId())).sorted(Comparator.comparingDouble(member -> regroupDistance(expectedLeader, member))).findFirst().orElse(null);
			if (missing != null)
			{
				if (remainingBudget - examined < 3) { return examined; }
				invite(leader.profileId(), missing, PartyDistributionType.FINDERS_KEEPERS);
				examined += 3;
			}
			return examined;
		}
		final PartySnapshot party = observed.get();
		if (groupClaims.stream().anyMatch(claim -> !claim.state().realMembers().isEmpty()) && party.members().stream().noneMatch(member -> member.kind() == MemberKind.REAL))
		{
			releaseDepartedMixedGroup(runtime, groupClaims, party);
			return examined;
		}
		if (!party.leader().equals(leader))
		{
			final PartyState before = groupClaims.getFirst().state();
			final PartyOperation previous = before.operation();
			final PartyOperation recovery = operation(before, OperationKind.RECOVER, null, previous == null ? 1 : previous.leaderGoalId(), previous == null ? 0 : previous.leaderGoalRevision());
			if (!commitMembership(before, party, recovery))
			{
				return examined;
			}
			leader = party.leader();
		}
		if (groupClaims.stream().map(claim -> claim.state().operation()).anyMatch(operation -> operation != null && operation.kind() == OperationKind.JOIN && operation.phase() == OperationPhase.CANONICAL_OBSERVED && operation.member() != null && party.members().contains(operation.member())))
		{
			// Commit this observed join before preparing the next missing planned member.
			commitObserved(groupClaims, party);
			return examined;
		}
		final MemberRef missing = leader.kind() == MemberKind.PHANTOM ? expected.stream().filter(member -> !party.members().contains(member)).filter(member -> _backend.materialize(member.profileId())).sorted(Comparator.comparingDouble(member -> regroupDistance(party.leader(), member))).findFirst().orElse(null) : null;
		if (missing != null)
		{
			if (remainingBudget - examined < 3) { return examined; }
			invite(leader.profileId(), missing, party.distribution());
			examined += 3;
			return examined;
		}
		final List<StoredPartyState> current = claims(runtime.groupId());
		if (current.isEmpty())
		{
			removeGroup(runtime.groupId());
			return examined;
		}
		commitObserved(current, party);
		if (examined < remainingBudget)
		{
			final var leaderClaim = _claims.get(party.leader().profileId());
			if (leaderClaim != null)
			{
				for (var member : party.members())
				{
					if (examined + 4 > remainingBudget) { break; }
					if (member.kind() == MemberKind.PHANTOM) { advanceRegroup(leaderClaim, member); examined += 4; }
				}
			}
		}
		examined += advanceCompanionCommands(party, remainingBudget - examined);
		examined += advanceRoute(runtime.groupId(), party, remainingBudget - examined);
		if (examined < remainingBudget)
		{
			examined += dispatchTactics(party, remainingBudget - examined);
		}
		return Math.min(remainingBudget, examined);
	}

	private double regroupDistance(MemberRef leader, MemberRef member)
	{
		final var first = _backend.memberSnapshot(leader).orElse(null); final var second = _backend.memberSnapshot(member).orElse(null);
		return first == null || second == null || first.instanceId() != second.instanceId() ? Double.MAX_VALUE : Math.hypot((long) first.x() - second.x(), (long) first.y() - second.y()) + Math.abs((long) first.z() - second.z());
	}

	private int reconcileRealLed(GroupRuntime runtime, List<StoredPartyState> groupClaims, int remainingBudget)
	{
		int examined = 1 + groupClaims.size();
		final PartySnapshot party = groupClaims.stream().map(claim -> _backend.currentMember(claim.profileId()).flatMap(_backend::observe)).flatMap(Optional::stream).findFirst().orElse(null);
		if (party == null)
		{
			releaseLostMixedGroup(runtime, groupClaims);
			return examined;
		}
		final PartyState before = groupClaims.getFirst().state();
		final List<MemberRef> phantoms = party.members().stream().filter(member -> member.kind() == MemberKind.PHANTOM).sorted(Comparator.comparing(MemberRef::stableKey)).toList();
		final List<MemberRef> reals = party.members().stream().filter(member -> member.kind() == MemberKind.REAL).sorted(Comparator.comparing(MemberRef::stableKey)).toList();
		if (!before.realMembers().isEmpty() && reals.isEmpty())
		{
			releaseDepartedMixedGroup(runtime, groupClaims, party);
			return examined;
		}
		if (!before.leader().equals(party.leader()) || !before.phantomMembers().equals(phantoms) || !before.realMembers().equals(reals))
		{
			final PartyOperation previous = before.operation();
			final PartyOperation recovery = operation(before, OperationKind.RECOVER, null, previous == null ? 1 : previous.leaderGoalId(), previous == null ? 0 : previous.leaderGoalRevision());
			if (!commitMembership(before, party, recovery))
			{
				return examined;
			}
		}
		final List<StoredPartyState> current = claims(runtime.groupId());
		if (current.isEmpty())
		{
			removeGroup(runtime.groupId());
			return examined;
		}
		commitObserved(current, party);
		examined += advanceCompanionCommands(party, remainingBudget - examined);
		if (examined < remainingBudget)
		{
			examined += dispatchTactics(party, remainingBudget - examined);
		}
		if (examined < remainingBudget)
		{
			examined += advanceRealFollow(party, remainingBudget - examined);
		}
		return Math.min(remainingBudget, examined);
	}

	private int advanceRealFollow(PartySnapshot party, int remainingBudget)
	{
		if (party.leader().kind() != MemberKind.REAL)
		{
			return 0;
		}
		final Map<MemberRef, MemberSnapshot> snapshots = snapshots(party.members());
		final MemberSnapshot leader = snapshots.get(party.leader());
		int examined = 0;
		for (MemberRef member : party.members())
		{
			if ((member.kind() != MemberKind.PHANTOM) || (remainingBudget - examined < 3))
			{
				continue;
			}
			final StoredPartyState claim = _claims.get(member.profileId());
			if ((claim == null) || !committedClaim(claim) || !claim.state().leader().equals(party.leader()) || holdsMovement(member.profileId()))
			{
				continue;
			}
			final String groupId = claim.state().groupId();
			final long generation = claim.state().groupGeneration();
			examined += _routes.follow(groupId, generation, snapshots.get(member), leader, _topologyHash.get(), Math.max(0, _clock.getAsLong()), remainingBudget - examined, () ->
			{
				final StoredPartyState current = _claims.get(member.profileId());
				return (_state != State.RUNNING) || (current == null) || !current.state().groupId().equals(groupId) || (current.state().groupGeneration() != generation) || !current.state().leader().equals(party.leader()) || !current.state().phantomMembers().contains(member);
			});
		}
		return examined;
	}

	/** A normal human logout may leave a native all-Phantom party behind. Release only its old companions. */
	private void releaseDepartedMixedGroup(GroupRuntime runtime, List<StoredPartyState> groupClaims, PartySnapshot departed)
	{
		for (StoredPartyState claim : groupClaims)
		{
			final StoredPartyState latest = _claims.get(claim.profileId());
			if ((latest == null) || !latest.state().groupId().equals(claim.state().groupId()) || (latest.state().groupGeneration() != claim.state().groupGeneration()))
			{
				continue;
			}
			final MemberRef member = _backend.currentMember(claim.profileId()).orElse(null);
			final PartySnapshot current = member == null ? null : _backend.observe(member).orElse(null);
			if (current == null)
			{
				continue;
			}
			if (current.members().stream().anyMatch(value -> (value.kind() == MemberKind.REAL) || !departed.members().contains(value)))
			{
				return;
			}
			final MembershipOutcome outcome = _backend.leave(member);
			if ((outcome != MembershipOutcome.COMPLETED) && (outcome != MembershipOutcome.NOT_IN_PARTY))
			{
				return;
			}
		}
		releaseLostMixedGroup(runtime, groupClaims);
	}

	private void releaseLostMixedGroup(GroupRuntime runtime, List<StoredPartyState> groupClaims)
	{
		for (StoredPartyState claim : groupClaims)
		{
			final StoredPartyState latest = _claims.get(claim.profileId());
			if ((latest == null) || !latest.state().groupId().equals(claim.state().groupId()) || (latest.state().groupGeneration() != claim.state().groupGeneration()))
			{
				continue;
			}
			final PartyOperation operation = latest.state().operation();
			final StoredGoal current = _goals.load(claim.profileId()).orElse(null);
			if ((operation != null) && (current != null) && (current.goal().goalId() == operation.leaderGoalId()) && (current.goal().status() == PhantomGoalStatus.ACTIVE) && Set.of(FORM_GOAL, JOIN_GOAL, LEAD_GOAL, MEMBER_GOAL).contains(current.goal().goalType()))
			{
				try
				{
					_goals.replace(claim.profileId(), current.rowVersion(), current.goal().withStatus(PhantomGoalStatus.ABANDONED));
				}
				catch (RuntimeException exception)
				{
					_metrics.conflict();
				}
			}
			final ExternalActionLease tactical = _tacticalActions.get(claim.profileId());
			if ((tactical != null) && tactical.operationKey().startsWith(tacticalScope(claim.state())) && _tacticalActions.remove(claim.profileId(), tactical))
			{
				tactical.close();
			}
			final TacticalCombatClaim combat = _tacticalCombat.get(claim.profileId());
			if ((combat != null) && combat.operationKey().startsWith(tacticalScope(claim.state())))
			{
				cancelTacticalCombat(combat);
			}
			moveToSolo(latest, "party.real.membership_lost");
		}
		if (claims(runtime.groupId()).isEmpty())
		{
			removeGroup(runtime.groupId());
		}
	}

	private int advanceRoute(String groupId, PartySnapshot party, int remainingBudget)
	{
		final List<StoredPartyState> claims = claims(groupId);
		if (claims.isEmpty())
		{
			return 0;
		}
		RouteManifest route = claims.getFirst().state().route();
		if (route == null)
		{
			final PhantomPartyRouteCoordinator.RouteAttempt attempt = _routes.poll(groupId);
			if (attempt.status() != PhantomPartyRouteCoordinator.AttemptStatus.READY)
			{
				return 0;
			}
			route = attempt.route();
			persistRoute(groupId, route);
		}
		final Map<MemberRef, MemberSnapshot> snapshots = snapshots(party.members());
		final boolean paused = party.members().stream().anyMatch(member -> (member.kind() == MemberKind.PHANTOM) && holdsMovement(member.profileId()));
		final PhantomPartyRouteCoordinator.AdvanceResult result = _routes.advance(groupId, route, party.leader(), party.members(), snapshots, Math.max(1, remainingBudget), Math.max(0, _clock.getAsLong()), _topologyHash.get(), () -> _state != State.RUNNING, paused);
		final RouteManifest advanced = result.route();
		if (!advanced.equals(route))
		{
			persistRoute(groupId, advanced);
		}
		return result.examinedOperations();
	}

	private void persistRoute(String groupId, RouteManifest route)
	{
		for (StoredPartyState claim : claims(groupId))
		{
			final PartyState state = claim.state();
			final PartyOperation base = state.operation();
			final long goalId = base == null ? 1 : base.leaderGoalId();
			final long goalRevision = base == null ? 0 : base.leaderGoalRevision();
			final PartyOperation operation = new PartyOperation(PhantomPartyModel.stableOperationId(state.groupId(), state.groupGeneration(), state.membershipRevision(), OperationKind.ROUTE, state.leader(), null, goalId, goalRevision, state.leaderManifestHash()), OperationKind.ROUTE, OperationPhase.COMMITTED, state.leader(), null, goalId, goalRevision, state.leaderManifestHash(), 0, deadline(), "");
			final PartyState draft = new PartyState(state.groupId(), state.groupGeneration(), state.membershipRevision(), state.status(), state.leader(), state.ownRoleKey(), ZERO_HASH, state.phantomMembers(), state.realMembers(), state.objectiveMode(), route.destination(), state.requirements(), state.assignments(), route, operation, state.progressionHash(), state.topologyHash(), "");
			final PartyState next = new PartyState(draft.groupId(), draft.groupGeneration(), draft.membershipRevision(), draft.status(), draft.leader(), draft.ownRoleKey(), draft.canonicalManifestHash(), draft.phantomMembers(), draft.realMembers(), draft.objectiveMode(), draft.objectiveRef(), draft.requirements(), draft.assignments(), draft.route(), draft.operation(), draft.progressionHash(), draft.topologyHash(), draft.lastFailureKey(), state.command());
			try
			{
				putClaim(save(claim.profileId(), claim.rowVersion(), next));
			}
			catch (RuntimeException e)
			{
				_metrics.conflict();
				return;
			}
		}
	}

	private void commitObserved(List<StoredPartyState> existing, PartySnapshot party)
	{
		final PartyState authority = existing.stream().filter(claim -> claim.state().leader().equals(party.leader())).findFirst().orElse(existing.getFirst()).state();
		final PartyOperation observedJoin = exactObservedJoin(existing, party);
		final List<MemberRef> phantoms = party.members().stream().filter(member -> member.kind() == MemberKind.PHANTOM).sorted(Comparator.comparing(MemberRef::stableKey)).toList();
		final List<MemberRef> reals = party.members().stream().filter(member -> member.kind() == MemberKind.REAL).sorted(Comparator.comparing(MemberRef::stableKey)).toList();
		final Map<MemberRef, MemberSnapshot> snapshots = snapshots(party.members());
		final RoleMatchResult roles = _roles.match(authority.objectiveMode(), authority.requirements(), new ArrayList<>(snapshots.values()));
		final boolean stable = authority.leader().equals(party.leader()) //
			&& authority.phantomMembers().equals(phantoms) //
			&& authority.realMembers().equals(reals) //
			&& authority.assignments().equals(roles.assignments()) //
			&& (existing.size() == phantoms.size()) //
			&& existing.stream().allMatch(claim -> Set.of(StateStatus.LEADER, StateStatus.MEMBER).contains(claim.state().status()) && claim.state().leaderManifestHash().equals(authority.leaderManifestHash()));
		if (stable)
		{
			ensureCommittedGoals(existing);
			return;
		}
		final boolean membershipChanged = !authority.leader().equals(party.leader()) || !authority.phantomMembers().equals(phantoms) || !authority.realMembers().equals(reals);
		final long generation = Math.addExact(authority.groupGeneration(), membershipChanged ? 1 : 0);
		final PartyState draft = state(authority.groupId(), generation, authority.membershipRevision() + 1, party.leader().kind() == MemberKind.PHANTOM ? StateStatus.LEADER : StateStatus.MEMBER, party.leader(), phantoms, reals, authority.objectiveMode(), authority.objectiveRef(), authority.requirements(), roles.assignments(), authority.route(), authority.operation(), progressionEvidence(snapshots), "");
		final String manifest = draft.canonicalManifestHash();
		for (MemberRef member : phantoms)
		{
			final StoredPartyState current = _claims.get(member.profileId());
			final String ownRole = roles.assignments().stream().filter(assignment -> assignment.member().equals(member)).map(RoleAssignment::roleKey).findFirst().orElse("");
			// Real-led companions may each own a different speech-created JOIN goal.
			final PartyOperation ownOperation = committedClaim(current) && (party.leader().kind() == MemberKind.REAL) && current.state().leader().equals(party.leader()) ? current.state().operation() : null;
			final PartyOperation sourceOperation = ownOperation == null ? authority.operation() : ownOperation;
			final PartyOperation operation = sourceOperation == null ? null : sourceOperation.withPhase(OperationPhase.COMMITTED, sourceOperation.invitationSequence(), "");
			final boolean sameAuthority = (current != null) && current.state().groupId().equals(authority.groupId()) && (current.state().groupGeneration() == generation) && current.state().leader().equals(party.leader());
			final PartyState next = new PartyState(authority.groupId(), generation, draft.membershipRevision(), member.equals(party.leader()) ? StateStatus.LEADER : StateStatus.MEMBER, party.leader(), ownRole, manifest, phantoms, reals, authority.objectiveMode(), authority.objectiveRef(), authority.requirements(), roles.assignments(), authority.route(), operation, draft.progressionHash(), draft.topologyHash(), "", !membershipChanged && sameAuthority ? current.state().command() : null);
			try
			{
				final StoredPartyState saved = save(member.profileId(), current == null ? -1 : current.rowVersion(), next);
				putClaim(saved);
				transitionGoal(member.profileId(), member.equals(party.leader()) ? LEAD_GOAL : MEMBER_GOAL, member.equals(party.leader()) || (current == null) ? authority.operation() : current.state().operation());
			}
			catch (RuntimeException e)
			{
				_metrics.conflict();
				return;
			}
		}
		final boolean farmRecovery = PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(authority.objectiveRef().namespace());
		final boolean genericPhantomRecovery = authority.objectiveMode() == ObjectiveMode.GENERAL_PVE
			&& authority.leader().kind() == MemberKind.PHANTOM && authority.leader().equals(party.leader())
			&& authority.realMembers().isEmpty() && reals.isEmpty();
		if (farmRecovery || genericPhantomRecovery)
		{
			for (var absent : existing)
			{
				if (absent.state().status() != StateStatus.RECOVERING || phantoms.stream().anyMatch(member -> member.profileId() == absent.profileId())) { continue; }
				final var current = _claims.get(absent.profileId());
				if (current == null || current.rowVersion() != absent.rowVersion()) { continue; }
				final var previous = current.state();
				if (!farmRecovery)
				{
					final var member = previous.phantomMembers().stream().filter(value -> value.profileId() == absent.profileId()).findFirst().orElse(null);
					if (!previous.groupId().equals(authority.groupId()) || previous.groupGeneration() != authority.groupGeneration()
						|| !previous.leaderManifestHash().equals(authority.leaderManifestHash()) || !previous.leader().equals(authority.leader())
						|| !previous.realMembers().isEmpty() || previous.objectiveMode() != authority.objectiveMode()
						|| !previous.objectiveRef().equals(authority.objectiveRef()) || member == null || !authority.phantomMembers().contains(member)) { continue; }
				}
				// A partial native rejoin must retain the exact absent member's old roster and owned root.
				final var recoveryOperation = farmRecovery ? authority.operation() : previous.operation();
				final var recovering = new PartyState(previous.groupId(), generation, draft.membershipRevision(), StateStatus.RECOVERING, party.leader(), previous.ownRoleKey(), manifest, previous.phantomMembers(), List.of(), previous.objectiveMode(), previous.objectiveRef(), previous.requirements(), previous.assignments(), null, recoveryOperation, previous.progressionHash(), previous.topologyHash(), "");
				try { putClaim(save(current.profileId(), current.rowVersion(), recovering)); }
				catch (RuntimeException failure) { _metrics.conflict(); return; }
			}
		}
		_metrics.commit();
		emitJoined(phantoms, observedJoin, observedJoin == null ? null : observedJoin.withPhase(OperationPhase.COMMITTED, observedJoin.invitationSequence(), ""));
	}

	private static PartyOperation exactObservedJoin(List<StoredPartyState> existing, PartySnapshot party)
	{
		PartyOperation candidate = null;
		for (StoredPartyState stored : existing)
		{
			final PartyOperation operation = stored.state().operation();
			if ((operation == null) || (operation.kind() != OperationKind.JOIN) || (operation.phase() != OperationPhase.CANONICAL_OBSERVED) || !operation.leader().equals(party.leader()) || (operation.member() == null) || !party.members().contains(operation.member()))
			{
				continue;
			}
			if ((candidate != null) && (!candidate.operationId().equals(operation.operationId()) || (candidate.invitationSequence() != operation.invitationSequence()) || !candidate.leader().equals(operation.leader()) || !candidate.member().equals(operation.member())))
			{
				return null;
			}
			candidate = operation;
		}
		return candidate;
	}

	private void commitRealLedMember(long profileId, StoredGoal joinGoal, PartySnapshot party, InvitationIdentity identity)
	{
		final MemberRef member = _backend.currentMember(profileId).orElse(null);
		if (member == null)
		{
			return;
		}
		final String groupId = PhantomPartyModel.sha256("party.real|" + party.leader().characterObjectId() + '|' + identity.sequence());
		final List<MemberRef> phantoms = party.members().stream().filter(value -> value.kind() == MemberKind.PHANTOM).toList();
		final List<MemberRef> reals = party.members().stream().filter(value -> value.kind() == MemberKind.REAL).toList();
		final StoredPartyState current = _claims.get(profileId);
		final PartyOperation observed = ((current == null) || (current.state().status() == StateStatus.SOLO) || !sameInvitation(current.state().operation(), identity)) ? null : current.state().operation();
		final long goalId = observed == null ? (joinGoal == null ? identity.sequence() : joinGoal.goal().goalId()) : observed.leaderGoalId();
		final long goalRevision = observed == null ? (joinGoal == null ? 0 : joinGoal.goal().revision()) : observed.leaderGoalRevision();
		final String operationId = observed == null ? PhantomPartyModel.sha256(INVITATION_SESSION + '|' + groupId + "|join|" + profileId) : observed.operationId();
		final PartyOperation operation = new PartyOperation(operationId, OperationKind.JOIN, OperationPhase.COMMITTED, party.leader(), member, goalId, goalRevision, ZERO_HASH, identity.sequence(), deadline(), "");
		// A new human invitation must not reuse an expelled member's former authority epoch.
		final long generation = Math.addExact(phantoms.stream().map(value -> _claims.get(value.profileId())).filter(Objects::nonNull).mapToLong(value -> value.state().groupGeneration()).max().orElse(0), 1);
		final PartyState draft = state(groupId, generation, generation, StateStatus.MEMBER, party.leader(), phantoms, reals, ObjectiveMode.GENERAL_PVE, new PhantomDomainRef("party", "real-led"), List.of(), List.of(), null, operation, progressionHash(member), "");
		final PartyState committed = new PartyState(draft.groupId(), draft.groupGeneration(), draft.membershipRevision(), draft.status(), draft.leader(), draft.ownRoleKey(), draft.canonicalManifestHash(), draft.phantomMembers(), draft.realMembers(), draft.objectiveMode(), draft.objectiveRef(), draft.requirements(), draft.assignments(), null, operation, draft.progressionHash(), draft.topologyHash(), "");
		try
		{
			putClaim(save(profileId, current == null ? -1 : current.rowVersion(), committed));
			transitionGoal(profileId, MEMBER_GOAL, operation);
			if (observed == null)
			{
				// This native human invitation deliberately had no managed goal/prepared JOIN to preserve personal FARM.
				emitSocial(profileId, "party.member.joined", subject(party.leader()), operation.operationId(), "membership");
			}
			else
			{
				emitJoined(phantoms, observed, operation);
			}
		}
		catch (RuntimeException e)
		{
			_metrics.conflict();
		}
	}

	/** Shared control-plane read, at most five versioned roots once per second/group. Never a combat callback. */
	private void refreshFarmIntent(GroupRuntime runtime, PartyState authority)
	{
		if (currentFarmIntentView(authority) != null) { return; }
		final long now = _clock.getAsLong();
		runtime.farmSource = null; // A failed refresh cannot retain previously granted authority.
		final var planned = PhantomAutonomousFarmParty.plannedProfiles(authority.objectiveRef());
		final var operation = authority.operation();
		final Map<Long, Long> versions = new java.util.LinkedHashMap<>();
		boolean valid = planned.size() >= 2 && planned.getFirst() == authority.leader().profileId() && operation != null;
		for (long profile : planned)
		{
			final var source = _goals.load(profile).orElse(null);
			if (source == null) { valid = false; continue; }
			versions.put(profile, source.rowVersion());
			final var goal = source.goal();
			valid &= PhantomAutonomousFarmParty.ordinaryIntent(profile, goal);
			if (profile == authority.leader().profileId()) { valid &= operation != null && goal.goalId() == operation.leaderGoalId() && goal.revision() == operation.leaderGoalRevision(); }
		}
		runtime.farmSource = new FarmSourceView(farmSourceKey(authority), now, now + 1_000_000_000L, Map.copyOf(versions), valid);
	}

	private static FarmSourceKey farmSourceKey(PartyState authority)
	{
		final var operation = authority.operation();
		return new FarmSourceKey(authority.groupGeneration(), authority.leader(), authority.objectiveRef(), operation == null ? 0 : operation.leaderGoalId(), operation == null ? 0 : operation.leaderGoalRevision());
	}

	private FarmSourceView currentFarmIntentView(PartyState authority)
	{
		final var runtime = _groups.get(authority.groupId());
		final var source = runtime == null ? null : runtime.farmSource;
		final long now = _clock.getAsLong();
		return source != null && source.key().equals(farmSourceKey(authority)) && now >= source.sampledNanos() && now < source.expiresNanos() ? source : null;
	}

	private boolean currentFarmIntent(PartyState authority)
	{
		final var source = currentFarmIntentView(authority);
		return source != null && source.valid();
	}

	private boolean currentFarmReady(PartyState authority, PartySnapshot party)
	{
		final var planned = PhantomAutonomousFarmParty.plannedProfiles(authority.objectiveRef());
		if (party == null || !party.leader().equals(authority.leader()) || party.members().size() != planned.size() || !sameRoster(roster(authority), party.members()) || party.members().stream().anyMatch(member -> member.kind() != MemberKind.PHANTOM || !planned.contains(member.profileId())) || !currentFarmIntent(authority)) { return false; }
		return authority.assignments().stream().filter(assignment -> assignment.roleKey().startsWith("support.")).map(RoleAssignment::member).anyMatch(member -> _backend.memberSnapshot(member).filter(PhantomAutonomousFarmParty::supportPresent).isPresent()) && _backend.autonomousFarmReady(party);
	}

	private int dispatchTactics(PartySnapshot party, int remainingBudget)
	{
		final var farmClaim = _claims.get(party.leader().profileId());
		final boolean farm = farmClaim != null && PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(farmClaim.state().objectiveRef().namespace());
		boolean farmReady = true;
		if (farm)
		{
			final boolean intent = currentFarmIntent(farmClaim.state());
			farmReady = intent && currentFarmReady(farmClaim.state(), party);
			if (!intent) { return 0; }
		}
		final Map<MemberRef, MemberSnapshot> snapshots = snapshots(party.members());
		// Farm projections already reserve assigned support members for native support.
		// Do not give their weapon an autoattack owner that can starve an urgent heal.
		final Set<MemberRef> supportMembers = farm ? farmClaim.state().assignments().stream().filter(assignment -> assignment.roleKey().startsWith("support.")).map(RoleAssignment::member).collect(java.util.stream.Collectors.toSet()) : Set.of();
		final List<TacticalDirective> directives = _tactics.plan(party.leader(), party.members(), snapshots, directive -> !supportMembers.contains(directive.actor()) || !Set.of(DirectiveKind.ASSIST_TARGET, DirectiveKind.PROTECT_MEMBER).contains(directive.kind()));
		final Set<Long> occupied = Set.copyOf(_tacticalActions.keySet());
		final Set<Long> decided = new HashSet<>();
		int examined = 0;
		for (TacticalDirective directive : directives)
		{
			if (farm && !farmReady && Set.of(DirectiveKind.ASSIST_TARGET, DirectiveKind.PROTECT_MEMBER).contains(directive.kind())) { continue; }
			if (examined >= remainingBudget)
			{
				break;
			}
			examined++;
			if (occupied.contains(directive.actor().profileId()) || _tacticalActions.containsKey(directive.actor().profileId()) || decided.contains(directive.actor().profileId()))
			{
				continue;
			}
			final StoredPartyState claim = _claims.get(directive.actor().profileId());
			if ((claim == null) || !committedClaim(claim) || !claim.state().leader().equals(party.leader()) || !claim.state().phantomMembers().contains(directive.actor()))
			{
				continue;
			}
			final CompanionCommand command = claim.state().command();
			if ((command != null) && (command.mode() != CompanionMode.FOLLOW) && ((command.mode() == CompanionMode.PENDING_HOLD) || !Set.of(DirectiveKind.HEAL_MEMBER, DirectiveKind.RECHARGE_MEMBER, DirectiveKind.RESURRECT_MEMBER, DirectiveKind.PARTY_SUPPORT).contains(directive.kind())))
			{
				continue;
			}
			final String key = tacticalScope(claim.state()) + directive.kind().name().toLowerCase(java.util.Locale.ROOT) + '.' + directive.actor().profileId();
			final boolean offense = Set.of(DirectiveKind.ASSIST_TARGET, DirectiveKind.PROTECT_MEMBER).contains(directive.kind());
			if (offense && ((_tactics.combatOwner() == null) || _tactics.combatMode(directive).isEmpty() || _tactics.combatOwner().observeNormalTarget(directive.actor().profileId(), directive.targetObjectId()).isEmpty()))
			{
				continue;
			}
			decided.add(directive.actor().profileId());
			final TacticalCombatClaim active = _tacticalCombat.get(directive.actor().profileId());
			final MemberSnapshot actor = snapshots.get(directive.actor());
			if (active != null)
			{
				// Nonurgent maintenance cannot replace an owned fight or native pickup.
				if (directive.kind() == DirectiveKind.PARTY_SUPPORT) { continue; }
				// Retarget only after the current native cast/attack; movement never breaks it.
				if ((!offense || (active.targetObjectId() != directive.targetObjectId())) && (actor != null) && !actor.casting() && !actor.attacking())
				{
					cancelTacticalCombat(active);
				}
				continue;
			}
			if (offense)
			{
				if ((actor == null) || actor.casting() || actor.attacking())
				{
					continue;
				}
				_routes.cancelFollow(claim.state().groupId(), claim.state().groupGeneration(), directive.actor().profileId());
				if (_backend.memberSnapshot(directive.actor()).map(MemberSnapshot::moving).orElse(true))
				{
					continue;
				}
				dispatchTacticalCombat(directive, key, claim.state());
				continue;
			}
			if (Set.of(DirectiveKind.HEAL_MEMBER, DirectiveKind.RECHARGE_MEMBER, DirectiveKind.RESURRECT_MEMBER, DirectiveKind.PROTECT_MEMBER).contains(directive.kind()))
			{
				_routes.cancelFollow(claim.state().groupId(), claim.state().groupGeneration(), directive.actor().profileId());
			}
			_tactics.dispatch(directive, key, deadline(), supportToken(directive, claim.state()), holdsMovement(directive.actor().profileId())).ifPresent(lease ->
			{
				_tacticalActions.put(directive.actor().profileId(), lease);
				_tacticalReleases.offer(directive.actor().profileId());
			});
		}
		return examined;
	}

	/** A pending native approach/cast belongs only to this current party authority. */
	private PhantomCancellationToken supportToken(TacticalDirective directive, PartyState authority)
	{
		return () ->
		{
			final StoredPartyState current = _claims.get(directive.actor().profileId());
			if (PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(authority.objectiveRef().namespace()) && !currentFarmIntent(authority)) { return true; }
			if ((_state != State.RUNNING) || !committedClaim(current) || !current.state().groupId().equals(authority.groupId()) || (current.state().groupGeneration() != authority.groupGeneration()) || !current.state().leader().equals(authority.leader()) || !_backend.currentMember(directive.actor().profileId()).filter(directive.actor()::equals).isPresent())
			{
				return true;
			}
			final PartySnapshot party = _backend.observe(directive.actor()).orElse(null);
			if ((party == null) || !party.leader().equals(authority.leader()) || !sameRoster(roster(authority), party.members()))
			{
				return true;
			}
			final MemberSnapshot actor = _backend.memberSnapshot(directive.actor()).orElse(null);
			final MemberSnapshot target = _backend.memberSnapshot(directive.targetMember()).orElse(null);
			return (actor == null) || actor.dead() || (target == null) || (actor.instanceId() != target.instanceId());
		};
	}

	private void dispatchTacticalCombat(TacticalDirective directive, String key, PartyState authority)
	{
		final PhantomCombatService combat = _tactics.combatOwner();
		final var mode = _tactics.combatMode(directive);
		if ((combat == null) || mode.isEmpty())
		{
			return;
		}
		final long profileId = directive.actor().profileId();
		final PhantomCancellationToken token = () ->
		{
			final StoredPartyState current = _claims.get(profileId);
			final var observed = _backend.observe(directive.actor()).orElse(null);
			return (_state != State.RUNNING) || (current == null) || !current.state().groupId().equals(authority.groupId()) || (current.state().groupGeneration() != authority.groupGeneration()) || !current.state().leader().equals(authority.leader()) || commandStopsCombat(profileId)
				|| PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(authority.objectiveRef().namespace()) && !currentFarmReady(authority, observed)
				|| observed == null || !observed.leader().equals(authority.leader()) || !observed.members().contains(directive.actor());
		};
		final boolean loot = PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(authority.objectiveRef().namespace()) && authority.leader().equals(directive.actor());
		final var started = combat.startContentSession(new PhantomCombatRequest(profileId, directive.targetObjectId(), mode.orElseThrow(), true, loot, 60000, token), key);
		if (started.accepted() && (started.session() != null))
		{
			final TacticalCombatClaim next = new TacticalCombatClaim(profileId, started.session().generation(), directive.targetObjectId(), key, token);
			if (_tacticalCombat.putIfAbsent(profileId, next) != null)
			{
				cancelTacticalCombat(next);
			}
			_tacticalReleases.offer(profileId);
		}
	}

	private boolean releaseTacticalCombat(TacticalCombatClaim claim)
	{
		final PhantomCombatService combat = _tactics.combatOwner();
		if ((combat == null) || !combat.matchesOwnedSession(claim.profileId(), claim.generation(), claim.targetObjectId(), claim.token()) || combat.consumeTerminal(claim.profileId()).isPresent())
		{
			_tacticalCombat.remove(claim.profileId(), claim);
			return true;
		}
		return false;
	}

	private void cancelTacticalCombat(TacticalCombatClaim claim)
	{
		final PhantomCombatService combat = _tactics.combatOwner();
		if ((combat != null) && combat.matchesOwnedSession(claim.profileId(), claim.generation(), claim.targetObjectId(), claim.token()))
		{
			combat.cancel(claim.profileId());
		}
		if (!releaseTacticalCombat(claim) && (_state == State.RUNNING))
		{
			_tacticalReleases.offer(claim.profileId());
		}
	}

	private static String tacticalScope(PartyState state)
	{
		return "party.tactic." + PhantomPartyModel.sha256(state.groupId() + '|' + state.groupGeneration()) + '.';
	}

	/** Exact learned native support candidates for a bounded external request. */
	public List<org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.MemberCapability> supportCapabilities(long profileId, int exactTargetObjectId)
	{
		if ((profileId <= 0) || (exactTargetObjectId <= 0))
		{
			return List.of();
		}
		return _backend.currentMember(profileId).map(member -> _backend.capabilities(member, exactTargetObjectId)).orElse(List.of());
	}

	private void releaseTacticalAction(long profileId)
	{
		final TacticalCombatClaim combat = _tacticalCombat.get(profileId);
		if (combat != null)
		{
			if (!releaseTacticalCombat(combat))
			{
				_tacticalReleases.offer(profileId);
			}
			return;
		}
		final ExternalActionLease lease = _tacticalActions.get(profileId);
		if (lease == null)
		{
			return;
		}
		if (PhantomPartyTactics.releaseFinishedAction(lease, _clock.getAsLong()))
		{
			_tacticalActions.remove(profileId, lease);
		}
		else
		{
			_tacticalReleases.offer(profileId);
		}
	}

	private StoredPartyState sanitizeAfterRestart(StoredPartyState stored)
	{
		final PartyState state = stored.state();
		if (Set.of(StateStatus.SOLO, StateStatus.RETIRED, StateStatus.INCONSISTENT).contains(state.status()))
		{
			return stored;
		}
		if ((state.leader().kind() == MemberKind.REAL) || state.phantomMembers().isEmpty())
		{
			final MemberRef self = _backend.currentMember(stored.profileId()).orElse(MemberRef.phantom(stored.profileId(), 0));
			final PartyState solo = state(PhantomPartyModel.sha256("party.solo|" + stored.profileId() + '|' + (state.groupGeneration() + 1)), state.groupGeneration() + 1, state.membershipRevision() + 1, StateStatus.SOLO, self, List.of(self), List.of(), state.objectiveMode(), state.objectiveRef(), List.of(), List.of(), null, null, state.progressionHash(), "restart.real_consent_not_restored");
			return save(stored.profileId(), stored.rowVersion(), solo);
		}
		if (!Set.of(StateStatus.LEADER, StateStatus.MEMBER, StateStatus.RECOVERING).contains(state.status()) && ((state.operation() == null) || (state.operation().phase().ordinal() < OperationPhase.CANONICAL_OBSERVED.ordinal())))
		{
			if (restartPreparedMember(stored)) { return stored; }
			if (restartPreparedCore(stored))
			{
				final var pending = state.operation();
				final var recovery = new PartyOperation(PhantomPartyModel.sha256(pending.operationId() + "|restart.core"), OperationKind.RECOVER, OperationPhase.COMMITTED, state.leader(), null, pending.leaderGoalId(), pending.leaderGoalRevision(), state.leaderManifestHash(), 0, deadline(), "");
				// Only the previously committed local roster is recovered. The unjoined target
				// follows ordinary SOLO reconciliation; its independent clock remains durable.
				final var core = new PartyState(state.groupId(), state.groupGeneration(), state.membershipRevision(), StateStatus.RECOVERING, state.leader(), "", state.leaderManifestHash(), state.phantomMembers(), List.of(), state.objectiveMode(), state.objectiveRef(), state.requirements(), state.assignments(), null, recovery, state.progressionHash(), state.topologyHash(), "");
				return save(stored.profileId(), stored.rowVersion(), core);
			}
			final MemberRef self = _backend.currentMember(stored.profileId()).orElse(MemberRef.phantom(stored.profileId(), 0));
			final PartyState solo = state(PhantomPartyModel.sha256("party.solo|" + stored.profileId() + '|' + (state.groupGeneration() + 1)), state.groupGeneration() + 1, state.membershipRevision() + 1, StateStatus.SOLO, self, List.of(self), List.of(), state.objectiveMode(), state.objectiveRef(), List.of(), List.of(), null, null, state.progressionHash(), "restart.uncommitted_operation_aborted");
			return save(stored.profileId(), stored.rowVersion(), solo);
		}
		final String failure = state.command() == null ? "" : "restart.command_authority_invalidated";
		// An observed JOIN may retain different leader/invitee local rosters at STOP.
		// Their admitted shared manifest is authority; startup must not recompute it per row.
		// Mixed parties still discard real consent through the existing stripped-roster path.
		final PartyState recovered = state.realMembers().isEmpty()
			? new PartyState(state.groupId(), state.groupGeneration(), state.membershipRevision(), StateStatus.RECOVERING, state.leader(), "", state.leaderManifestHash(), state.phantomMembers(), List.of(), state.objectiveMode(), state.objectiveRef(), state.requirements(), state.assignments(), state.route(), state.operation(), state.progressionHash(), state.topologyHash(), failure)
			: state(state.groupId(), state.groupGeneration(), state.membershipRevision(), StateStatus.RECOVERING, state.leader(), state.phantomMembers(), List.of(), state.objectiveMode(), state.objectiveRef(), state.requirements(), state.assignments(), state.route(), state.operation(), state.progressionHash(), failure);
		return save(stored.profileId(), stored.rowVersion(), recovered);
	}

	private boolean restartPreparedCore(StoredPartyState stored)
	{
		final var state = stored.state(); final var operation = state.operation();
		if (state.leader().profileId() != stored.profileId() || operation == null || operation.kind() != OperationKind.JOIN || operation.phase() != OperationPhase.PREPARED || operation.invitationSequence() != 0 || operation.member() == null
			|| !state.realMembers().isEmpty() || state.phantomMembers().size() < 2 || state.phantomMembers().contains(operation.member()) || !state.leaderManifestHash().equals(state.canonicalManifestHash())) { return false; }
		final var root = _goals.load(stored.profileId()).map(StoredGoal::goal).orElse(null);
		if (root == null || !regroupLeaderRoot(state, root) || PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(state.objectiveRef().namespace()) && !PhantomAutonomousFarmParty.ordinaryIntent(stored.profileId(), root)) { return false; }
		return state.phantomMembers().stream().filter(member -> !member.equals(state.leader())).allMatch(member ->
		{
			final var peer = _store.load(member.profileId()).orElse(null);
			return committedClaim(peer) && peer.state().groupId().equals(state.groupId()) && peer.state().groupGeneration() == state.groupGeneration() && peer.state().leaderManifestHash().equals(state.leaderManifestHash()) && peer.state().leader().equals(state.leader()) && peer.state().phantomMembers().contains(member) && peer.state().realMembers().isEmpty();
		});
	}

	private boolean restartPreparedMember(StoredPartyState stored)
	{
		final var state = stored.state(); final var pending = state.operation();
		if (state.status() != StateStatus.INVITED_INBOUND || pending == null || pending.kind() != OperationKind.JOIN || pending.phase() != OperationPhase.PREPARED || pending.invitationSequence() != 0 || pending.member() == null || pending.member().profileId() != stored.profileId()
			|| state.leader().kind() != MemberKind.PHANTOM || !state.realMembers().isEmpty()) { return false; }
		final var leader = _store.load(state.leader().profileId()).orElse(null);
		if (leader == null || !leader.state().groupId().equals(state.groupId()) || leader.state().groupGeneration() != state.groupGeneration() || !leader.state().leaderManifestHash().equals(state.leaderManifestHash()) || !leader.state().realMembers().isEmpty() || leader.state().phantomMembers().contains(pending.member())) { return false; }
		final var recovery = leader.state().operation();
		final boolean core = pending.equals(recovery) && restartPreparedCore(leader) || leader.state().status() == StateStatus.RECOVERING && recovery != null && recovery.kind() == OperationKind.RECOVER && recovery.phase() == OperationPhase.COMMITTED && recovery.operationId().equals(PhantomPartyModel.sha256(pending.operationId() + "|restart.core"));
		final var root = _goals.load(stored.profileId()).map(StoredGoal::goal).orElse(null);
		return core && root != null && root.status() == PhantomGoalStatus.ACTIVE && (PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(state.objectiveRef().namespace())
			? PhantomAutonomousFarmParty.ordinaryIntent(stored.profileId(), root) : JOIN_GOAL.equals(root.goalType()) && goalTargets(root, state.leader().characterObjectId()));
	}

	private void rebuildGroups()
	{
		final Map<String, List<StoredPartyState>> grouped = new HashMap<>();
		for (StoredPartyState claim : _claims.values())
		{
			if (committedClaim(claim))
			{
				grouped.computeIfAbsent(claim.state().groupId(), ignored -> new ArrayList<>()).add(claim);
			}
		}
		for (Map.Entry<String, List<StoredPartyState>> entry : grouped.entrySet())
		{
			final Set<String> manifests = entry.getValue().stream().map(claim -> claim.state().leaderManifestHash()).collect(java.util.stream.Collectors.toSet());
			final Set<Long> generations = entry.getValue().stream().map(claim -> claim.state().groupGeneration()).collect(java.util.stream.Collectors.toSet());
			if ((manifests.size() != 1) || (generations.size() != 1))
			{
				for (StoredPartyState claim : entry.getValue())
				{
					markInconsistent(claim, "restart.claim_conflict");
				}
			}
			else
			{
				ensureGroup(entry.getKey());
				_metrics.recovery();
			}
		}
	}

	private void electLeader(List<StoredPartyState> claims, MemberRef elected)
	{
		final long generation = claims.stream().mapToLong(claim -> claim.state().groupGeneration()).max().orElse(0) + 1;
		for (StoredPartyState claim : claims)
		{
			final PartyState current = claim.state();
			final PartyState draft = state(current.groupId(), generation, current.membershipRevision() + 1, claim.profileId() == elected.profileId() ? StateStatus.LEADER : StateStatus.MEMBER, elected, current.phantomMembers(), List.of(), current.objectiveMode(), current.objectiveRef(), current.requirements(), current.assignments(), current.route(), current.operation(), current.progressionHash(), "");
			final PartyState next = new PartyState(draft.groupId(), draft.groupGeneration(), draft.membershipRevision(), draft.status(), draft.leader(), draft.ownRoleKey(), draft.canonicalManifestHash(), draft.phantomMembers(), draft.realMembers(), draft.objectiveMode(), draft.objectiveRef(), draft.requirements(), draft.assignments(), draft.route(), draft.operation(), draft.progressionHash(), draft.topologyHash(), "");
			try
			{
				putClaim(save(claim.profileId(), claim.rowVersion(), next));
			}
			catch (RuntimeException e)
			{
				markInconsistent(claim, "leader.election_conflict");
			}
		}
	}

	private void transitionGoal(long profileId, String nextType, PartyOperation operation)
	{
		if (operation == null)
		{
			return;
		}
		final Optional<StoredGoal> found = _goals.load(profileId);
		if (found.isEmpty())
		{
			return;
		}
		final PhantomGoal goal = found.get().goal();
		if (goal.status() != PhantomGoalStatus.ACTIVE)
		{
			return;
		}
		if (nextType.equals(LEAD_GOAL))
		{
			if ((goal.goalId() != operation.leaderGoalId()) || (goal.revision() != operation.leaderGoalRevision()) || !FORM_GOAL.equals(goal.goalType()))
			{
				return;
			}
		}
		else if (nextType.equals(MEMBER_GOAL))
		{
			if (!JOIN_GOAL.equals(goal.goalType()) || !goalTargets(goal, operation.leader().characterObjectId()))
			{
				return;
			}
		}
		else
		{
			return;
		}
		final PhantomGoal replacement = new PhantomGoal(goal.goalId(), nextType, PhantomGoalStatus.ACTIVE, goal.subject(), goal.target(), goal.requiredAmount(), goal.currentAmount(), goal.acquisitionMethod(), goal.validSources(), goal.selectedAnchor(), goal.purposeKey(), goal.priority(), goal.riskBudget(), goal.expenseBudget(), goal.deadlineEpochMillis(), goal.constraints(), "party.membership.committed", goal.revision() + 1);
		try
		{
			_goals.replace(profileId, found.get().rowVersion(), replacement);
		}
		catch (RuntimeException e)
		{
			_metrics.conflict();
		}
	}

	private void ensureCommittedGoals(List<StoredPartyState> claims)
	{
		for (StoredPartyState claim : claims)
		{
			final PartyState state = claim.state();
			if (state.status() == StateStatus.LEADER)
			{
				transitionGoal(claim.profileId(), LEAD_GOAL, state.operation());
			}
			else if (state.status() == StateStatus.MEMBER)
			{
				transitionGoal(claim.profileId(), MEMBER_GOAL, state.operation());
			}
		}
	}

	private void abortManagedInvitation(PartyInvitation invitation, OptionalLong managedRequester, OptionalLong managedInvitee, String reasonKey)
	{
		final OptionalLong leaderProfileId = managedRequester.isPresent() ? managedRequester : _backend.managedProfileId(invitation.requesterObjectId());
		if (leaderProfileId.isPresent())
		{
			final StoredPartyState leader = _claims.get(leaderProfileId.getAsLong());
			if ((leader != null) && sameInvitation(leader.state().operation(), invitation.identity()))
			{
				abortFormation(leader, invitation.identity(), reasonKey);
			}
		}
		if (managedInvitee.isEmpty())
		{
			return;
		}
		final StoredPartyState member = _claims.get(managedInvitee.getAsLong());
		if ((member != null) && Set.of(StateStatus.INVITED_INBOUND, StateStatus.JOINING).contains(member.state().status()) && sameInvitation(member.state().operation(), invitation.identity()))
		{
			moveToSolo(member, reasonKey);
		}
	}

	private void abortFormation(StoredPartyState stored, InvitationIdentity identity, String failure)
	{
		final StoredPartyState current = _claims.get(stored.profileId());
		if ((current == null) || (current.rowVersion() != stored.rowVersion()) || (current.state().status() != StateStatus.INVITED_OUTBOUND) || !sameInvitation(current.state().operation(), identity))
		{
			return;
		}
		final PartyState before = current.state();
		final PartyOperation aborted = before.operation().withPhase(OperationPhase.ABORTED, identity.sequence(), failure);
		final StoredGoal activeGoal = _goals.load(current.profileId()).orElse(null);
		if ((activeGoal != null) && regroupLeaderRoot(before, activeGoal.goal()) && !FORM_GOAL.equals(activeGoal.goal().goalType()))
		{
			try
			{
				putClaim(save(current.profileId(), current.rowVersion(), before.withOperation(StateStatus.LEADER, aborted, failure)));
			}
			catch (RuntimeException e)
			{
				_metrics.conflict();
			}
			return;
		}
		final MemberRef self = before.phantomMembers().stream().filter(member -> (member.kind() == MemberKind.PHANTOM) && (member.profileId() == current.profileId())).findFirst().orElseGet(() -> _backend.currentMember(current.profileId()).orElse(MemberRef.phantom(current.profileId(), 0)));
		final PartyState solo = state(PhantomPartyModel.sha256("party.solo|" + current.profileId() + '|' + (before.groupGeneration() + 1)), before.groupGeneration() + 1, before.membershipRevision() + 1, StateStatus.SOLO, self, List.of(self), List.of(), before.objectiveMode(), before.objectiveRef(), List.of(), List.of(), null, aborted, before.progressionHash(), failure);
		try
		{
			putClaim(save(current.profileId(), current.rowVersion(), solo));
			failFormGoal(current.profileId(), aborted, failure);
			removeGroup(before.groupId());
		}
		catch (RuntimeException e)
		{
			_metrics.conflict();
		}
	}

	private void failFormGoal(long profileId, PartyOperation operation, String failure)
	{
		final Optional<StoredGoal> found = _goals.load(profileId);
		if (found.isEmpty())
		{
			return;
		}
		final PhantomGoal goal = found.get().goal();
		if ((goal.status() != PhantomGoalStatus.ACTIVE) || (goal.goalId() != operation.leaderGoalId()) || (goal.revision() != operation.leaderGoalRevision()) || !FORM_GOAL.equals(goal.goalType()))
		{
			return;
		}
		final PhantomGoal failed = new PhantomGoal(goal.goalId(), goal.goalType(), PhantomGoalStatus.FAILED, goal.subject(), goal.target(), goal.requiredAmount(), goal.currentAmount(), goal.acquisitionMethod(), goal.validSources(), goal.selectedAnchor(), goal.purposeKey(), goal.priority(), goal.riskBudget(), goal.expenseBudget(), goal.deadlineEpochMillis(), goal.constraints(), failure, goal.revision() + 1);
		_goals.replace(profileId, found.get().rowVersion(), failed);
	}

	private void rollbackPreparedMember(MemberRef member, StoredPartyState previous, StoredPartyState prepared, String failure)
	{
		if ((member.kind() != MemberKind.PHANTOM) || (prepared == null))
		{
			return;
		}
		final StoredPartyState current = _claims.get(member.profileId());
		if ((current == null) || (current.rowVersion() != prepared.rowVersion()))
		{
			return;
		}
		if (previous == null)
		{
			moveToSolo(current, failure);
			return;
		}
		try
		{
			putClaim(save(member.profileId(), current.rowVersion(), previous.state()));
		}
		catch (RuntimeException e)
		{
			markInconsistent(current, "invite.member_rollback_conflict");
		}
	}

	private StoredPartyState moveToSolo(StoredPartyState stored, String failure)
	{
		final MemberRef self = stored.state().phantomMembers().stream().filter(member -> (member.kind() == MemberKind.PHANTOM) && (member.profileId() == stored.profileId())).findFirst().orElseGet(() -> _backend.currentMember(stored.profileId()).orElse(MemberRef.phantom(stored.profileId(), 0)));
		final PartyState current = stored.state();
		final PartyState solo = state(PhantomPartyModel.sha256("party.solo|" + stored.profileId() + '|' + (current.groupGeneration() + 1)), current.groupGeneration() + 1, current.membershipRevision() + 1, StateStatus.SOLO, self, List.of(self), List.of(), current.objectiveMode(), current.objectiveRef(), List.of(), List.of(), null, null, current.progressionHash(), failure);
		try
		{
			final var replacement = save(stored.profileId(), stored.rowVersion(), solo);
			putClaim(replacement);
			return replacement;
		}
		catch (RuntimeException e)
		{
			markInconsistent(stored, "invite.member_abort_conflict");
			return null;
		}
	}

	private static boolean sameInvitation(PartyOperation operation, InvitationIdentity identity)
	{
		return (operation != null) && (operation.invitationSequence() == identity.sequence()) && (operation.leader().characterObjectId() == identity.requesterObjectId()) && (operation.member() != null) && (operation.member().characterObjectId() == identity.inviteeObjectId());
	}

	private static boolean sameParticipants(PartyOperation operation, InvitationIdentity identity)
	{
		return (operation != null) && (operation.leader().characterObjectId() == identity.requesterObjectId()) && (operation.member() != null) && (operation.member().characterObjectId() == identity.inviteeObjectId());
	}

	private void abort(StoredPartyState stored, String failure)
	{
		final StoredPartyState current = _claims.get(stored.profileId());
		if ((current == null) || (current.rowVersion() != stored.rowVersion()))
		{
			return;
		}
		try
		{
			final PartyOperation operation = stored.state().operation();
			final PartyState aborted = stored.state().withOperation(StateStatus.FORMING, operation == null ? null : operation.withPhase(OperationPhase.ABORTED, operation.invitationSequence(), failure), failure);
			putClaim(save(stored.profileId(), stored.rowVersion(), aborted));
		}
		catch (RuntimeException e)
		{
			_metrics.conflict();
		}
	}

	private void markInconsistent(StoredPartyState stored, String failure)
	{
		try
		{
			putClaim(save(stored.profileId(), stored.rowVersion(), stored.state().withOperation(StateStatus.INCONSISTENT, stored.state().operation(), failure)));
		}
		catch (RuntimeException e)
		{
			_metrics.failure();
		}
	}

	private CommandOutcome membership(long profileId, long goalId, long goalRevision, long expectedGeneration, String goalType, OperationKind kind, MemberRef target)
	{
		return membership(profileId, goalId, goalRevision, expectedGeneration, goalType, kind, target, false);
	}

	private CommandOutcome membership(long profileId, long goalId, long goalRevision, long expectedGeneration, String goalType, OperationKind kind, MemberRef target, boolean farmRelease)
	{
		final OperationClaim control = beginOperation();
		if (control == null)
		{
			return CommandOutcome.NOT_RUNNING;
		}
		try (control)
		{
			final StoredPartyState retry = _claims.get(profileId);
			final PartyOperation retryOperation = retry == null ? null : retry.state().operation();
			if (!farmRelease && (retryOperation != null) && (retryOperation.kind() == kind) && (retryOperation.leaderGoalId() == goalId) && (retryOperation.leaderGoalRevision() == goalRevision) && (retryOperation.phase() == OperationPhase.COMMITTED) && exactCommandGoal(profileId, goalId, goalRevision, goalType, target))
			{
				return CommandOutcome.IDEMPOTENT;
			}
			// Releasing obsolete farm ownership never rewrites or executes the replacement root.
			final boolean quietFarm = farmRelease && kind == OperationKind.LEAVE && target == null && committedClaim(retry) && retry.state().groupGeneration() == expectedGeneration && retry.state().realMembers().isEmpty() && PhantomAutonomousFarmParty.OBJECTIVE_NAMESPACE.equals(retry.state().objectiveRef().namespace());
			final StoredPartyState claim = quietFarm ? retry : farmRelease ? null : exactCommandClaim(profileId, goalId, goalRevision, expectedGeneration, goalType, target);
			if (claim == null)
			{
				return commandMismatch(profileId, goalId, goalRevision, expectedGeneration, goalType, target);
			}
			final PartyState current = claim.state();
			if ((kind != OperationKind.LEAVE) && ((current.status() != StateStatus.LEADER) || (current.leader().profileId() != profileId)))
			{
				return CommandOutcome.NOT_LEADER;
			}
			final MemberRef actor = current.phantomMembers().stream().filter(member -> member.profileId() == profileId).findFirst().orElse(null);
			if (actor == null)
			{
				return CommandOutcome.TARGET_UNAVAILABLE;
			}
			final PartyOperation preparedOperation = operation(current, kind, target, goalId, goalRevision);
			final StoredPartyState prepared;
			try
			{
				prepared = save(profileId, claim.rowVersion(), current.withOperation(kind == OperationKind.LEAVE ? StateStatus.LEAVING : current.status(), preparedOperation, ""));
				putClaim(prepared);
			}
			catch (RuntimeException e)
			{
				return CommandOutcome.PERSISTENCE_CONFLICT;
			}
			final MembershipOutcome canonical = switch (kind)
			{
				case LEAVE -> _backend.leave(actor);
				case EXPEL -> _backend.expel(actor, target);
				case TRANSFER_LEADER -> _backend.transferLeader(actor, target);
				default -> MembershipOutcome.INVALID_TARGET;
			};
			final PartySnapshot observed = observeAfterMembership(current, actor, target).orElse(null);
			if ((canonical != MembershipOutcome.COMPLETED) && !membershipPostcondition(kind, actor, target, observed, canonical))
			{
				abort(prepared, "party.membership.canonical_rejected");
				return CommandOutcome.CANONICAL_REJECTED;
			}
			if (!membershipPostcondition(kind, actor, target, observed, canonical))
			{
				markInconsistent(prepared, "party.membership.postcondition_failed");
				return CommandOutcome.CANONICAL_REJECTED;
			}
			if (!commitMembership(current, observed, preparedOperation))
			{
				return CommandOutcome.PERSISTENCE_CONFLICT;
			}
			emitMembership(current, actor, target, preparedOperation);
			return canonical == MembershipOutcome.COMPLETED ? CommandOutcome.ACCEPTED : CommandOutcome.IDEMPOTENT;
		}
	}

	private StoredPartyState exactCommandClaim(long profileId, long goalId, long goalRevision, long expectedGeneration, String goalType, MemberRef target)
	{
		final StoredPartyState claim = _claims.get(profileId);
		if ((claim == null) || (claim.state().groupGeneration() != expectedGeneration) || !exactCommandGoal(profileId, goalId, goalRevision, goalType, target))
		{
			return null;
		}
		return claim;
	}

	private CommandOutcome commandMismatch(long profileId, long goalId, long goalRevision, long expectedGeneration, String goalType, MemberRef target)
	{
		final StoredPartyState claim = _claims.get(profileId);
		if ((claim != null) && (claim.state().groupGeneration() != expectedGeneration))
		{
			return CommandOutcome.STALE_GENERATION;
		}
		return exactCommandGoal(profileId, goalId, goalRevision, goalType, target) ? CommandOutcome.CLAIM_EXISTS : CommandOutcome.GOAL_MISMATCH;
	}

	private boolean exactCommandGoal(long profileId, long goalId, long goalRevision, String type, MemberRef target)
	{
		final Optional<StoredGoal> stored = _goals.load(profileId);
		if (stored.isEmpty())
		{
			return false;
		}
		final PhantomGoal goal = stored.get().goal();
		if ((goal.status() != PhantomGoalStatus.ACTIVE) || (goal.goalId() != goalId) || (goal.revision() != goalRevision) || !type.equals(goal.goalType()))
		{
			return false;
		}
		if (target == null)
		{
			return true;
		}
		final PhantomDomainRef goalTarget = goal.target();
		return (goalTarget != null) && (("profile".equals(goalTarget.namespace()) && (target.kind() == MemberKind.PHANTOM) && Long.toString(target.profileId()).equals(goalTarget.key())) || ("character.object".equals(goalTarget.namespace()) && Integer.toString(target.characterObjectId()).equals(goalTarget.key())));
	}

	private PartyOperation operation(PartyState state, OperationKind kind, MemberRef member, long goalId, long goalRevision)
	{
		return new PartyOperation(PhantomPartyModel.stableOperationId(state.groupId(), state.groupGeneration(), state.membershipRevision(), kind, state.leader(), member, goalId, goalRevision, state.leaderManifestHash()), kind, OperationPhase.PREPARED, state.leader(), member, goalId, goalRevision, state.leaderManifestHash(), 0, deadline(), "");
	}

	private Optional<PartySnapshot> observeAfterMembership(PartyState before, MemberRef actor, MemberRef target)
	{
		for (MemberRef member : before.phantomMembers())
		{
			if (!member.equals(actor) && !member.equals(target))
			{
				final Optional<PartySnapshot> observed = _backend.observe(member);
				if (observed.isPresent())
				{
					return observed;
				}
			}
		}
		for (MemberRef member : before.realMembers())
		{
			if (!member.equals(target))
			{
				final Optional<PartySnapshot> observed = _backend.observe(member);
				if (observed.isPresent())
				{
					return observed;
				}
			}
		}
		return _backend.observe(actor);
	}

	private static boolean membershipPostcondition(OperationKind kind, MemberRef actor, MemberRef target, PartySnapshot observed, MembershipOutcome canonical)
	{
		return switch (kind)
		{
			case LEAVE -> (observed == null) || !observed.members().contains(actor);
			case EXPEL -> ((observed == null) && (canonical == MembershipOutcome.COMPLETED)) || ((observed != null) && !observed.members().contains(target));
			case TRANSFER_LEADER -> (observed != null) && observed.leader().equals(target);
			default -> false;
		};
	}

	private boolean commitMembership(PartyState before, PartySnapshot observed, PartyOperation prepared)
	{
		final List<StoredPartyState> previous = claims(before.groupId());
		final Set<Long> remainingProfiles = observed == null ? Set.of() : observed.members().stream().filter(member -> member.kind() == MemberKind.PHANTOM).map(MemberRef::profileId).collect(java.util.stream.Collectors.toSet());
		for (StoredPartyState claim : previous)
		{
			if (!remainingProfiles.contains(claim.profileId()))
			{
				moveToSolo(claim, "");
			}
		}
		if (observed == null)
		{
			removeGroup(before.groupId());
			return true;
		}
		final List<StoredPartyState> remaining = claims(before.groupId());
		if (remaining.isEmpty())
		{
			removeGroup(before.groupId());
			return true;
		}
		final long generation = observed.leader().equals(before.leader()) && sameRoster(roster(before), observed.members()) ? before.groupGeneration() : Math.addExact(before.groupGeneration(), 1);
		final List<MemberRef> phantoms = observed.members().stream().filter(member -> member.kind() == MemberKind.PHANTOM).sorted(Comparator.comparing(MemberRef::stableKey)).toList();
		final List<MemberRef> reals = observed.members().stream().filter(member -> member.kind() == MemberKind.REAL).sorted(Comparator.comparing(MemberRef::stableKey)).toList();
		final Map<MemberRef, MemberSnapshot> snapshots = snapshots(observed.members());
		final RoleMatchResult roles = _roles.match(before.objectiveMode(), before.requirements(), new ArrayList<>(snapshots.values()));
		final PartyOperation committed = prepared.withPhase(OperationPhase.COMMITTED, 0, "");
		final PartyState authority = state(before.groupId(), generation, before.membershipRevision() + 1, StateStatus.MEMBER, observed.leader(), phantoms, reals, before.objectiveMode(), before.objectiveRef(), before.requirements(), roles.assignments(), null, committed, progressionEvidence(snapshots), "");
		final String manifest = authority.canonicalManifestHash();
		for (MemberRef member : phantoms)
		{
			final StoredPartyState current = _claims.get(member.profileId());
			if (current == null)
			{
				continue;
			}
			final StateStatus status = member.equals(observed.leader()) ? StateStatus.LEADER : StateStatus.MEMBER;
			final String ownRole = roles.assignments().stream().filter(assignment -> assignment.member().equals(member)).map(RoleAssignment::roleKey).findFirst().orElse("");
			final PartyOperation own = current.state().operation();
			final PartyOperation memberOperation = (committed.kind() == OperationKind.RECOVER) && committedClaim(current) && (own != null) ? new PartyOperation(committed.operationId(), committed.kind(), committed.phase(), committed.leader(), committed.member(), own.leaderGoalId(), own.leaderGoalRevision(), committed.manifestHash(), committed.invitationSequence(), committed.deadlineLogicalNanos(), committed.failureKey()) : committed;
			final PartyState next = new PartyState(before.groupId(), generation, authority.membershipRevision(), status, observed.leader(), ownRole, manifest, phantoms, reals, before.objectiveMode(), before.objectiveRef(), before.requirements(), roles.assignments(), null, memberOperation, authority.progressionHash(), authority.topologyHash(), "");
			try
			{
				putClaim(save(member.profileId(), current.rowVersion(), next));
			}
			catch (RuntimeException e)
			{
				markInconsistent(current, "party.membership.commit_conflict");
				return false;
			}
		}
		_routes.cancel(before.groupId(), before.groupGeneration());
		ensureGroup(before.groupId());
		return true;
	}

	private MemberRef resolveMember(PhantomDomainRef target)
	{
		if (target == null)
		{
			return null;
		}
		try
		{
			if ("profile".equals(target.namespace()))
			{
				return _backend.currentMember(Long.parseLong(target.key())).orElse(null);
			}
			if ("character.object".equals(target.namespace()))
			{
				final int objectId = Integer.parseInt(target.key());
				final OptionalLong managed = _backend.managedProfileId(objectId);
				return managed.isPresent() ? MemberRef.phantom(managed.getAsLong(), objectId) : MemberRef.real(objectId);
			}
		}
		catch (NumberFormatException e)
		{
			return null;
		}
		return null;
	}

	private boolean exactGoal(long profileId, long goalId, long goalRevision, String type, Integer targetObjectId)
	{
		final Optional<StoredGoal> stored = _goals.load(profileId);
		return stored.isPresent() && (stored.get().goal().status() == PhantomGoalStatus.ACTIVE) && (stored.get().goal().goalId() == goalId) && (stored.get().goal().revision() == goalRevision) && type.equals(stored.get().goal().goalType()) && ((targetObjectId == null) || goalTargets(stored.get().goal(), targetObjectId));
	}

	private static boolean goalTargets(PhantomGoal goal, int requesterObjectId)
	{
		final PhantomDomainRef target = goal.target();
		if (target == null)
		{
			return false;
		}
		return ("character.object".equals(target.namespace()) && Integer.toString(requesterObjectId).equals(target.key())) || ("profile".equals(target.namespace()) && goal.validSources().stream().anyMatch(source -> "character.object".equals(source.namespace()) && Integer.toString(requesterObjectId).equals(source.key())));
	}

	private void emitInvitationTerminal(TerminalEvent terminal)
	{
		final String outbound;
		final String inbound;
		switch (terminal.outcome())
		{
			case ACCEPTED:
				outbound = "party.invite.accepted.outbound";
				inbound = "party.invite.accepted.inbound";
				break;
			case REFUSED:
				outbound = "party.invite.refused.outbound";
				inbound = "party.invite.refused.inbound";
				break;
			case EXPIRED:
				outbound = "party.invite.expired.outbound";
				inbound = "party.invite.expired.inbound";
				break;
			default:
				return;
		}
		final PartyInvitation invitation = terminal.invitation();
		final String source = "invitation|" + INVITATION_SESSION + '|' + invitation.identity().sequence() + '|' + invitation.identity().requesterObjectId() + '|' + invitation.identity().inviteeObjectId();
		if (terminal.managedRequester().isPresent())
		{
			emitSocial(terminal.managedRequester().getAsLong(), outbound, subject(terminal.managedInvitee(), invitation.identity().inviteeObjectId()), source, "outbound");
		}
		if (terminal.managedInvitee().isPresent())
		{
			emitSocial(terminal.managedInvitee().getAsLong(), inbound, subject(terminal.managedRequester(), invitation.identity().requesterObjectId()), source, "inbound");
		}
	}

	private void emitJoined(List<MemberRef> managedMembers, PartyOperation observed, PartyOperation committed)
	{
		if (!isExactFirstJoinTransition(observed, committed))
		{
			return;
		}
		for (MemberRef owner : managedMembers)
		{
			if (owner.kind() != MemberKind.PHANTOM)
			{
				continue;
			}
			final MemberRef counterpart = owner.equals(committed.member()) ? committed.leader() : committed.member();
			if (!owner.equals(counterpart))
			{
				emitSocial(owner.profileId(), "party.member.joined", subject(counterpart), committed.operationId(), "membership");
			}
		}
	}

	private static boolean isExactFirstJoinTransition(PartyOperation observed, PartyOperation committed)
	{
		return (observed != null) && (committed != null) //
			&& (observed.kind() == OperationKind.JOIN) && (observed.phase() == OperationPhase.CANONICAL_OBSERVED) //
			&& (committed.kind() == OperationKind.JOIN) && (committed.phase() == OperationPhase.COMMITTED) //
			&& observed.operationId().equals(committed.operationId()) //
			&& (observed.invitationSequence() == committed.invitationSequence()) //
			&& observed.leader().equals(committed.leader()) && observed.member().equals(committed.member());
	}

	private void emitMembership(PartyState before, MemberRef actor, MemberRef target, PartyOperation operation)
	{
		final String eventKey = switch (operation.kind())
		{
			case LEAVE -> "party.member.left";
			case EXPEL -> "party.member.expelled";
			case TRANSFER_LEADER -> "party.leader.transferred";
			default -> null;
		};
		if (eventKey == null)
		{
			return;
		}
		for (MemberRef owner : before.phantomMembers())
		{
			final MemberRef counterpart;
			if (operation.kind() == OperationKind.LEAVE)
			{
				counterpart = owner.equals(actor) ? leaveCounterpart(before, actor) : actor;
			}
			else
			{
				counterpart = owner.equals(target) ? actor : target;
			}
			if ((counterpart != null) && !owner.equals(counterpart))
			{
				emitSocial(owner.profileId(), eventKey, subject(counterpart), operation.operationId(), "membership");
			}
		}
	}

	private static MemberRef leaveCounterpart(PartyState before, MemberRef actor)
	{
		if (!before.leader().equals(actor))
		{
			return before.leader();
		}
		return java.util.stream.Stream.concat(before.phantomMembers().stream(), before.realMembers().stream()).filter(member -> !member.equals(actor)).findFirst().orElse(null);
	}

	private void emitSocial(long ownerProfileId, String eventKey, SubjectRef subject, String sourceIdentity, String perspective)
	{
		final String eventId = PhantomSocialModel.sha256("social.event|party|" + sourceIdentity + '|' + ownerProfileId + '|' + eventKey + '|' + subject.stableKey() + '|' + perspective);
		final String evidence = PhantomSocialModel.sha256("party.evidence|" + sourceIdentity);
		try
		{
			final PhantomSocialEventSink.Result result = _socialEvents.record(new SocialEvent(ownerProfileId, eventId, eventKey, subject, Math.max(0, _socialClock.getAsLong()), 1000, evidence, _affiliationContexts.resolve(ownerProfileId, subject)));
			if (result.status() == PhantomSocialEventSink.Status.RECORDED)
			{
				_socialEventsRecorded.incrementAndGet();
			}
			else if ((result.status() != PhantomSocialEventSink.Status.IDEMPOTENT) && (result.status() != PhantomSocialEventSink.Status.DISABLED))
			{
				_socialEventFailures.incrementAndGet();
			}
		}
		catch (RuntimeException e)
		{
			_socialEventFailures.incrementAndGet();
		}
	}

	private static SubjectRef subject(OptionalLong managedProfileId, int characterObjectId)
	{
		return managedProfileId.isPresent() ? SubjectRef.phantom(managedProfileId.getAsLong()) : SubjectRef.character(characterObjectId);
	}

	private static SubjectRef subject(MemberRef member)
	{
		return member.kind() == MemberKind.PHANTOM ? SubjectRef.phantom(member.profileId()) : SubjectRef.character(member.characterObjectId());
	}

	private String groupForLeader(long leaderProfileId)
	{
		final StoredPartyState claim = _claims.get(leaderProfileId);
		return claim == null ? PhantomPartyModel.sha256("party.unclaimed|" + leaderProfileId) : claim.state().groupId();
	}

	private List<StoredPartyState> claims(String groupId)
	{
		synchronized (_indexLock)
		{
			final NavigableMap<Long, StoredPartyState> indexed = _claimsByGroup.get(groupId);
			return indexed == null ? List.of() : List.copyOf(indexed.values());
		}
	}

	private int claimCount(String groupId)
	{
		synchronized (_indexLock)
		{
			final NavigableMap<Long, StoredPartyState> indexed = _claimsByGroup.get(groupId);
			return indexed == null ? 0 : indexed.size();
		}
	}

	private void putClaim(StoredPartyState replacement)
	{
		final StoredPartyState previous = _claims.put(replacement.profileId(), replacement);
		synchronized (_indexLock)
		{
			if (previous != null)
			{
				final NavigableMap<Long, StoredPartyState> old = _claimsByGroup.get(previous.state().groupId());
				if (old != null)
				{
					old.remove(previous.profileId());
					if (old.isEmpty())
					{
						_claimsByGroup.remove(previous.state().groupId());
					}
				}
			}
			_claimsByGroup.computeIfAbsent(replacement.state().groupId(), ignored -> new TreeMap<>()).put(replacement.profileId(), replacement);
		}
		if (committedClaim(replacement) || !Set.of(StateStatus.SOLO, StateStatus.RETIRED, StateStatus.INCONSISTENT).contains(replacement.state().status()))
		{
			ensureGroup(replacement.state().groupId());
		}
	}

	private void ensureGroup(String groupId)
	{
		_groups.computeIfAbsent(groupId, GroupRuntime::new);
		scheduleGroup(groupId);
	}

	private void scheduleGroup(String groupId)
	{
		synchronized (_indexLock)
		{
			if (_dueGroupSet.add(groupId))
			{
				if (_dueGroups.size() >= MAX_DUE_GROUPS)
				{
					final String dropped = _dueGroups.removeFirst();
					_dueGroupSet.remove(dropped);
				}
				_dueGroups.addLast(groupId);
			}
		}
	}

	private GroupRuntime pollDueGroup()
	{
		synchronized (_indexLock)
		{
			final String groupId = _dueGroups.pollFirst();
			if (groupId == null)
			{
				return null;
			}
			_dueGroupSet.remove(groupId);
			return _groups.get(groupId);
		}
	}

	private void removeGroup(String groupId)
	{
		_groups.remove(groupId);
		_routes.cancel(groupId);
		synchronized (_indexLock)
		{
			_dueGroupSet.remove(groupId);
			_dueGroups.remove(groupId);
		}
	}

	private OperationClaim beginOperation()
	{
		synchronized (_lifecycleLock)
		{
			if (_state != State.RUNNING)
			{
				return null;
			}
			_operationClaims.incrementAndGet();
			return new OperationClaim();
		}
	}

	private OperationClaim beginTerminalOperation()
	{
		synchronized (_lifecycleLock)
		{
			if ((_state != State.RUNNING) && (_state != State.STOPPING))
			{
				return null;
			}
			_operationClaims.incrementAndGet();
			return new OperationClaim();
		}
	}

	private Map<MemberRef, MemberSnapshot> snapshots(List<MemberRef> roster)
	{
		final Map<MemberRef, MemberSnapshot> result = new LinkedHashMap<>();
		for (MemberRef member : roster)
		{
			_backend.memberSnapshot(member).ifPresent(snapshot -> result.put(member, snapshot));
		}
		return result;
	}

	private PartyState state(String groupId, long generation, long revision, StateStatus status, MemberRef leader, List<MemberRef> phantoms, List<MemberRef> reals, ObjectiveMode objective, PhantomDomainRef objectiveRef, List<RoleRequirement> requirements, List<RoleAssignment> assignments, org.l2jmobius.gameserver.phantoms.party.model.PhantomPartyModel.RouteManifest route, PartyOperation operation, String progressionHash, String failure)
	{
		final PartyState draft = new PartyState(groupId, generation, revision, status, leader, "", ZERO_HASH, phantoms, reals, objective, objectiveRef, requirements, assignments, route, operation, progressionHash, _topologyHash.get(), failure);
		return new PartyState(draft.groupId(), draft.groupGeneration(), draft.membershipRevision(), draft.status(), draft.leader(), draft.ownRoleKey(), draft.canonicalManifestHash(), draft.phantomMembers(), draft.realMembers(), draft.objectiveMode(), draft.objectiveRef(), draft.requirements(), draft.assignments(), draft.route(), draft.operation(), draft.progressionHash(), draft.topologyHash(), draft.lastFailureKey());
	}

	private String progressionHash(MemberRef member)
	{
		return _backend.memberSnapshot(member).map(MemberSnapshot::progressionHash).orElse(ZERO_HASH);
	}

	private static String progressionEvidence(Map<MemberRef, MemberSnapshot> snapshots)
	{
		return PhantomPartyModel.sha256(snapshots.values().stream().sorted(Comparator.comparing(snapshot -> snapshot.ref().stableKey())).map(snapshot -> snapshot.ref().stableKey() + ':' + snapshot.progressionHash()).reduce("", (left, right) -> left + '|' + right));
	}

	private long deadline()
	{
		return Math.addExact(Math.max(1, _clock.getAsLong()), java.util.concurrent.TimeUnit.SECONDS.toNanos(30));
	}

	private List<StoredPartyState> readPage(long cursor)
	{
		_persistenceClaims.incrementAndGet();
		try
		{
			return _store.loadManagedAfter(cursor, PAGE_SIZE);
		}
		finally
		{
			_persistenceClaims.decrementAndGet();
		}
	}

	private StoredPartyState save(long profileId, long expectedRowVersion, PartyState state)
	{
		_persistenceClaims.incrementAndGet();
		try
		{
			return _store.save(profileId, expectedRowVersion, state);
		}
		finally
		{
			_persistenceClaims.decrementAndGet();
		}
	}

	private static boolean committedClaim(StoredPartyState claim)
	{
		return (claim != null) && Set.of(StateStatus.LEADER, StateStatus.MEMBER, StateStatus.RECOVERING).contains(claim.state().status());
	}

	private record TacticalCombatClaim(long profileId, long generation, int targetObjectId, String operationKey, PhantomCancellationToken token)
	{
	}

	public record Snapshot(State state, int partyClaims, int groups, int terminalEvents, int inboundInvites, int operationClaims, int persistenceClaims, int navigationClaims, int routeActions, int tacticalActions, int operationBudget, int lastPulseExamined, int maximumPulseExamined, long socialEventsRecorded, long socialEventFailures, PhantomPartyMetrics.Snapshot metrics)
	{
		public static Snapshot inactive()
		{
			return new Snapshot(State.STOPPED, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, new PhantomPartyMetrics().snapshot());
		}
	}

	private record ManagedInvitation(PartyInvitation invitation, long profileId)
	{
	}

	private record TerminalEvent(PartyInvitation invitation, OptionalLong managedRequester, OptionalLong managedInvitee, TerminalOutcome outcome, String reasonKey)
	{
		private TerminalEvent
		{
			Objects.requireNonNull(invitation);
			Objects.requireNonNull(managedRequester);
			Objects.requireNonNull(managedInvitee);
			Objects.requireNonNull(outcome);
			Objects.requireNonNull(reasonKey);
		}
	}

	/** Source identity excludes mutable HP/MP/readiness-dependent tactical assignment scores. */
	private record FarmSourceKey(long groupGeneration, MemberRef leader, PhantomDomainRef objective, long goalId, long goalRevision) { }
	private record FarmSourceView(FarmSourceKey key, long sampledNanos, long expiresNanos, Map<Long, Long> rowVersions, boolean valid) { }

	private static final class GroupRuntime
	{
		private final String _groupId;
		private volatile FarmSourceView farmSource;
		private final Map<Long, Long> regroupDue = new HashMap<>();
		private GroupRuntime(String groupId) { _groupId = groupId; }
		private String groupId() { return _groupId; }
	}

	private final class OperationClaim implements AutoCloseable
	{
		private final AtomicBoolean _closed = new AtomicBoolean();

		@Override
		public void close()
		{
			if (_closed.compareAndSet(false, true))
			{
				_operationClaims.decrementAndGet();
			}
		}
	}
}
