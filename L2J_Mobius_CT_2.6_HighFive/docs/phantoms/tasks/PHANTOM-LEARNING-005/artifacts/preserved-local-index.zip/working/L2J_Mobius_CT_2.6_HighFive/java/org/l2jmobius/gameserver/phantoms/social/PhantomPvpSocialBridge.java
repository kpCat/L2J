/*
 * Copyright (c) 2013 L2jMobius
 */
package org.l2jmobius.gameserver.phantoms.social;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.l2jmobius.gameserver.phantoms.social.PhantomSocialEventSink.Status;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialModel.MemorySnapshot;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialModel.SocialEvent;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialModel.SocialSnapshot;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialModel.SubjectRef;
import org.l2jmobius.gameserver.phantoms.social.PhantomSocialService.QueryResult;

/**
 * Goal018-owned adapter for typed PvP social events and exact revenge evidence.
 * It supplies bounded remembered causes; native identity resolution and combat
 * admission remain with their existing owners.
 */
public final class PhantomPvpSocialBridge
{
	public enum EventKind
	{
		ATTACK_RECEIVED("pvp.attack.received"),
		KILL_CAUSED("pvp.kill.caused"),
		DEATH_SUFFERED("pvp.death.suffered"),
		HELP_RECEIVED("pvp.help.received");

		private final String _eventKey;

		EventKind(String eventKey)
		{
			_eventKey = eventKey;
		}

		public String eventKey()
		{
			return _eventKey;
		}
	}

	public record Delivery(boolean durable, Status status, String eventId)
	{
		public Delivery
		{
			Objects.requireNonNull(status);
			eventId = Objects.requireNonNull(eventId);
		}
	}

	public record RevengeEvidence(SubjectRef subject, String eventId, String eventKey, String authorityHash, long expiryMinute)
	{
		public RevengeEvidence
		{
			Objects.requireNonNull(subject);
			eventId = Objects.requireNonNull(eventId);
			eventKey = Objects.requireNonNull(eventKey);
			authorityHash = Objects.requireNonNull(authorityHash);
			if (expiryMinute < 0)
			{
				throw new IllegalArgumentException("Invalid PvP revenge expiry.");
			}
		}
	}

	private static final Set<String> REVENGE_EVENTS = Set.of(EventKind.ATTACK_RECEIVED.eventKey(), EventKind.DEATH_SUFFERED.eventKey());
	private final PhantomSocialService _social;
	private final PhantomSocialAffiliationContextPort _affiliationContexts;
	private final java.util.function.Consumer<SocialEvent> _contentEvents;
	private final java.util.concurrent.atomic.LongAdder _contentCallbackFailures = new java.util.concurrent.atomic.LongAdder();

	public PhantomPvpSocialBridge(PhantomSocialService social)
	{
		this(social, PhantomSocialAffiliationContextPort.noop());
	}

	public PhantomPvpSocialBridge(PhantomSocialService social, PhantomSocialAffiliationContextPort affiliationContexts)
	{
		this(social, affiliationContexts, event -> { });
	}

	public PhantomPvpSocialBridge(PhantomSocialService social, PhantomSocialAffiliationContextPort affiliationContexts, java.util.function.Consumer<SocialEvent> contentEvents)
	{
		_social = Objects.requireNonNull(social);
		_affiliationContexts = Objects.requireNonNull(affiliationContexts);
		_contentEvents = Objects.requireNonNull(contentEvents);
	}

	public Delivery record(long ownerProfileId, SubjectRef subject, EventKind kind, String operationId, String evidenceHash, long minute, int magnitude)
	{
		Objects.requireNonNull(subject);
		Objects.requireNonNull(kind);
		operationId = Objects.requireNonNull(operationId);
		evidenceHash = Objects.requireNonNull(evidenceHash);
		if ((ownerProfileId <= 0) || operationId.isBlank() || (operationId.length() > 128) || (minute < 0) || (magnitude < 1) || (magnitude > PhantomSocialModel.MAX_VALUE))
		{
			throw new IllegalArgumentException("Invalid typed PvP social event.");
		}
		final String eventId = PhantomSocialModel.sha256("pvp.social|" + kind.name() + '|' + ownerProfileId + '|' + subject.stableKey() + '|' + operationId);
		final SocialEvent event = new SocialEvent(ownerProfileId, eventId, kind.eventKey(), subject, minute, magnitude, evidenceHash, _affiliationContexts.resolve(ownerProfileId, subject));
		final PhantomSocialEventSink.Result result = _social.record(event);
		if (result.status() == Status.RECORDED)
		{
			try { _contentEvents.accept(event); }
			catch (RuntimeException contentFailure) { _contentCallbackFailures.increment(); }
		}
		return new Delivery(result.durable(), result.status(), eventId);
	}

	public long contentCallbackFailures() { return _contentCallbackFailures.sum(); }

<<<<<<< Updated upstream
	/** Bounded own-memory evidence; no identity resolution or aggression admission. */
	public List<RevengeEvidence> revengeSources(long ownerProfileId, long minute)
	{
		if ((ownerProfileId <= 0) || (minute < 0)) { return List.of(); }
		final var memories = _social.recentMemories(ownerProfileId, PhantomSocialModel.MAX_MEMORIES, minute);
		if (!memories.available()) { return List.of(); }
		return memories.value().stream()
			.filter(memory -> REVENGE_EVENTS.contains(memory.eventKey()) && (memory.expiryMinute() > minute))
			.map(MemorySnapshot::subject).distinct().limit(4)
			.map(subject -> revenge(ownerProfileId, subject, minute)).flatMap(Optional::stream).toList();
=======
	public List<RevengeEvidence> revengeCandidates(long ownerProfileId, int limit, long minute)
	{
		if (ownerProfileId <= 0 || limit < 1 || limit > 10 || minute < 0) { return List.of(); }
		final var memories = _social.recentMemories(ownerProfileId, PhantomSocialModel.MAX_MEMORIES, minute);
		if (!memories.available()) { return List.of(); }
		return memories.value().stream().filter(memory -> REVENGE_EVENTS.contains(memory.eventKey()) && memory.expiryMinute() > minute)
			.map(MemorySnapshot::subject).distinct().limit(limit).map(subject -> revenge(ownerProfileId, subject, minute)).flatMap(Optional::stream).toList();
>>>>>>> Stashed changes
	}

	public Optional<RevengeEvidence> revenge(long ownerProfileId, SubjectRef exactSubject, long minute)
	{
		if ((ownerProfileId <= 0) || (exactSubject == null) || (minute < 0))
		{
			return Optional.empty();
		}
		final QueryResult<SocialSnapshot> result = _social.snapshot(ownerProfileId, exactSubject, 8, minute);
		if (!result.available())
		{
			return Optional.empty();
		}
		final MemorySnapshot memory = result.value().memories().stream().filter(item -> REVENGE_EVENTS.contains(item.eventKey()) && item.subject().equals(exactSubject) && (item.expiryMinute() > minute)).max(Comparator.comparingLong(MemorySnapshot::happenedMinute).thenComparing(MemorySnapshot::eventId)).orElse(null);
		if (memory == null)
		{
			return Optional.empty();
		}
		final String authority = PhantomSocialModel.sha256("pvp.revenge|" + result.value().authorityHash() + '|' + memory.eventId() + '|' + memory.evidenceHash() + '|' + memory.expiryMinute());
		return Optional.of(new RevengeEvidence(exactSubject, memory.eventId(), memory.eventKey(), authority, memory.expiryMinute()));
	}

	/** Read-only, infrequent admission inside an actual farm dispute or a remembered personal attack. */
	public boolean allowsProactiveDispute(long profileId, SubjectRef subject, long minute, boolean farmingDispute)
	{
		if (profileId <= 0 || subject == null || minute < 0) { return false; }
		final var result = _social.snapshot(profileId, subject, PhantomSocialModel.MAX_MEMORIES, minute);
		if (!result.available()) { return false; }
		final var snapshot = result.value();
		if (snapshot.memories().stream().anyMatch(memory -> memory.subject().equals(subject) && memory.eventKey().equals(EventKind.KILL_CAUSED.eventKey()) && memory.expiryMinute() > minute)) { return false; }
		final var traits = snapshot.personality().traits();
		final var relationship = snapshot.relationship().relationship();
		final boolean rememberedAttack = snapshot.memories().stream().anyMatch(memory -> memory.subject().equals(subject) && REVENGE_EVENTS.contains(memory.eventKey()) && memory.expiryMinute() > minute);
		if (!farmingDispute && !rememberedAttack) { return false; }
		final int assertiveness = traits.getOrDefault("assertiveness", 0);
		final int caution = traits.getOrDefault("caution", 0);
		final int friendship = relationship.getOrDefault("friendship", 0);
		// Exact farming escalation is already causal; its native magnitude need not create anger first.
		if (assertiveness < 5500 || caution > 6500 || friendship > 1000) { return false; }
		// A stable half-hour window cannot be rerolled by hot ticks, target switches or restart.
		final String roll = PhantomSocialModel.sha256("pvp.rare-dispute|" + snapshot.personality().seed() + '|' + profileId + '|' + subject.stableKey() + '|' + minute / 30);
		return Long.parseUnsignedLong(roll.substring(0, 8), 16) % 10000 < Math.min(300, Math.max(25, (assertiveness - caution) / 20));
	}
}
