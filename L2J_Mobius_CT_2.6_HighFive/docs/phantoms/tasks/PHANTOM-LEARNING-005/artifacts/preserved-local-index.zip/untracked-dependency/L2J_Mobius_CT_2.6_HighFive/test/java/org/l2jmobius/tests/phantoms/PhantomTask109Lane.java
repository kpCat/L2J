/* Copyright (c) 2013 L2jMobius */
package org.l2jmobius.tests.phantoms;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.AclEntryType;
import java.nio.file.attribute.AclFileAttributeView;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.Instant;
import java.util.HexFormat;
import java.util.Properties;
import java.util.UUID;
import java.util.regex.Pattern;

/** Create-only, infrastructure-only TEST109 authority. Historical TEST lanes remain read-only. */
public final class PhantomTask109Lane
{
	static final String SCHEMA = selectedSchema(System.getProperty("phantom.task109.schema", "l2jmobiush5_phantom_test_109b"));
	private static final String BASELINE = "a1b30f7b84a9c06e1141a0cae7a2e48dd922bf24";
	private static final String PACKAGE_SHA = "4f2f1260a47500b15e12c6cf9e537392675a430f1cfc1929e6e0f082df7dd5e5";
	private static final String ADMIN_URL = "jdbc:mysql://127.0.0.1:3308/?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8";
	private static final String TARGET_URL = ADMIN_URL.replace("3308/", "3308/" + SCHEMA);
	private static final Pattern ABSENT_DROP = Pattern.compile("(?is)\\s*DROP\\s+TABLE\\s+IF\\s+EXISTS\\s+`?([A-Za-z0-9_]+)`?\\s*");
	private static String phase = "PREFLIGHT";
	private PhantomTask109Lane() { }
	private static void require(boolean condition, String reason)
	{
		if (!condition) { throw new IllegalArgumentException("TASK109_" + reason); }
	}
	static String selectedSchema(String schema)
	{
		require(java.util.Set.of("l2jmobiush5_phantom_test_109b", "l2jmobiush5_phantom_test_109c", "l2jmobiush5_phantom_test_109d", "l2jmobiush5_phantom_test_109e", "l2jmobiush5_phantom_test_109f", "l2jmobiush5_phantom_test_109g", "l2jmobiush5_phantom_test_109h", "l2jmobiush5_phantom_test_109i", "l2jmobiush5_phantom_test_109j", "l2jmobiush5_phantom_test_109m", "l2jmobiush5_phantom_test_109n", "l2jmobiush5_phantom_test_109o", "l2jmobiush5_phantom_test_109p").contains(schema), "FRESH_SCHEMA_ALLOWLIST");
		return schema;
	}
	static void requireBinding(String selected, String callerUuid, String ownerSchema, String ownerUuid)
	{
		require(selectedSchema(selected).equals(ownerSchema) && callerUuid != null && callerUuid.equals(ownerUuid), "OWNER_SCHEMA_UUID_BINDING");
	}
	private static Path physical(Path path) throws Exception
	{
		final Path value = path.toAbsolutePath().normalize();
		require(value.equals(path.toAbsolutePath()) && value.equals(path.toRealPath()), "PHYSICAL_PATH");
		for (Path parent = value; parent != null; parent = parent.getParent())
		{
			require(!Files.isSymbolicLink(parent) && !Files.readAttributes(parent, java.nio.file.attribute.BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS).isOther(), "REPARSE_PATH");
		}
		return value;
	}
	private static String hash(Path path) throws Exception
	{
		final var digest = MessageDigest.getInstance("SHA-256");
		try (var input = Files.newInputStream(physical(path)))
		{
			final byte[] buffer = new byte[65536];
			for (int count; (count = input.read(buffer)) >= 0;) { digest.update(buffer, 0, count); }
		}
		return HexFormat.of().formatHex(digest.digest());
	}
	private static Properties read(Path path) throws Exception
	{
		require(Files.size(physical(path)) <= 16384, "BOUNDED_PROPERTIES");
		final var result = new Properties();
		try (var reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) { result.load(reader); }
		return result;
	}
	private static void write(Path path, Properties value) throws Exception
	{
		try (var writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW)) { value.store(writer, "TASK109 private authority"); }
	}
	private static void privateAcl(Path stage, Path path) throws Exception
	{
		final var lookup = path.getFileSystem().getUserPrincipalLookupService();
		final var owner = Files.getOwner(physical(stage));
		require(owner.equals(lookup.lookupPrincipalByName(System.getProperty("user.name"))) && Files.getOwner(physical(path)).equals(owner), "ACL_OWNER");
		final var system = lookup.lookupPrincipalByName("SYSTEM");
		final var view = Files.getFileAttributeView(path, AclFileAttributeView.class);
		require(view != null, "ACL_UNAVAILABLE");
		for (var entry : view.getAcl()) { require(entry.type() != AclEntryType.ALLOW || entry.principal().equals(owner) || entry.principal().equals(system), "PRIVATE_ACL"); }
	}
	private static Properties owner(Path source, Path stage) throws Exception
	{
		privateAcl(stage, stage); privateAcl(stage, stage.resolve("private/owner.properties"));
		final Properties value = read(stage.resolve("private/owner.properties"));
		require("TASK109_PARTY_COMBAT".equals(value.getProperty("owner")) && "109".equals(value.getProperty("taskId")) && SCHEMA.equals(value.getProperty("schema")), "OWNER_SCHEMA");
		require(BASELINE.equals(value.getProperty("baseline")) && new com.sun.security.auth.module.NTSystem().getUserSID().equals(value.getProperty("ownerSid")), "BASELINE_SID");
		final String uuid = value.getProperty("installationId", "");
		requireBinding(SCHEMA, System.getProperty("phantom.task109.uuid"), value.getProperty("schema"), uuid);
		require(UUID.fromString(uuid).toString().equals(uuid) && uuid.equals(System.getProperty("phantom.task109.uuid", "")), "CALLER_UUID");
		require(Instant.now().isBefore(Instant.parse(value.getProperty("expiresUtc"))), "EXPIRED");
		require(physical(source).equals(physical(Path.of(value.getProperty("sourceModule")))) && physical(stage).equals(physical(Path.of(value.getProperty("stage")))), "OWNER_PATH");
		require(!stage.startsWith(source.getParent()) && physical(Path.of(value.getProperty("shadowModule"))).equals(stage.resolve("L2J_Mobius_CT_2.6_HighFive")), "EXTERNAL_SHADOW");
		require(hash(source.resolve("dist/game/config/Database.ini")).equals(value.getProperty("sourceDatabaseSha256")), "SOURCE_DATABASE_DRIFT");
		require(PACKAGE_SHA.equals(value.getProperty("packageSha256")) && hash(source.resolve("docs/phantoms/tasks/PHANTOM-AUTONOMOUS-PARTY-COMBAT-109/SHA256SUMS.txt")).equals(PACKAGE_SHA), "PACKAGE_DRIFT");
		for (String line : Files.readAllLines(source.resolve("docs/phantoms/tasks/PHANTOM-AUTONOMOUS-PARTY-COMBAT-109/SHA256SUMS.txt"), StandardCharsets.UTF_8))
		{
			final String[] fields = line.split("  ", -1);
			require(fields.length == 2 && fields[0].matches("[0-9a-f]{64}") && fields[1].matches("[A-Z_]+\\.(md|txt)") && hash(source.resolve("docs/phantoms/tasks/PHANTOM-AUTONOMOUS-PARTY-COMBAT-109").resolve(fields[1])).equals(fields[0]), "TASK_INPUT_DRIFT");
		}
		require(hash(stage.resolve("inputs.tsv")).equals(value.getProperty("inputsSha256")) && hash(stage.resolve("private/protected.tsv")).equals(value.getProperty("protectedSha256")), "MANIFEST_DRIFT");
		require(hash(stage.resolve("L2J_Mobius_CT_2.6_HighFive/dist/db_installer/sql/game/economy071.sql")).equals(value.getProperty("migrationSha256")), "MIGRATION_DRIFT");
		for (String line : Files.readAllLines(stage.resolve("private/protected.tsv"), StandardCharsets.UTF_8))
		{
			final String[] fields = line.split("\t", -1);
			require(fields.length == 2 && fields[1].matches("[0-9a-f]{64}") && hash(Path.of(fields[0])).equals(fields[1]), "PROTECTED_INPUT_DRIFT");
		}
		return value;
	}
	private static void inputs(Path source, Path stage, Properties authority) throws Exception
	{
		final Path shadow = stage.resolve("L2J_Mobius_CT_2.6_HighFive"), geo = physical(Path.of(authority.getProperty("geoSource")));
		require(geo.equals(source.getParent().resolve(".phantom-local/task074/runtime-test/game/data/geodata")) && hash(source.getParent().resolve(".phantom-local/task074/GEODATA074.tsv")).equals(authority.getProperty("geoPinSha256")), "GEO_SOURCE_PIN");
		int count = 0, regions = 0;
		final var seen = new java.util.HashSet<Path>(); final var origins = new java.util.HashSet<Path>();
		for (String line : Files.readAllLines(stage.resolve("inputs.tsv"), StandardCharsets.UTF_8))
		{
			final String[] fields = line.split("\t", -1);
			require(fields.length == 3 && fields[2].matches("[0-9a-f]{64}"), "INPUT_ROW");
			final Path origin = physical(Path.of(fields[0])), copy = physical(Path.of(fields[1]));
			origins.add(origin);
			require((origin.startsWith(source) || origin.startsWith(geo)) && copy.startsWith(shadow) && !copy.equals(shadow.resolve("dist/game/config/Database.ini")) && seen.add(copy), "INPUT_ESCAPE_DUPLICATE");
			require(hash(origin).equals(fields[2]), "SOURCE_INPUT_DRIFT");
			if (Files.exists(stage.resolve("pin.complete")) && copy.equals(shadow.resolve("dist/game/config/IdManager.ini")))
			{
				require(Files.readString(copy).equals(Files.readString(origin).replace("DatabaseCleanUp = True", "DatabaseCleanUp = False")), "CLEANUP_OVERLAY_DRIFT");
			}
			else { require(hash(copy).equals(fields[2]), "SHADOW_INPUT_DRIFT"); }
			if (origin.startsWith(geo))
			{
				require(origin.getFileName().toString().matches("[0-9]{2}_[0-9]{2}\\.l2j") && copy.equals(shadow.resolve("dist/game/data/geodata").resolve(origin.getFileName())), "GEO_REGION");
				regions++;
			}
			count++;
		}
		require(count > 1000 && regions == 203, "INPUT_COUNT_GEO");
		for (String root : new String[] {"java", "test", "dist/game/config", "dist/game/data", "dist/db_installer/sql"})
		{
			for (Path tree : new Path[] {source.resolve(root), shadow.resolve(root)})
			{
				try (var entries = Files.walk(tree))
				{
					for (Path entry : entries.toList())
					{
						require(!Files.isSymbolicLink(entry) && !Files.readAttributes(entry, java.nio.file.attribute.BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS).isOther(), "REPARSE_INPUT_TREE");
						if (!Files.isRegularFile(entry) || entry.equals(source.resolve("dist/game/config/Database.ini")) || entry.equals(shadow.resolve("dist/game/config/Database.ini")) || entry.startsWith(source.resolve("dist/game/data/geodata"))) { continue; }
						require(tree.startsWith(source) ? origins.contains(entry) : seen.contains(entry), "UNPINNED_INPUT_FILE");
					}
				}
			}
		}
		try (var libraries = Files.list(shadow.resolve("dist/libs")))
		{
			for (Path library : libraries.filter(file -> file.getFileName().toString().endsWith(".jar")).toList())
			{
				final String name = library.getFileName().toString();
				require(name.equals("GameServer.jar") || name.equals("LoginServer.jar") || seen.contains(library), "EXTRA_CLASSPATH_LIBRARY");
			}
		}
	}
	private static void targetUrl(String url) { require(TARGET_URL.equals(url), "EXACT_JDBC"); }
	private static Properties settings(Path stage) throws Exception
	{
		final Path path = stage.resolve("L2J_Mobius_CT_2.6_HighFive/dist/game/config/Database.ini");
		privateAcl(stage, path);
		final Properties seal = read(stage.resolve("pin.complete")), result = read(path);
		require(seal.getProperty("installationId").equals(System.getProperty("phantom.task109.uuid")) && hash(path).equals(seal.getProperty("databaseSha256")), "CONFIG_PIN");
		require(hash(stage.resolve("L2J_Mobius_CT_2.6_HighFive/dist/game/config/IdManager.ini")).equals(seal.getProperty("cleanupSha256")), "CLEANUP_PIN");
		targetUrl(result.getProperty("URL"));
		require("com.mysql.cj.jdbc.Driver".equals(result.getProperty("Driver")) && !result.getProperty("Login", "").isBlank() && result.containsKey("Password") && "4".equals(result.getProperty("MaximumDatabaseConnections")) && "False".equals(result.getProperty("BackupDatabase")) && "False".equals(result.getProperty("TestDatabaseConnections")), "BOUNDED_CONFIG");
		return result;
	}
	private static Connection connect(Properties settings, boolean admin) throws Exception
	{
		Class.forName(settings.getProperty("Driver")); DriverManager.setLoginTimeout(10);
		return DriverManager.getConnection(admin ? ADMIN_URL : settings.getProperty("URL"), settings.getProperty("Login"), settings.getProperty("Password"));
	}
	private static void quiescent(Connection connection) throws Exception
	{
		try (var statement = connection.createStatement(); var rows = statement.executeQuery("SELECT COUNT(*) FROM information_schema.PROCESSLIST WHERE ID<>CONNECTION_ID() AND COMMAND<>'Daemon'")) { require(rows.next() && rows.getLong(1) == 0, "FOREIGN_SQL_STOP"); }
	}
	private static void visibility(Connection connection) throws Exception
	{
		boolean all = false;
		try (var statement = connection.createStatement(); var rows = statement.executeQuery("SHOW GRANTS FOR CURRENT_USER"))
		{
			while (rows.next())
			{
				final String grant = rows.getString(1).toUpperCase(java.util.Locale.ROOT);
				all |= grant.startsWith("GRANT ALL PRIVILEGES ON *.* ");
			}
		}
		// Installer requires complete schema DDL/DML authority; partial global/table grants fail closed.
		require(all, "FULL_VISIBILITY_SCHEMA_RIGHTS_REQUIRED");
		quiescent(connection);
	}
	private static void absent(Connection connection) throws Exception
	{
		try (var statement = connection.createStatement(); var rows = statement.executeQuery("SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='" + SCHEMA + "'")) { require(rows.next() && rows.getLong(1) == 0, "EXISTING_SCHEMA_STOP"); }
	}
	private static String foreignMetadata(Connection connection) throws Exception
	{
		final var digest = MessageDigest.getInstance("SHA-256");
		for (String sql : new String[] {"SELECT SCHEMA_NAME,DEFAULT_CHARACTER_SET_NAME,DEFAULT_COLLATION_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME<>'" + SCHEMA + "' ORDER BY SCHEMA_NAME", "SELECT TABLE_SCHEMA,TABLE_NAME,TABLE_TYPE,ENGINE,TABLE_COLLATION FROM information_schema.TABLES WHERE TABLE_SCHEMA NOT IN ('information_schema','performance_schema','" + SCHEMA + "') ORDER BY TABLE_SCHEMA,TABLE_NAME"})
		{
			try (var statement = connection.createStatement(); var rows = statement.executeQuery(sql)) { while (rows.next()) { for (int index = 1; index <= rows.getMetaData().getColumnCount(); index++) { digest.update((String.valueOf(rows.getString(index)) + "\t").getBytes(StandardCharsets.UTF_8)); } digest.update((byte) '\n'); } }
		}
		return HexFormat.of().formatHex(digest.digest());
	}
	private static void safeSql(String sql)
	{
		if (ABSENT_DROP.matcher(sql).matches()) { return; }
		require(sql.stripLeading().matches("(?is)(CREATE\\s+TABLE|CREATE\\s+(?:UNIQUE\\s+)?INDEX|INSERT\\s+(?:IGNORE\\s+)?INTO|REPLACE\\s+INTO|ALTER\\s+TABLE|SET\\s+(NAMES|FOREIGN_KEY_CHECKS|CHARACTER_SET_CLIENT|CHARACTER_SET_RESULTS|COLLATION_CONNECTION))\\b.*"), "UNSAFE_SQL_VERB");
		final var identifiers = new StringBuilder(); char quote = 0;
		for (int index = 0; index < sql.length(); index++)
		{
			final char value = sql.charAt(index);
			if (quote != 0) { if (value == '\\') { index++; } else if (value == quote) { if (index + 1 < sql.length() && sql.charAt(index + 1) == quote) { index++; } else { quote = 0; } } identifiers.append(' '); }
			else if (value == '\'' || value == '"') { quote = value; identifiers.append(' '); }
			else { identifiers.append(value); }
		}
		require(!Pattern.compile("[`A-Za-z_][`A-Za-z0-9_]*\\s*\\.\\s*[`A-Za-z_]").matcher(identifiers).find(), "EXTERNAL_SQL_REFERENCE");
	}
	private static void owned(Connection connection, Properties authority, PhantomTestSchemaManifest.Snapshot schema) throws Exception
	{
		require(SCHEMA.equals(connection.getCatalog()), "CATALOG");
		try (var query = connection.prepareStatement("SELECT task_id,installation_id,schema_version,migration_sha256 FROM economy071_authority WHERE schema_name=?"))
		{
			query.setString(1, SCHEMA);
			try (var rows = query.executeQuery()) { require(rows.next() && rows.getInt(1) == 109 && authority.getProperty("installationId").equals(rows.getString(2)) && rows.getInt(3) == 1 && authority.getProperty("migrationSha256").equals(rows.getString(4)) && !rows.next(), "DATABASE_AUTHORITY"); }
		}
		PhantomTestSchemaManifest.requireExactDatabaseMetadata(connection, schema);
	}
	private static void exactTables(Connection connection, Path module) throws Exception
	{
		final var expected = new java.util.TreeSet<String>();
		for (var script : PhantomTestSchemaManifest.inventory(module))
		{
			for (String sql : script.statements()) { final var table = Pattern.compile("(?is)^\\s*CREATE\\s+TABLE\\s+(?:IF\\s+NOT\\s+EXISTS\\s+)?`?([A-Za-z0-9_]+)`?\\s*\\(").matcher(sql); if (table.find()) { expected.add(table.group(1).toLowerCase(java.util.Locale.ROOT)); } }
		}
		final var actual = new java.util.TreeSet<String>();
		try (var statement = connection.createStatement(); var rows = statement.executeQuery("SELECT TABLE_NAME,TABLE_TYPE,ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA='" + SCHEMA + "'"))
		{
			while (rows.next()) { require("BASE TABLE".equals(rows.getString(2)) && rows.getString(3) != null, "TABLE_METADATA"); actual.add(rows.getString(1).toLowerCase(java.util.Locale.ROOT)); }
		}
		require(!expected.isEmpty() && expected.equals(actual), "EXACT_TABLE_INVENTORY");
	}
	private static void preflight(Path source, Path stage) throws Exception
	{
		final var authority = owner(source, stage); inputs(source, stage, authority);
		require(!Files.exists(stage.resolve("bootstrap.started")), "NO_BOOTSTRAP_RETRY");
		final Properties settings = read(source.resolve("dist/game/config/Database.ini"));
		require("com.mysql.cj.jdbc.Driver".equals(settings.getProperty("Driver")), "SOURCE_DRIVER");
		try (var connection = connect(settings, true))
		{
			connection.setReadOnly(true); visibility(connection); absent(connection);
			final Properties receipt = new Properties(); receipt.setProperty("installationId", authority.getProperty("installationId")); receipt.setProperty("foreignMetadata", foreignMetadata(connection)); receipt.setProperty("utc", Instant.now().toString());
			receipt.setProperty("baseline", BASELINE); receipt.setProperty("inputsSha256", authority.getProperty("inputsSha256")); receipt.setProperty("protectedSha256", authority.getProperty("protectedSha256")); receipt.setProperty("sourceDatabaseSha256", authority.getProperty("sourceDatabaseSha256")); receipt.setProperty("geoRegions", "203"); receipt.setProperty("fullVisibility", "true"); receipt.setProperty("fullSchemaRights", "true"); receipt.setProperty("foreignSQL", "0"); receipt.setProperty("schemaAbsent", "true"); receipt.setProperty("SQL_DDL_DML", "0");
			write(stage.resolve("preflight.properties"), receipt);
		}
		System.out.println("TASK109_PREFLIGHT_PASS absent=true fullVisibility=true fullSchemaRights=true foreignSQL=0 sourceStageSHA=true protectedFileSHA=true sourceDatabaseUntouched=true ownerSID=true physicalShadow=true Geo=203 DDL_DML=0");
	}
	private static void pin(Path source, Path stage) throws Exception
	{
		final var authority = owner(source, stage); inputs(source, stage, authority);
		require(!Files.exists(stage.resolve("pin.started")) && !Files.exists(stage.resolve("pin.complete")) && !Files.exists(stage.resolve("bootstrap.started")), "NO_PIN_RETRY");
		require(authority.getProperty("installationId").equals(read(stage.resolve("preflight.properties")).getProperty("installationId")), "PREFLIGHT_REQUIRED");
		Files.writeString(stage.resolve("pin.started"), authority.getProperty("installationId"), StandardOpenOption.CREATE_NEW);
		final Path shadow = stage.resolve("L2J_Mobius_CT_2.6_HighFive"), config = shadow.resolve("dist/game/config/Database.ini"), cleanup = shadow.resolve("dist/game/config/IdManager.ini");
		final var original = read(source.resolve("dist/game/config/Database.ini")); final var settings = new Properties();
		for (String key : new String[] {"Driver", "Login", "Password"}) { require(original.containsKey(key), "SOURCE_CREDENTIALS"); settings.setProperty(key, original.getProperty(key)); }
		settings.setProperty("URL", TARGET_URL); settings.setProperty("MaximumDatabaseConnections", "4"); settings.setProperty("TestDatabaseConnections", "False"); settings.setProperty("BackupDatabase", "False");
		write(config, settings); privateAcl(stage, config);
		final String text = Files.readString(cleanup); require(text.contains("DatabaseCleanUp = True") && text.indexOf("DatabaseCleanUp = True") == text.lastIndexOf("DatabaseCleanUp = True"), "CLEANUP_PREIMAGE");
		Files.writeString(cleanup, text.replace("DatabaseCleanUp = True", "DatabaseCleanUp = False"), StandardCharsets.UTF_8);
		final var seal = new Properties(); seal.setProperty("installationId", authority.getProperty("installationId")); seal.setProperty("databaseSha256", hash(config)); seal.setProperty("cleanupSha256", hash(cleanup)); seal.setProperty("sqlAggregate", PhantomTestSchemaManifest.current(shadow).aggregateSha256());
		write(stage.resolve("pin.complete"), seal);
		System.out.println("TASK109_PIN_PASS Geo=203 sourceConfigUntouched=true SQL_DDL_DML=0");
	}
	private static void verifyPin(Path source, Path stage) throws Exception
	{
		final var authority = owner(source, stage); inputs(source, stage, authority); settings(stage);
		require(Files.readString(stage.resolve("pin.started")).equals(authority.getProperty("installationId")), "PIN_START_UUID");
		final Path shadow = stage.resolve("L2J_Mobius_CT_2.6_HighFive");
		require(PhantomTestSchemaManifest.current(shadow).aggregateSha256().equals(read(stage.resolve("pin.complete")).getProperty("sqlAggregate")), "SQL_PIN");
		for (var script : PhantomTestSchemaManifest.inventory(shadow)) { for (String sql : script.statements()) { safeSql(sql); } }
	}
	private static void bootstrap(Path source, Path stage) throws Exception
	{
		verifyPin(source, stage); final var authority = owner(source, stage); final var settings = settings(stage);
		final Path shadow = stage.resolve("L2J_Mobius_CT_2.6_HighFive"); final var schema = PhantomTestSchemaManifest.current(shadow);
		require(!Files.exists(stage.resolve("bootstrap.started")) && !Files.exists(stage.resolve("bootstrap.complete")), "NO_BOOTSTRAP_RETRY");
		try (var connection = connect(settings, true))
		{
			visibility(connection); absent(connection);
			require(foreignMetadata(connection).equals(read(stage.resolve("preflight.properties")).getProperty("foreignMetadata")), "PREFLIGHT_METADATA_DRIFT");
			Files.writeString(stage.resolve("bootstrap.started"), authority.getProperty("installationId"), StandardOpenOption.CREATE_NEW); phase = "BOOTSTRAP_MUTATING";
			try (var statement = connection.createStatement()) { statement.execute("CREATE DATABASE `" + SCHEMA + "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"); }
		}
		int omitted = 0;
		try (var connection = connect(settings, false))
		{
			require(SCHEMA.equals(connection.getCatalog()), "NEW_CATALOG"); visibility(connection); final int[] noops = {0};
			for (var script : PhantomTestSchemaManifest.inventory(shadow))
			{
				try (var statement = connection.createStatement())
				{
					StrictSqlScriptRunner.executeStatements(script, sql ->
					{
						final var drop = ABSENT_DROP.matcher(sql);
						if (drop.matches())
						{
							try (var query = connection.prepareStatement("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=? AND TABLE_NAME=?"))
							{
								query.setString(1, SCHEMA); query.setString(2, drop.group(1));
								try (var rows = query.executeQuery()) { if (!rows.next() || rows.getLong(1) != 0) { throw new SQLException("TASK109_DROP_EXISTING_REFUSED"); } }
							}
							noops[0]++; return;
						}
						safeSql(sql); statement.execute(sql);
					});
				}
			}
			omitted = noops[0];
			try (var insert = connection.prepareStatement("INSERT INTO economy071_authority(schema_name,task_id,installation_id,schema_version,migration_sha256) VALUES(?,109,?,1,?)")) { insert.setString(1, SCHEMA); insert.setString(2, authority.getProperty("installationId")); insert.setString(3, authority.getProperty("migrationSha256")); insert.executeUpdate(); }
			PhantomTestSchemaManifest.writeDatabaseMetadata(connection, schema); owned(connection, authority, schema);
			quiescent(connection); require(foreignMetadata(connection).equals(read(stage.resolve("preflight.properties")).getProperty("foreignMetadata")), "FOREIGN_METADATA_CHANGED");
		}
		final var receipt = new Properties(); receipt.setProperty("installationId", authority.getProperty("installationId")); receipt.setProperty("sqlAggregate", schema.aggregateSha256()); write(stage.resolve("bootstrap.complete"), receipt);
		System.out.println("TASK109_CREATE_ONLY_BOOTSTRAP_PASS absentDropsOmitted=" + omitted + " DROP_TRUNCATE_DELETE=0");
	}
	private static void verify(Path source, Path stage) throws Exception
	{
		verifyPin(source, stage); final var authority = owner(source, stage);
		require(authority.getProperty("installationId").equals(Files.readString(stage.resolve("bootstrap.started"))) && authority.getProperty("installationId").equals(read(stage.resolve("bootstrap.complete")).getProperty("installationId")), "BOOTSTRAP_UUID");
		try (var connection = connect(settings(stage), false))
		{
			connection.setReadOnly(true); visibility(connection); owned(connection, authority, PhantomTestSchemaManifest.current(stage.resolve("L2J_Mobius_CT_2.6_HighFive"))); exactTables(connection, stage.resolve("L2J_Mobius_CT_2.6_HighFive"));
			require(foreignMetadata(connection).equals(read(stage.resolve("preflight.properties")).getProperty("foreignMetadata")), "FOREIGN_METADATA_CHANGED");
		}
		System.out.println("TASK109_VERIFY_PASS owned=true fullVisibility=true foreignSQL=0 foreignMetadataUnchanged=true DDL_DML=0");
	}
	static boolean nativeEnabled() { return Boolean.getBoolean("phantom.task109.native"); }
	static Path nativeRoot() { return Path.of(System.getProperty("phantom.task109.root", "")); }
	static Instant nativeAdmissionExpiry() throws Exception { final var stage = physical(nativeRoot()); privateAcl(stage, stage.resolve("private/owner.properties")); final var value = read(stage.resolve("private/owner.properties")); require(value.getProperty("installationId").equals(System.getProperty("phantom.task109.uuid")), "CALLER_UUID"); final var expiry = Instant.parse(value.getProperty("expiresUtc")); require(Instant.now().isBefore(expiry), "EXPIRED"); return expiry; }
	static void validateNative(Path module, Path config) throws Exception
	{
		require(nativeEnabled(), "NATIVE_FLAG");
		for (String key : System.getProperties().stringPropertyNames()) { require(!(key.startsWith("phantom.task") && key.endsWith(".native") && !key.equals("phantom.task109.native") && Boolean.getBoolean(key)), "FOREIGN_NATIVE"); require(!(key.startsWith("phantom.") && (key.endsWith(".persistent") || key.endsWith(".manifest") || key.endsWith(".control"))), "FOREIGN_AUTHORITY"); }
		final Path stage = physical(nativeRoot()), shadow = stage.resolve("L2J_Mobius_CT_2.6_HighFive"), source = physical(Path.of(read(stage.resolve("private/owner.properties")).getProperty("sourceModule")));
		require(physical(module).equals(shadow) && physical(config).equals(shadow.resolve("dist/game/config/Database.ini")) && physical(Path.of("").toAbsolutePath()).equals(shadow.resolve("dist/game")), "NATIVE_CWD_CONFIG");
		verifyPin(source, stage); final var authority = owner(source, stage);
		final Path candidate = physical(Path.of(System.getProperty("phantom.task109.candidate", "")));
		require(candidate.getParent().equals(stage) && candidate.getFileName().toString().matches("candidate-v[1-9][0-9]*"), "CANDIDATE_PATH");
		final var seal = read(candidate.resolve("seal.properties"));
		require(BASELINE.equals(seal.getProperty("baseline")) && authority.getProperty("installationId").equals(seal.getProperty("installationId")) && authority.getProperty("inputsSha256").equals(seal.getProperty("inputsSha256")), "CANDIDATE_AUTHORITY");
		for (String[] pin : new String[][] {{"gameJarSha256", "L2J_Mobius_CT_2.6_HighFive/dist/libs/GameServer.jar"}, {"loginJarSha256", "L2J_Mobius_CT_2.6_HighFive/dist/libs/LoginServer.jar"}, {"testJarSha256", stage.relativize(candidate.resolve("Test109.jar")).toString()}}) { require(hash(stage.resolve(pin[1])).equals(seal.getProperty(pin[0])), "NATIVE_JAR_PIN"); }
		require(hash(candidate.resolve("resources.tsv")).equals(seal.getProperty("resourcesSha256")), "RESOURCE_MANIFEST_PIN");
		int resourceCount = 0;
		for (String line : Files.readAllLines(candidate.resolve("resources.tsv"), StandardCharsets.UTF_8))
		{
			final String[] fields = line.split("\t", -1); require(fields.length == 2 && fields[0].startsWith("build/phantom-test/resources/") && !fields[0].contains("..") && fields[1].matches("[0-9a-f]{64}") && hash(stage.resolve(fields[0])).equals(fields[1]), "RESOURCE_DRIFT"); resourceCount++;
		}
		try (var resources = Files.walk(stage.resolve("build/phantom-test/resources"))) { require(resources.filter(Files::isRegularFile).count() == resourceCount, "EXTRA_CLASSPATH_RESOURCE"); }
		require(physical(Path.of(org.l2jmobius.gameserver.model.actor.Player.class.getProtectionDomain().getCodeSource().getLocation().toURI())).equals(shadow.resolve("dist/libs/GameServer.jar")) && physical(Path.of(PhantomTask109Lane.class.getProtectionDomain().getCodeSource().getLocation().toURI())).equals(candidate.resolve("Test109.jar")), "CODE_SOURCE");
		require(authority.getProperty("installationId").equals(read(stage.resolve("bootstrap.complete")).getProperty("installationId")), "NATIVE_BOOTSTRAP_UUID");
		System.out.println("TASK109_NATIVE_FILES_PASS Geo=203 sourceConfigUntouched=true sameJAR=true");
	}
	static void initializeNative(Path module, Path config) throws Exception
	{
		validateNative(module, config); final Path stage = nativeRoot(); final var authority = read(stage.resolve("private/owner.properties"));
		try (var connection = connect(settings(stage), false)) { connection.setReadOnly(true); visibility(connection); owned(connection, authority, PhantomTestSchemaManifest.current(module)); require(foreignMetadata(connection).equals(read(stage.resolve("preflight.properties")).getProperty("foreignMetadata")), "FOREIGN_METADATA_CHANGED"); }
		System.setProperty("phantom.economy.schema", SCHEMA); System.setProperty("phantom.economy.installation", authority.getProperty("installationId"));
		org.l2jmobius.commons.database.DatabaseFactory.initFromConfig(config.toString());
	}
	static boolean cleanProcessReceipt(String observedType, String observedExit, String processClean)
	{
		return "Int32".equals(observedType) && "0".equals(observedExit) && "true".equals(processClean);
	}

	static void postflightNative(Path module, Path config) throws Exception
	{
		validateNative(module, config); final Path stage = nativeRoot(), candidate = physical(Path.of(System.getProperty("phantom.task109.candidate")));
		final String priorPhase = System.getProperty("phantom.task109.postflightPhase", ""); require(priorPhase.equals("native") || priorPhase.equals("restart") || priorPhase.equals("c2"), "POSTFLIGHT_PHASE");
		final Properties exit = read(candidate.resolve(priorPhase + ".exit.properties")), clearance = read(candidate.resolve(priorPhase + ".clearance.properties"));
		require(cleanProcessReceipt(exit.getProperty("observedType"), exit.getProperty("observedExit"), read(candidate.resolve(priorPhase + ".complete")).getProperty("processClean")), "OBSERVED_CLEAN_EXIT_ZERO_REQUIRED");
		require(exit.getProperty("installationId").equals(System.getProperty("phantom.task109.uuid")) && hash(candidate.resolve(priorPhase + ".log")).equals(exit.getProperty("logSha256")) && hash(candidate.resolve(priorPhase + ".complete")).equals(exit.getProperty("completionSha256")), "EXIT_RECEIPT_PIN");
		require(hash(candidate.resolve(priorPhase + ".gameplay.tsv")).equals(read(candidate.resolve(priorPhase + ".complete")).getProperty("gameplaySha256")), "GAMEPLAY_VERDICT_RECEIPT_PIN");
		require(hash(module.resolve("dist/libs/GameServer.jar")).equals(exit.getProperty("gameJarSha256")) && read(stage.resolve("private/owner.properties")).getProperty("inputsSha256").equals(exit.getProperty("inputsSha256")), "EXIT_SAME_JAR_INPUTS");
		require("0".equals(clearance.getProperty("JVM")) && "0".equals(clearance.getProperty("TCP")) && "0".equals(clearance.getProperty("SQL")) && "true".equals(clearance.getProperty("fullVisibility")) && hash(candidate.resolve(priorPhase + ".exit.properties")).equals(clearance.getProperty("exitReceiptSha256")) && hash(candidate.resolve(priorPhase + ".sql-clearance.log")).equals(clearance.getProperty("sqlLogSha256")), "POSTEXIT_CLEARANCE_REQUIRED");
		require(Files.readString(candidate.resolve(priorPhase + ".log")).contains("TASK109_CANONICAL_STORE_STOP_PASS"), "CANONICAL_STORE_RECEIPT_REQUIRED");
		verify(Path.of(read(stage.resolve("private/owner.properties")).getProperty("sourceModule")), stage);
		final var receipt = new Properties(); receipt.setProperty("exitReceiptSha256", hash(candidate.resolve(priorPhase + ".exit.properties"))); receipt.setProperty("completionSha256", exit.getProperty("completionSha256")); receipt.setProperty("installationId", exit.getProperty("installationId")); receipt.setProperty("utc", Instant.now().toString());
		write(candidate.resolve(priorPhase + ".postflight.complete"), receipt);
		System.out.println("TASK109_NATIVE_POSTFLIGHT_PASS phase=" + priorPhase + " observedExit=0 STORE=true priorOwnSQL=0 foreignSQL=0 JVM=0 TCP=0 DDL_DML=0");
	}
	static void requireRestartReady() throws Exception
	{
		final Path candidate = physical(Path.of(System.getProperty("phantom.task109.candidate")));
		final Properties receipt = read(candidate.resolve("native.postflight.complete")), exit = read(candidate.resolve("native.postflight.exit.properties")), clearance = read(candidate.resolve("native.postflight.clearance.properties"));
		require("Int32".equals(exit.getProperty("observedType")) && "0".equals(exit.getProperty("observedExit")) && hash(candidate.resolve("native.postflight.complete")).equals(exit.getProperty("completionSha256")) && hash(candidate.resolve("native.postflight.log")).equals(exit.getProperty("logSha256")), "RESTART_POSTFLIGHT_EXIT_ZERO");
		require(receipt.getProperty("installationId").equals(System.getProperty("phantom.task109.uuid")) && receipt.getProperty("exitReceiptSha256").equals(hash(candidate.resolve("native.exit.properties"))) && "0".equals(clearance.getProperty("JVM")) && "0".equals(clearance.getProperty("TCP")) && "0".equals(clearance.getProperty("SQL")) && hash(candidate.resolve("native.postflight.exit.properties")).equals(clearance.getProperty("exitReceiptSha256")), "RESTART_CLEARANCE_CHAIN");
		final var nativeComplete = read(candidate.resolve("native.complete"));
		if (PhantomAutonomousParty109Native.gameplayClosure())
		{
			final var proof = read(candidate.resolve("native.pk.persistence.properties"));
			final boolean dPassed = "PASS".equals(read(candidate.resolve("native.gate-D.properties")).getProperty("status"));
			if (!PhantomAutonomousParty109Native.jointAcceptance() || dPassed) { require(dDurabilityReady(nativeComplete, proof), "D_DURABLE_SQL_WITNESS_REQUIRED"); }
			else { require("false".equals(proof.getProperty("pkGameplayPassed")) && "true".equals(proof.getProperty("canonicalStoreSQLVerified")), "INDEPENDENT_F_REQUIRES_CANONICAL_SQL_STORE"); }
			require(hash(candidate.resolve("native.pk.persistence.properties")).equals(nativeComplete.getProperty("pkWitnessSha256")) && hash(candidate.resolve("native.persisted.tsv")).equals(proof.getProperty("persistedSha256")), "D_SQL_WITNESS_PINS");
			require((PhantomAutonomousParty109Native.jointAcceptance() || dPassed) && "PASS".equals(read(candidate.resolve("native.gate-E.properties")).getProperty("status")), "D_AND_STORE_PASS_REQUIRED");
		}
		require("true".equals(nativeComplete.getProperty("processClean")) && hash(candidate.resolve("native.complete")).equals(receipt.getProperty("completionSha256")) && hash(candidate.resolve("native.gameplay.tsv")).equals(nativeComplete.getProperty("gameplaySha256")), "RESTART_CLEAN_COMPLETION_AND_GAMEPLAY_PINS");
	}
	static boolean dDurabilityReady(Properties complete, Properties proof)
	{
		return "true".equals(complete.getProperty("processClean")) && "true".equals(complete.getProperty("dDurabilityReady"))
			&& "true".equals(proof.getProperty("pkGameplayPassed")) && "true".equals(proof.getProperty("canonicalStoreSQLVerified"))
			&& "1".equals(proof.getProperty("pkKills")) && proof.getProperty("karma", "").matches("[1-9][0-9]*");
	}
	static void requireC2Ready() throws Exception
	{
		require(PhantomAutonomousParty109Native.gameplayClosure(), "C2_CLOSURE_REQUIRED");
		requireRestartReady();
		final Path candidate = physical(Path.of(System.getProperty("phantom.task109.candidate")));
		final var receipt = read(candidate.resolve("restart.postflight.complete"));
		final var exit = read(candidate.resolve("restart.postflight.exit.properties"));
		final var clearance = read(candidate.resolve("restart.postflight.clearance.properties"));
		final var complete = read(candidate.resolve("restart.complete"));
		final var loaded = read(candidate.resolve("restart.pk-load.properties"));
		final var nativePk = read(candidate.resolve("native.pk.persistence.properties"));
		if (PhantomAutonomousParty109Native.jointAcceptance())
		{
			require(dDurabilityReady(read(candidate.resolve("native.complete")), nativePk), "C2_NATIVE_PK_DURABILITY_REQUIRED");
			final var stored = read(candidate.resolve("restart.pk.persistence.properties"));
			require(hash(candidate.resolve("restart.pk.persistence.properties")).equals(complete.getProperty("storedPkSha256"))
				&& "true".equals(stored.getProperty("canonicalStoreSQLVerified")) && "true".equals(stored.getProperty("pkGameplayPassed"))
				&& stored.getProperty("actor").equals(nativePk.getProperty("actor")) && stored.getProperty("pkKills").equals(nativePk.getProperty("pkKills"))
				&& stored.getProperty("karma", "").matches("0|[1-9][0-9]*") && "restart.persisted.tsv".equals(stored.getProperty("persistedSnapshot"))
				&& hash(candidate.resolve("restart.persisted.tsv")).equals(stored.getProperty("persistedSha256")), "C2_RESTART_FINAL_SQL_WITNESS_PIN");
		}
		require(hash(candidate.resolve("restart.pk-load.properties")).equals(complete.getProperty("loadedPkSha256"))
			&& "true".equals(loaded.getProperty("verifiedImmediatelyAfterNativeLoad")) && complete.getProperty("pid").equals(loaded.getProperty("pid"))
			&& loaded.getProperty("actor").equals(nativePk.getProperty("actor")) && loaded.getProperty("pkKills").equals(nativePk.getProperty("pkKills"))
			&& loaded.getProperty("karma").equals(nativePk.getProperty("karma")), "C2_RESTART_PK_LOAD_WITNESS_PIN");
		require("Int32".equals(exit.getProperty("observedType")) && "0".equals(exit.getProperty("observedExit"))
			&& hash(candidate.resolve("restart.postflight.complete")).equals(exit.getProperty("completionSha256"))
			&& hash(candidate.resolve("restart.postflight.log")).equals(exit.getProperty("logSha256")), "C2_RESTART_POSTFLIGHT_EXIT_ZERO");
		require(receipt.getProperty("installationId").equals(System.getProperty("phantom.task109.uuid"))
			&& receipt.getProperty("exitReceiptSha256").equals(hash(candidate.resolve("restart.exit.properties")))
			&& "0".equals(clearance.getProperty("JVM")) && "0".equals(clearance.getProperty("TCP")) && "0".equals(clearance.getProperty("SQL"))
			&& hash(candidate.resolve("restart.postflight.exit.properties")).equals(clearance.getProperty("exitReceiptSha256")), "C2_RESTART_CLEARANCE_CHAIN");
		require("true".equals(complete.getProperty("processClean")) && "true".equals(complete.getProperty(PhantomAutonomousParty109Native.jointAcceptance() ? "pkDurabilityReady" : "gameplayPassed"))
			&& hash(candidate.resolve("restart.complete")).equals(receipt.getProperty("completionSha256"))
			&& hash(candidate.resolve("restart.gameplay.tsv")).equals(complete.getProperty("gameplaySha256"))
			&& "PASS".equals(read(candidate.resolve("restart.gate-PK_RESTART.properties")).getProperty("status"))
			&& (!PhantomAutonomousParty109Native.jointAcceptance() || "PASS".equals(read(candidate.resolve("restart.gate-A.properties")).getProperty("status")))
			&& (!PhantomAutonomousParty109Native.jointAcceptance() || "PASS".equals(read(candidate.resolve("restart.gate-E.properties")).getProperty("status")))
			&& !Long.toString(ProcessHandle.current().pid()).equals(complete.getProperty("pid")), "C2_REQUIRES_DURABLE_PK_IN_SEPARATE_COMPLETED_JVM");
	}
	private static void guards()
	{
		targetUrl(TARGET_URL); int negatives = 0;
		for (String invalid : new String[] {TARGET_URL.replace(":3308/", ":3306/"), TARGET_URL.replace(SCHEMA, "l2jmobiush5"), TARGET_URL.replace(SCHEMA, "l2jmobiush5_phantom_test_094"), TARGET_URL.replace(SCHEMA, "l2jmobiush5_phantom_test_102"), TARGET_URL + "&allowMultiQueries=true"})
		{
			try { targetUrl(invalid); throw new AssertionError("TASK109_JDBC_NEGATIVE_ACCEPTED"); } catch (IllegalArgumentException expected) { negatives++; }
		}
		for (String invalid : new String[] {"DROP TABLE x", "TRUNCATE x", "DELETE FROM x", "USE other", "CREATE TABLE other.x(id INT)", "INSERT INTO `other`.`x` VALUES(1)"})
		{
			try { safeSql(invalid); throw new AssertionError("TASK109_SQL_NEGATIVE_ACCEPTED"); } catch (IllegalArgumentException expected) { negatives++; }
		}
		safeSql("DROP TABLE IF EXISTS `x`"); safeSql("INSERT INTO x VALUES('other.x')");
		System.out.println("TASK109_GUARDS_PASS negative=" + negatives + " SQL_DDL_DML=0");
	}
	public static void main(String[] args)
	{
		try
		{
			if (args.length == 1 && args[0].equals("guards")) { guards(); return; }
			if (args.length == 2 && args[0].equals("audit"))
			{
				final var config = read(physical(Path.of(args[1])).resolve("dist/game/config/Database.ini"));
				try (var connection = connect(config, true)) { connection.setReadOnly(true); visibility(connection); absent(connection); }
				System.out.println("TASK109_SQL_AUDIT_PASS fullVisibility=true fullSchemaRights=true schemaAbsent=true foreignSQL=0 DDL_DML=0"); return;
			}
			require(args.length == 3, "ACTION_ARGUMENTS");
			for (String key : System.getProperties().stringPropertyNames()) { require(!(key.startsWith("phantom.task") && key.endsWith(".native") && Boolean.getBoolean(key)), "NATIVE_NOT_AUTHORIZED"); }
			phase = args[0].toUpperCase(java.util.Locale.ROOT); final Path source = physical(Path.of(args[1])), stage = physical(Path.of(args[2]));
			switch (args[0]) { case "preflight" -> preflight(source, stage); case "pin" -> pin(source, stage); case "verify-pin" -> { verifyPin(source, stage); System.out.println("TASK109_PIN_VERIFY_PASS SQL_DDL_DML=0"); } case "bootstrap" -> bootstrap(source, stage); case "verify" -> verify(source, stage); default -> throw new IllegalArgumentException("TASK109_UNKNOWN_ACTION"); }
		}
		catch (SQLException failure) { System.err.println("TASK109_" + phase + "_STOP SQLState=" + failure.getSQLState() + " vendorCode=" + failure.getErrorCode()); System.exit(2); }
		catch (Exception failure) { final String reason = failure instanceof IllegalArgumentException && failure.getMessage() != null && failure.getMessage().matches("TASK109_[A-Z_]+") ? failure.getMessage() : failure.getClass().getSimpleName(); System.err.println("TASK109_" + phase + "_STOP reason=" + reason); System.exit(2); }
	}
}
